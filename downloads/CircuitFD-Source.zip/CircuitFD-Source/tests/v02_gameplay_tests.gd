extends SceneTree
## Real main-scene v0.2 integration checks; no native-window/audio-listening claim.
var game: Node3D
var checks: int = 0
var failures: int = 0
var saved: Dictionary = {}

func check(condition: bool, message: String) -> void:
	checks += 1
	if not condition:
		failures += 1
		push_error("V02 GAMEPLAY: " + message)

func key_event(code: Key, pressed: bool = true) -> InputEventKey:
	var event := InputEventKey.new()
	event.keycode = code
	event.physical_keycode = code
	event.pressed = pressed
	return event

func press(code: Key, down: bool = true) -> void:
	Input.parse_input_event(key_event(code, down))
	Input.flush_buffered_events()

func tick(count: int) -> void:
	for _i in range(count):
		game._physics_process(1.0 / 120.0)

func _initialize() -> void:
	if OS.get_environment("CIRCUIT_QA_ISOLATED") != "1":
		push_error("Use CIRCUIT_QA_ISOLATED=1 and isolated XDG_DATA_HOME for settings tests")
		quit(2)
		return
	create_timer(60.0).timeout.connect(func():
		push_error("V02 GAMEPLAY: test did not complete within 60 wall seconds")
		quit(1))
	call_deferred("run")

func run() -> void:
	for name in ["settings.cfg", "music-library.json"]:
		var path: String = "user://" + name
		if FileAccess.file_exists(path):
			saved[name] = FileAccess.get_file_as_bytes(path)
			DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	game = load("res://main.tscn").instantiate()
	root.add_child(game)
	game.set_process(false)
	game.set_physics_process(false)
	await process_frame
	check(is_instance_valid(game.atmosphere) and is_instance_valid(game.music), "Atmosphere or music is absent from the real scene")
	if not is_instance_valid(game.atmosphere) or not is_instance_valid(game.music):
		game.free()
		quit(1)
		return
	check(not game.playing and not game.music.is_panel_open() and not game.photo_mode, "Startup should be safely paused without modal overlays")
	check(game.settings.has("time_of_day") and game.settings.has("weather") and game.settings.has("reflections"), "New persisted session settings are absent")
	check(game.hud.setting_controls.has("weather") and game.hud.setting_controls.has("time_of_day"), "New settings have no actual UI controls")

	# The UI signal must reach the actual lighting module and persisted ConfigFile.
	game.hud.setting_changed.emit("time_of_day", 0)
	var day_rotation: Vector3 = game.sun.rotation
	var day_color: Color = game.sun.light_color
	game._unhandled_key_input(key_event(KEY_T))
	check(game.settings.time_of_day == 1 and game.atmosphere.time_preset == 1, "T did not cycle the applied time preset")
	check(game.sun.rotation.distance_to(day_rotation) > 0.1 and game.sun.light_color != day_color, "Time preset changed a label without changing actual sunlight")
	game._unhandled_key_input(key_event(KEY_T))
	check(game.atmosphere.time_preset == 2, "Dusk preset cannot be reached")
	game._unhandled_key_input(key_event(KEY_T))
	check(game.atmosphere.time_preset == 0 and game.hud.setting_controls.time_of_day.selected == 0, "Time cycling does not wrap/synchronize its UI")
	game.hud.setting_changed.emit("quality", 1)
	game.hud.setting_changed.emit("reflections", false)
	check(not game.atmosphere.probe.visible, "Disabling local reflections leaves the actual probe enabled")
	game.hud.setting_changed.emit("reflections", true)
	check(game.atmosphere.probe.visible and game.atmosphere.probe.cull_mask == 1, "Local reflection probe is absent or includes the car's layer")
	var car_geometry: Array[Node] = game.model.find_children("*", "GeometryInstance3D", true, false)
	var layer_ok: bool = not car_geometry.is_empty()
	for geometry in car_geometry:
		layer_ok = layer_ok and geometry.layers == 2
	check(layer_ok, "Car geometry can be baked into its own environment-only reflection probe")

	game.hud.setting_changed.emit("weather", 1)
	check(game.track.wet and game.settings.weather == 1, "Wet setting did not reach the real track")
	check(is_equal_approx(float(game.track._road_material.get_shader_parameter("wetness")), 1.0), "Wet setting does not affect the asphalt shader")
	game._start()
	press(KEY_W)
	tick(240)
	check(game.surface == "wet" and game.car.speed > 0.5, "Real driving did not use the wet surface route")
	game._unhandled_key_input(key_event(KEY_F2))
	tick(1)
	check(not game.track.wet and game.surface == "asphalt" and game.hud.setting_controls.weather.selected == 0, "F2 failed to restore dry shader, physics route or UI")
	press(KEY_W, false)

	# Freeze the moving car in photo mode, then exercise real orbit controls.
	var position_before_photo: Vector3 = game.car.position
	var lap_before_photo: float = game.rules.lap_time
	game._unhandled_key_input(key_event(KEY_P))
	check(game.photo_mode and not game.playing and not game.hud.root.visible and game._photo_layer.visible, "Photo entry did not freeze the scene and hide the driving HUD")
	var wheel_before: float = game.model.wheel_angle
	tick(480)
	game._process(0.25)
	check(game.car.position.distance_to(position_before_photo) < 0.00001 and is_equal_approx(game.rules.lap_time, lap_before_photo), "Photo mode advances the vehicle or lap timer")
	check(is_equal_approx(game.model.wheel_angle, wheel_before), "Photo mode animates rolling wheels while simulation is frozen")
	var camera_before: Vector3 = game.camera.global_position
	var motion := InputEventMouseMotion.new()
	motion.button_mask = MOUSE_BUTTON_MASK_LEFT
	motion.relative = Vector2(120.0, 35.0)
	game._unhandled_input(motion)
	game._process(0.0)
	check(game.camera.global_position.distance_to(camera_before) > 0.3, "Photo mouse drag does not actually orbit the camera")
	var wheel := InputEventMouseButton.new()
	wheel.pressed = true
	wheel.button_index = MOUSE_BUTTON_WHEEL_UP
	for _i in range(50): game._unhandled_input(wheel)
	game._process(0.0)
	check(is_equal_approx(game._photo_distance, 2.7) and game.camera.global_position.y >= 0.22, "Photo zoom-in/ground safety limit failed")
	wheel.button_index = MOUSE_BUTTON_WHEEL_DOWN
	for _i in range(80): game._unhandled_input(wheel)
	check(is_equal_approx(game._photo_distance, 14.0), "Photo zoom-out limit failed")
	press(KEY_W)
	press(KEY_D)
	var yaw_before: float = game._photo_yaw
	game._process(1.0)
	check(game._photo_yaw != yaw_before and game.camera.global_position.is_finite(), "Photo keyboard orbit/tilt did not reach a finite camera")
	game._unhandled_key_input(key_event(KEY_P))
	check(not game.photo_mode and game.playing and game.hud.root.visible and not game._photo_layer.visible, "Photo return did not restore the prior driving state")
	check(not Input.is_physical_key_pressed(KEY_W) and not Input.is_physical_key_pressed(KEY_D), "Photo return leaks held camera keys into driving")
	game._pause()
	game._enter_photo()
	game._leave_photo()
	check(not game.playing and game.hud.menu.visible, "Photo opened from a menu unexpectedly starts driving")
	game._take_photo()
	check(not game._snapshot_pending, "Headless screenshot guard leaves a stuck save operation")

	# Opening music must pause safely; playback then survives closing and resuming.
	game._start()
	game.hud.music_requested.emit()
	check(not game.playing and game.music.is_panel_open() and not game.hud.menu.visible, "Music button did not pause and open the actual player without overlapping menus")
	check(game.music.playlist.size() > 0, "Bundled original demo is missing from the library")
	check(game.music.play_index(0), "Bundled demo cannot be decoded/started")
	check(game.music.is_music_playing() and game.music.duration() > 30.0, "Demo did not become real playable audio with duration")
	await create_timer(0.25).timeout
	check(game.music.player.get_playback_position() > 0.0, "Actual audio playback cursor did not progress")
	check(not game.music.get_current_title().is_empty(), "Playing music has no now-playing title")
	game.music.pause_playback()
	check(not game.music.is_music_playing() and game.music.player.stream_paused, "Music pause failed to pause the actual player")
	game.music.toggle_playback()
	check(game.music.is_music_playing(), "Music resume failed")
	check(game.music.seek_to(10.0), "Real demo stream cannot seek")
	await process_frame
	check(game.music.player.get_playback_position() >= 9.5, "Music seek did not affect the actual playback cursor")
	game._unhandled_key_input(key_event(KEY_M))
	check(not game.music.is_panel_open() and not game.playing and game.hud.menu.visible, "Closing music did not return to a safe paused menu")
	check(game.music.is_music_playing(), "Closing the music UI stops music unnecessarily")
	game.hud.resume_requested.emit()
	press(KEY_W)
	var before_resume: Vector3 = game.car.position
	tick(120)
	game._process(1.0 / 120.0)
	check(game.playing and game.car.position.distance_to(before_resume) > 0.1 and game.music.is_music_playing(), "Music does not continue during real resumed vehicle motion")
	check(game.hud.music_title_label.text == game.music.get_current_title(), "Driving HUD does not reflect the actual current music title")
	press(KEY_W, false)
	game._pause()
	var master_before: float = AudioServer.get_bus_volume_db(0)
	game.music.set_volume(0.0)
	check(AudioServer.get_bus_volume_db(AudioServer.get_bus_index("Music")) <= -79.9 and AudioServer.get_bus_volume_db(0) == master_before, "Music volume incorrectly changes the master/engine bus")
	game.music.set_volume(55.0)

	var config := ConfigFile.new()
	check(config.load("user://settings.cfg") == OK and config.get_value("settings", "weather", -1) == game.settings.weather and config.get_value("settings", "time_of_day", -1) == game.settings.time_of_day, "New applied session values are not saved")
	game.music.shutdown()
	game.audio.shutdown()
	game.free()
	await create_timer(0.7).timeout
	for name in ["settings.cfg", "music-library.json"]:
		var path: String = "user://" + name
		if saved.has(name):
			var file := FileAccess.open(path, FileAccess.WRITE)
			file.store_buffer(saved[name])
		else:
			DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	print("V02 GAMEPLAY TESTS: %d checks, %d failures | actual scene, synthetic input, Dummy audio" % [checks, failures])
	quit(0 if failures == 0 else 1)
