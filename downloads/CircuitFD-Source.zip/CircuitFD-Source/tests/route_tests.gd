extends SceneTree
## Scripted driving on the real generated path; never teleports to follow it.
const VehicleScript = preload("res://scripts/vehicle.gd")
const TrackScript = preload("res://scripts/track.gd")
const RulesScript = preload("res://scripts/race_rules.gd")

func _initialize() -> void:
	var track = TrackScript.new()
	track._make_path()
	var car = VehicleScript.new()
	root.add_child(car)
	var start: Dictionary = track.sample_at(0.0)
	car.reset_to(start.position, start.yaw)
	var rules = RulesScript.new()
	rules.reset(track.total_length)
	var maximum_departure: float = 0.0
	var maximum_speed: float = 0.0
	var passed: bool = false
	var simulated_seconds: float = 0.0
	for tick in range(240 * 120):
		var near: Dictionary = track.nearest(car.position)
		var lookahead: float = clampf(absf(car.speed) * 0.45, 4.0, 9.0)
		var target: Dictionary = track.sample_at(near.progress + lookahead)
		var to_target: Vector3 = target.position - car.position
		var error: float = wrapf(atan2(-to_target.x, -to_target.z) - car.rotation.y, -PI, PI)
		var curvature: float = 2.0 * sin(error) / maxf(to_target.length(), 1.0)
		var desired_angle: float = atan(curvature * 2.425 * (1.0 + 0.0016 * car.speed * car.speed))
		var max_steer: float = lerpf(0.53, 0.13, clampf(absf(car.speed) / 55.0, 0.0, 1.0))
		var steer: float = clampf(desired_angle / max_steer, -1.0, 1.0)
		var largest_curvature: float = 0.005
		for offset in [5.0, 10.0, 20.0, 35.0]:
			var p0: Dictionary = track.sample_at(near.progress + offset)
			var p1: Dictionary = track.sample_at(near.progress + offset + 6.0)
			largest_curvature = maxf(largest_curvature, absf(wrapf(p1.yaw - p0.yaw, -PI, PI)) / 6.0)
		var target_speed: float = clampf(sqrt(3.0 / largest_curvature), 6.0, 17.0)
		var gas: float = clampf((target_speed - car.speed) * 0.8, 0.0, 1.0)
		var brake: float = clampf((car.speed - target_speed - 0.3) * 0.3, 0.0, 0.7)
		car.step(1.0 / 120.0, gas, brake, steer, false, false, "asphalt")
		var after: Dictionary = track.nearest(car.position)
		maximum_departure = maxf(maximum_departure, after.distance)
		maximum_speed = maxf(maximum_speed, car.speed)
		simulated_seconds = float(tick + 1) / 120.0
		if rules.tick(1.0 / 120.0, after.progress, after.distance <= track.road_half_width + 0.9, car.velocity.dot(after.forward) > 0.3, car.velocity.length() > 0.25):
			passed = true
			break
		if not car.position.is_finite() or after.distance > track.barrier_offset:
			break
	var report: Dictionary = {"test": "scripted-real-vehicle-full-lap", "track_length_m": track.total_length, "run_utc": Time.get_datetime_string_from_system(true), "passed": passed, "simulated_seconds": simulated_seconds, "maximum_distance_from_center_m": maximum_departure, "maximum_speed_kmh": maximum_speed * 3.6, "laps": rules.completed_laps, "next_gate": rules.next_gate, "lap_valid": rules.valid, "position": str(car.position), "speed_kmh": car.speed * 3.6}
	print("ROUTE TEST ", JSON.stringify(report))
	var output := FileAccess.open("res://artifacts/route-test.json", FileAccess.WRITE)
	if output:
		output.store_string(JSON.stringify(report, "  "))
	track.free()
	car.free()
	if not passed:
		push_error("The real simulated car did not complete a valid full circuit within 240 simulated seconds")
	quit(0 if passed else 1)
