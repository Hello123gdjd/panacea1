extends SceneTree

const VehicleScript = preload("res://scripts/vehicle.gd")
var failures: int = 0
var checks: int = 0

func check(condition: bool, message: String) -> void:
	checks += 1
	if not condition:
		failures += 1
		push_error(message)

func simulate(car: Node3D, seconds: float, gas: float, stop: float, steering: float, reversing: bool = false, handbrake: bool = false, surface: String = "asphalt") -> void:
	for tick in range(roundi(seconds * 120.0)):
		car.step(1.0 / 120.0, gas, stop, steering, reversing, handbrake, surface)

func braking_distance(car: Node3D, surface: String) -> float:
	car.reset_to(Vector3.ZERO, 0.0)
	car.velocity = Vector3(0.0, 0.0, -25.0)
	for tick in range(120 * 12):
		car.step(1.0 / 120.0, 0.0, 1.0, 0.0, false, false, surface)
		if car.velocity.length() < 0.001:
			break
	return -car.position.z

func render_grouping(car: Node3D, render_hz: int) -> int:
	car.reset_to(Vector3.ZERO, 0.0)
	var accumulator: float = 0.0
	var simulation_ticks: int = 0
	var fixed_dt: float = 1.0 / 120.0
	for frame in range(render_hz * 6):
		accumulator += 1.0 / float(render_hz)
		while accumulator + 0.00000001 >= fixed_dt:
			var simulation_time: float = float(simulation_ticks) * fixed_dt
			var gas: float = 1.0 if simulation_time < 4.0 else 0.0
			var stop: float = 1.0 if simulation_time >= 5.0 else 0.0
			var steering: float = 0.3 if simulation_time > 2.0 and simulation_time < 4.0 else -0.1
			car.step(fixed_dt, gas, stop, steering, false, false)
			accumulator -= fixed_dt
			simulation_ticks += 1
	return simulation_ticks

func _initialize() -> void:
	var car = VehicleScript.new()
	root.add_child(car)
	car.reset_to(Vector3.ZERO, 0.0)
	simulate(car, 4.0, 0.0, 0.0, 0.0)
	check(car.position == Vector3.ZERO and car.velocity == Vector3.ZERO, "Stationary car drifted")
	simulate(car, 8.0, 1.0, 0.0, 0.0)
	check(car.speed > 20.0 and car.speed < 55.0, "Acceleration outside plausible broad range")
	check(car.position.z < -70.0 and absf(car.position.x) < 0.01, "Straight acceleration drifted sideways")
	check(car.gear >= 2 and car.rpm >= 950.0 and car.rpm <= 7900.0, "Automatic transmission/rpm failed")
	simulate(car, 8.0, 0.0, 1.0, 0.0)
	check(absf(car.speed) < 0.001 and car.velocity.length() < 0.001, "Full brake did not stop")
	simulate(car, 4.0, 0.0, 1.0, 0.0)
	check(absf(car.speed) < 0.001, "Holding brake at rest generated reverse motion")
	simulate(car, 4.0, 1.0, 0.0, 0.0, true)
	check(car.speed < -2.0 and car.gear == -1, "Explicit reverse failed")
	simulate(car, 15.0, 1.0, 0.0, 0.0, true)
	check(car.speed > -12.0, "Reverse speed cap failed")
	simulate(car, 6.0, 1.0, 0.0, 0.0, false)
	check(car.speed > 0.0 and car.gear > 0, "Safe forward/reverse direction transition failed")
	car.reset_to(Vector3.ZERO, 0.0)
	simulate(car, 5.0, 1.0, 0.0, 0.0)
	simulate(car, 2.0, 0.6, 0.0, 1.0)
	check(car.rotation.y > 0.1 and car.position.x < 0.0, "Left steering must yaw left (+Y), turn towards -X")
	check(absf(car.lateral_slip) < 15.0, "Normal cornering produced runaway lateral slip")
	var other = VehicleScript.new()
	root.add_child(other)
	car.reset_to(Vector3.ZERO, 0.0)
	other.reset_to(Vector3.ZERO, 0.0)
	# Different render grouping uses exactly the same fixed physics substeps.
	for frame in range(360):
		for substep in range(2):
			car.step(1.0 / 120.0, 1.0, 0.0, 0.35, false, false)
	for frame in range(180):
		for substep in range(4):
			other.step(1.0 / 120.0, 1.0, 0.0, 0.35, false, false)
	check(car.position.distance_to(other.position) < 0.00001 and car.velocity.distance_to(other.velocity) < 0.00001, "Fixed-step render grouping changed trajectory")
	car.reset_to(Vector3.ZERO, 0.0)
	other.reset_to(Vector3.ZERO, 0.0)
	simulate(car, 6.0, 1.0, 0.0, 0.0, false, false, "asphalt")
	simulate(other, 6.0, 1.0, 0.0, 0.0, false, false, "grass")
	check(car.speed > other.speed * 1.3, "Grass must reduce traction and add rolling resistance")
	car.velocity = Vector3(10.0, 0.0, -25.0)
	car.step(1.0 / 120.0, 0.0, 0.0, 0.0, false, false)
	check(car.lateral_slip > 0.0 and car.lateral_slip < 10.0, "Finite lateral tyre damping failed")
	car.reset_to(Vector3.ZERO, 0.0)
	simulate(car, 5.0, 1.0, 0.0, 0.0)
	car.step(1.0 / 120.0, 0.0, 0.0, 1.0, false, false)
	var low_angle: float = car.steer
	car.reset_to(Vector3.ZERO, 0.0)
	car.velocity = Vector3(0.0, 0.0, -60.0)
	car.step(1.0 / 120.0, 0.0, 0.0, 1.0, false, false)
	check(car.steer < low_angle, "High-speed steering limit failed")
	for tick in range(24000):
		car.step(1.0 / 120.0, 0.7, 0.0, sin(float(tick) / 370.0), false, tick % 1200 > 1000, "gravel" if tick % 8000 > 6000 else "asphalt")
	check(car.position.is_finite() and car.velocity.is_finite() and is_finite(car.rotation.y), "Stress simulation generated non-finite values")
	car.reset_to(Vector3(7.0, 10.0, 3.0), 1.2)
	check(car.position == Vector3(7.0, 0.0, 3.0) and car.velocity == Vector3.ZERO and car.gear == 1, "Reset did not clear all motion")
	# Weather affects finite friction, without treating wet asphalt as rough gravel.
	check(car.surface_grip("grass") < car.surface_grip("wet") and car.surface_grip("wet") < car.surface_grip("asphalt"), "Wet grip must lie between grass and dry asphalt")
	var dry_braking: float = braking_distance(car, "asphalt")
	var wet_braking: float = braking_distance(other, "wet")
	check(dry_braking > 20.0 and wet_braking > dry_braking * 1.2 and wet_braking < dry_braking * 1.5, "Wet 90-km/h braking distance is not longer but bounded")
	check(car.velocity.length() < 0.001 and other.velocity.length() < 0.001, "Wet/dry braking test did not finish at rest")
	car.reset_to(Vector3.ZERO, 0.0)
	other.reset_to(Vector3.ZERO, 0.0)
	simulate(car, 5.0, 1.0, 0.0, 0.0, false, false, "asphalt")
	simulate(other, 5.0, 1.0, 0.0, 0.0, false, false, "wet")
	check(car.speed > other.speed * 1.1 and other.speed > 5.0, "Wet acceleration must have lower finite traction")
	other.velocity = Vector3(10.0, 0.0, -25.0)
	other.step(1.0 / 120.0, 0.0, 0.0, 1.0, false, false, "wet")
	check(other.velocity.is_finite() and other.lateral_slip > 0.0 and other.lateral_slip < 10.0, "Wet lateral force became non-finite or reversed slip")
	var reference_ticks: int = render_grouping(car, 30)
	var reference_position: Vector3 = car.position
	var reference_velocity: Vector3 = car.velocity
	check(reference_ticks == 720, "30Hz render accumulator lost fixed simulation ticks")
	for render_hz in [60, 144]:
		var ticks: int = render_grouping(other, render_hz)
		check(ticks == 720 and other.position.distance_to(reference_position) < 0.00001 and other.velocity.distance_to(reference_velocity) < 0.00001, "%dHz rendering changed the 120Hz physics trajectory" % render_hz)
	print("WEATHER BRAKING: 90km/h dry=%.3fm wet=%.3fm; render groups30/60/144 at120Hz fixed" % [dry_braking, wet_braking])
	print("PHYSICS TESTS: %d checks, %d failures" % [checks, failures])
	quit(0 if failures == 0 else 1)
