extends SceneTree
var count:=0
func check(ok:bool,description:String):
 assert(ok,description)
 count+=1
func _initialize():
 var car=load('res://scripts/car_model.gd').new()
 root.add_child(car)
 await process_frame
 check(car.wheel_spinners.size()==4,'four wheels')
 car.update_visuals(10.0,.25,.0,4000.0,.1,false)
 check(car.wheel_spinners[0].rotation.x<0.0,'forward wheel rotation')
 check(is_equal_approx(car.wheel_mounts[0].rotation.y,.25),'front wheel steering')
 check(is_zero_approx(car.wheel_mounts[1].rotation.y),'rear wheel remains straight')
 car.wheel_angle=0.0
 car.update_visuals(-1.0,.0,1.0,1000.0,.1,true)
 check(car.wheel_spinners[0].rotation.x>0.0,'reverse wheel rotation')
 for i in range(10): car.update_visuals(0.0,.0,1.0,1000.0,.1,true)
 check(car.popup_amount==1.0,'popups open smoothly to limit')
 check(car.head_lights[0].visible,'open headlights cast light')
 check(car.brake_lenses[0].material_override==car.brake_on_mat,'brakes emissive while braking')
 var oldangle=car.wheel_spinners[0].rotation.x
 car.update_visuals(0.0,.0,.0,1000.0,.1,false)
 check(is_equal_approx(oldangle,car.wheel_spinners[0].rotation.x),'wheels stationary at zero speed')
 check(not car.head_lights[0].visible,'headlight off while closing')
 car.set_cockpit_mode(true)
 check(not car.cabin_glass[0].visible,'driver clear glass visibility')
 car.set_cockpit_mode(false)
 check(car.cabin_glass[0].visible,'exterior glass restored')
 print('CAR_VISUAL_LOGIC_CHECKS: ',count,' passed')
 quit()
