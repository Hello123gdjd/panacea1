extends SceneTree
const Atmosphere = preload("res://scripts/atmosphere.gd")
var count: int = 0
var failures: int = 0

func check(ok: bool, message: String) -> void:
	count += 1
	if not ok:
		failures += 1
		push_error("ATMOSPHERE: " + message)

func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	var atmosphere = Atmosphere.new()
	root.add_child(atmosphere)
	await process_frame
	check(is_instance_valid(atmosphere.sun) and is_instance_valid(atmosphere.world_environment), "sun/environment absent")
	check(atmosphere.world_environment.environment.background_mode == Environment.BG_SKY, "background does not use actual sky")
	check(atmosphere.sky_material.shader.code.contains("broad_cloud"), "cloud sky was not built")
	check(atmosphere.world_environment.environment.ambient_light_sky_contribution < 1.0, "ambient fill energy would be ignored with sky contribution one")
	check(atmosphere.world_environment.environment.ambient_light_color != Color.BLACK, "neutral ambient fill is absent")
	var day_direction: Vector3 = atmosphere.sun.basis.z
	var light_colors: Array[Color] = []
	for preset in range(3):
		atmosphere.set_time(preset)
		light_colors.append(atmosphere.sun.light_color)
		check(atmosphere.time_preset == preset, "preset selector did not apply")
		check(atmosphere.sun.light_energy > 0.2 and atmosphere.world_environment.environment.ambient_light_energy > 0.4, "preset loses usable direct/ambient lighting")
		var source: Vector3 = atmosphere.sky_material.get_shader_parameter("solar_direction")
		check(source.distance_to(atmosphere.sun.basis.z.normalized()) < 0.00001, "sky sun and scene sunlight point to different places")
	check(light_colors[0] != light_colors[1] and light_colors[1] != light_colors[2], "presets have identical illumination colors")
	check(day_direction.distance_to(atmosphere.sun.basis.z) > 0.1, "day and dusk have identical sun angle")
	atmosphere.set_anchor(Vector3(23, 0, 167))
	check(atmosphere.probe.position.distance_to(Vector3(23, 2.4, 167)) < 0.00001, "reflection anchor is incorrect")
	check(atmosphere.probe.cull_mask == 1 and atmosphere.probe.reflection_mask == 1048575, "car exclusion layer or receiving layers incorrect")
	check(atmosphere.probe.box_projection and atmosphere.probe.update_mode == ReflectionProbe.UPDATE_ONCE, "probe does not use static local box projection")
	var revision: int = atmosphere.probe.get_meta("capture_revision")
	atmosphere.set_time(0)
	check(atmosphere.probe.get_meta("capture_revision") > revision, "light change did not invalidate cubemap")
	for quality in range(3):
		atmosphere.set_quality(quality)
		check(atmosphere.sun.shadow_enabled == (quality > 0), "quality did not change actual sun shadow state")
		check(atmosphere.probe.visible == (quality > 0), "performance preset leaves local reflection capture enabled")
		check(atmosphere.world_environment.environment.ssao_enabled == (quality == 2), "SSAO is not restricted to High")
	atmosphere.set_quality(1)
	atmosphere.set_reflections(false)
	check(not atmosphere.probe.visible, "reflection checkbox does not disable probe")
	atmosphere.set_reflections(true)
	check(atmosphere.probe.visible, "reflection checkbox does not restore probe")
	atmosphere.set_time(99)
	check(atmosphere.time_preset == 2, "bad time input was not clamped")
	atmosphere.set_quality(-5)
	check(atmosphere.quality_level == 0, "bad quality input was not clamped")
	atmosphere.free()
	await process_frame
	print("ATMOSPHERE TESTS: %d checks, %d failures" % [count, failures])
	quit(0 if failures == 0 else 1)
