extends SceneTree
## Actual scene integration tests, with isolated writable user data.
## Run with CIRCUIT_QA_ISOLATED=1 and a separate XDG_DATA_HOME.

var game: Node3D
var checks: int = 0
var failures: int = 0
var had_settings: bool = false
var old_settings = PackedByteArray()


func check(condition: bool, message: String) -> void:
	checks += 1
	if not condition:
		failures += 1
		push_error("GAMEPLAY: " + message)


func key_event(code: Key, pressed: bool = true) -> InputEventKey:
	var event = InputEventKey.new()
	event.physical_keycode = code
	event.keycode = code
	event.pressed = pressed
	return event


func press(code: Key, pressed: bool = true) -> void:
	Input.parse_input_event(key_event(code, pressed))
	Input.flush_buffered_events()


func release_all() -> void:
	for code in [KEY_W, KEY_S, KEY_A, KEY_D, KEY_UP, KEY_DOWN, KEY_LEFT, KEY_RIGHT, KEY_SPACE]:
		press(code, false)


func tick(count: int) -> void:
	for i in range(count):
		game._physics_process(1.0 / 120.0)


func _initialize() -> void:
	if OS.get_environment("CIRCUIT_QA_ISOLATED") != "1":
		push_error("Use CIRCUIT_QA_ISOLATED=1 with separate XDG_DATA_HOME; this suite tests settings recovery.")
		quit(2)
		return
	call_deferred("run")


func run() -> void:
	had_settings = FileAccess.file_exists("user://settings.cfg")
	if had_settings:
		old_settings = FileAccess.get_file_as_bytes("user://settings.cfg")
	var invalid_types = ConfigFile.new()
	invalid_types.set_value("settings", "quality", "broken")
	invalid_types.set_value("settings", "fov", "not a number")
	invalid_types.set_value("settings", "steering", Vector3.ONE)
	invalid_types.set_value("records", "best", "not a lap")
	check(invalid_types.save("user://settings.cfg") == OK, "Could not prepare isolated wrong-type settings fixture")
	game = load("res://main.tscn").instantiate()
	root.add_child(game)
	game.set_physics_process(false)
	game.set_process(false)
	await process_frame
	check(is_instance_valid(game.car) and is_instance_valid(game.hud) and is_instance_valid(game.camera), "Actual main scene did not initialize its vehicle/HUD/camera")
	check(game.track.points.size() > 50 and game.model.wheel_spinners.size() == 4, "Actual scene is missing circuit geometry or wheels")
	check(game.settings.quality == 1 and game.settings.fov == 72.0 and game.settings.steering == 1.0, "Wrong-type settings were accepted instead of defaults")
	check(game.rules.best_time == 0.0, "Malformed saved best lap was accepted")
	check(not game.playing and game.hud.menu.visible, "New scene should begin paused in the start menu")

	release_all()
	game.hud.drive_requested.emit()
	check(game.playing and not game.hud.menu.visible, "Drive signal did not start the actual scene")
	var start_position: Vector3 = game.car.position
	press(KEY_W)
	check(Input.is_physical_key_pressed(KEY_W), "Synthetic physical throttle event did not reach Input")
	tick(240)
	check(game.car.speed > 1.0 and game.car.position.distance_to(start_position) > 1.0, "Keyboard throttle failed to move the actual scene vehicle")
	check(game.rules.lap_time > 0.5, "Moving the actual vehicle did not start its lap timer")
	var wheel_before: float = game.model.wheel_angle
	game._process(1.0 / 120.0)
	check(absf(game.model.wheel_angle - wheel_before) > 0.0001, "Moving vehicle did not animate wheel rotation")
	game._pause()
	Input.flush_buffered_events()
	await process_frame
	var paused_position: Vector3 = game.car.position
	var paused_lap_time: float = game.rules.lap_time
	var paused_wheel: float = game.model.wheel_angle
	tick(360)
	game._process(0.5)
	check(not game.playing and game.hud.menu.visible, "Pause did not show the actual scene menu")
	check(game.car.position.distance_to(paused_position) < 0.00001 and is_equal_approx(game.rules.lap_time, paused_lap_time), "Paused simulation or lap timer continued advancing")
	check(is_equal_approx(game.model.wheel_angle, paused_wheel), "Paused visual wheels continued spinning")
	check(not Input.is_physical_key_pressed(KEY_W), "Pause did not release the held throttle key")
	game.hud.resume_requested.emit()
	check(game.playing and not game.hud.menu.visible, "Resume signal did not continue the actual scene")
	press(KEY_W)
	press(KEY_A)
	tick(30)
	game._notification(Node.NOTIFICATION_APPLICATION_FOCUS_OUT)
	Input.flush_buffered_events()
	check(not game.playing and game.hud.menu.visible, "Losing application focus did not pause the actual game")
	check(not Input.is_physical_key_pressed(KEY_W) and not Input.is_physical_key_pressed(KEY_A), "Focus loss left held throttle/steering keys stuck")

	game.reverse_selected = true
	game.model.rotation = Vector3(0.1, 0, 0.1)
	game.hud.reset_requested.emit()
	var grid: Dictionary = game.track.sample_at(0.0)
	check(game.car.position.distance_to(grid.position) < 0.001 and (-game.car.basis.z).dot(grid.forward) > 0.999, "Reset did not return to the correct grid position/direction")
	check(is_zero_approx(game.car.speed) and game.car.velocity.length() == 0.0 and not game.reverse_selected, "Reset left motion or reverse selection active")
	check(game.rules.lap_time == 0.0 and game.rules.next_gate == 1 and game.rules.valid, "Reset retained partial lap/timing state")
	check(game.model.rotation.length() < 0.00001 and game.camera.global_position.is_finite(), "Reset left body rotation or invalid camera state")
	game._start()
	press(KEY_W)
	press(KEY_S)
	press(KEY_A)
	press(KEY_D)
	tick(120)
	check(absf(game.car.speed) < 0.01 and game.car.position.distance_to(grid.position) < 0.01, "Simultaneous gas/brake caused unintended acceleration")
	check(absf(game.car.steer) < 0.001, "Simultaneous left/right keys did not cancel steering")
	release_all()

	for mode in range(4):
		game.camera_mode = mode
		game._update_camera(1.0 / 120.0, true)
		game._process(1.0 / 120.0)
		check(game.camera.global_position.is_finite() and game.camera.global_transform.basis.is_finite() and game.camera.global_position.y >= 0.45, "Camera %d has nonfinite transform or is below its ground limit" % mode)
	check(game.model.cockpit_active, "Cockpit camera did not switch the model's interior visibility mode")
	game._unhandled_key_input(key_event(KEY_C))
	game._process(1.0 / 120.0)
	check(game.camera_mode == 0 and not game.model.cockpit_active, "Camera key did not cycle from cockpit back to chase")
	game._unhandled_key_input(key_event(KEY_L))
	game._process(0.6)
	check(game.lamps_on and game.model.popup_amount > 0.99 and game.model.head_lights[0].visible, "Headlight key failed to open popups and enable the light")
	game._unhandled_key_input(key_event(KEY_L))
	game._process(0.6)
	check(not game.lamps_on and game.model.popup_amount < 0.01 and not game.model.head_lights[0].visible, "Headlights failed to close and switch off")
	game._unhandled_key_input(key_event(KEY_Q))
	press(KEY_W)
	tick(180)
	check(game.reverse_selected and game.car.gear < 0 and game.car.speed < -0.5, "Reverse selection plus throttle did not move the car backward")
	release_all()
	game._reset()

	for level in range(3):
		game.hud.setting_changed.emit("quality", level)
		var expected_msaa = [Viewport.MSAA_DISABLED, Viewport.MSAA_2X, Viewport.MSAA_4X][level]
		check(game.get_viewport().msaa_3d == expected_msaa and game.sun.shadow_enabled == (level != 0), "Quality preset %d did not change actual MSAA/shadows" % level)
	game.hud.setting_changed.emit("volume", 0.0)
	check(AudioServer.get_bus_volume_db(0) <= -79.9, "Zero volume did not attenuate the actual audio bus")
	game.hud.setting_changed.emit("volume", 100.0)
	check(is_zero_approx(AudioServer.get_bus_volume_db(0)), "Full volume did not restore the actual audio bus")
	game.hud.setting_changed.emit("steering", 1.4)
	check(is_equal_approx(game.car.steering_sensitivity, 1.4), "Steering setting did not reach the vehicle")
	game.hud.setting_changed.emit("fov", 80.0)
	game.camera_mode = 0
	game._update_camera(1.0 / 120.0, true)
	check(is_equal_approx(game.camera.fov, 80.0), "Field-of-view setting did not reach the camera")
	game.hud.setting_changed.emit("speed_fov", true)
	game.car.speed = 60.0
	game._update_camera(1.0 / 120.0, true)
	check(is_equal_approx(game.camera.fov, 85.0), "Speed field-of-view setting did not produce its bounded effect")
	game.hud.setting_changed.emit("motion", true)
	game.car.yaw_rate = 1.0
	game._update_camera(1.0 / 120.0, true)
	var moving_roll: float = absf(game.camera.rotation.z)
	game.hud.setting_changed.emit("motion", false)
	game._update_camera(1.0 / 120.0, true)
	check(moving_roll > 0.001 and absf(game.camera.rotation.z) < 0.00001, "Disabling camera motion did not remove the limited roll")
	var signals = [0]
	game.hud.setting_changed.connect(func(_key, _value): signals[0] += 1)
	game.hud.apply_settings(game.settings)
	check(signals[0] == 0 and game.hud.setting_controls.quality.selected == 2, "Loading saved UI settings emitted change events or left controls unsynchronized")
	check(FileAccess.file_exists("user://settings.cfg"), "Settings actions did not create the user settings file")
	var config_check = ConfigFile.new()
	check(config_check.load("user://settings.cfg") == OK and config_check.get_value("settings", "fov", 0.0) == 80.0, "Saved settings cannot be parsed or did not preserve the chosen value")

	var corrupt = FileAccess.open("user://settings.cfg", FileAccess.WRITE)
	corrupt.store_string("[settings\nnot valid config!!!")
	corrupt.close()
	print("EXPECTED_CORRUPT_CONFIG_BEGIN: testing parser failure recovery; the next ConfigFile parse message is intentional")
	game._load_settings()
	print("EXPECTED_CORRUPT_CONFIG_END: application continued after corrupt file")
	check(is_instance_valid(game.car) and game.settings.fov == 80.0, "Corrupt settings load damaged the running scene or its usable settings")
	game._reset()
	check(game.car.position.is_finite() and game.rules.valid, "The scene cannot reset after corrupt settings recovery")
	for i in range(30):
		game.camera_mode = i % 4
		game._reset()
		game._update_camera(1.0 / 120.0, true)
	check(game.car.position.distance_to(grid.position) < 0.001 and game.camera.global_position.is_finite(), "Repeated reset/camera cycling produced unstable state")
	game._pause()
	release_all()
	game.free()
	# Audio stop/free commands are consumed asynchronously by the mix thread.
	await create_timer(0.6).timeout
	if had_settings:
		var restore = FileAccess.open("user://settings.cfg", FileAccess.WRITE)
		restore.store_buffer(old_settings)
		restore.close()
	else:
		DirAccess.remove_absolute(ProjectSettings.globalize_path("user://settings.cfg"))
	print("GAMEPLAY TESTS: %d checks, %d failures | actual main scene | synthetic physical input | headless, no visual/Windows claims" % [checks, failures])
	quit(0 if failures == 0 else 1)
