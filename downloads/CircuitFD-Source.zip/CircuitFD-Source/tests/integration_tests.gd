extends SceneTree

const VehicleScript = preload("res://scripts/vehicle.gd")
const TrackScript = preload("res://scripts/track.gd")
const RulesScript = preload("res://scripts/race_rules.gd")
const MainScript = preload("res://scripts/main.gd")
var checks: int = 0
var failures: int = 0

func check(condition: bool, message: String) -> void:
	checks += 1
	if not condition:
		failures += 1
		push_error(message)

func _initialize() -> void:
	var track = TrackScript.new()
	track._make_path()
	check(track.total_length > 1000.0 and track.points.size() > 400, "Circuit path missing or implausibly short")
	var largest_error: float = 0.0
	var largest_distance: float = 0.0
	var rules = RulesScript.new()
	rules.reset(track.total_length)
	var did_complete: bool = false
	# A geometric centreline traversal validates real path projection and gate wrapping.
	var path_steps: int = ceili(track.total_length / 2.0)
	for i in range(1, path_steps + 1):
		var distance: float = minf(float(i) * 2.0, track.total_length)
		var sample: Dictionary = track.sample_at(distance)
		var nearest: Dictionary = track.nearest(sample.position)
		var progress_error: float = absf(wrapf(nearest.progress - sample.progress, -track.total_length * 0.5, track.total_length * 0.5))
		largest_error = maxf(largest_error, progress_error)
		largest_distance = maxf(largest_distance, nearest.distance)
		if rules.tick(0.1, nearest.progress, nearest.distance <= track.road_half_width + 0.9, true, true):
			did_complete = true
	check(largest_error < 0.01 and largest_distance < 0.01, "Track sample/nearest projection disagrees")
	check(did_complete and rules.completed_laps == 1, "Real circuit centreline could not register a valid ordered lap")
	var car = VehicleScript.new()
	root.add_child(car)
	var game = MainScript.new()
	game.track = track
	game.car = car
	var start: Dictionary = track.sample_at(20.0)
	var outward: Vector3 = start.forward.cross(Vector3.UP).normalized()
	car.reset_to(start.position + outward * (track.barrier_offset + 9.0), start.yaw)
	car.velocity = outward * 90.0
	game._enforce_barrier(track.nearest(car.position), 1.0 / 120.0)
	var after_collision: Dictionary = track.nearest(car.position)
	check(after_collision.distance <= track.barrier_offset - 0.88, "High-speed barrier correction leaves car envelope beyond barrier")
	check(car.velocity.dot(outward) <= 0.0 and car.velocity.length() < 90.0, "Barrier impact did not remove outward speed/energy")
	check(not game.rules.valid and game.collision_cooldown > 0.0, "Barrier collision did not invalidate lap or signal impact")
	var after_first: Vector3 = car.position
	for i in range(500):
		game._enforce_barrier(track.nearest(car.position), 1.0 / 120.0)
	check(car.position.distance_to(after_first) < 0.001, "Repeated barrier contact generated positional jitter")
	car.reset_to(start.position + outward * (track.barrier_offset + 2.0), start.yaw)
	car.velocity = -outward * 4.0
	game._enforce_barrier(track.nearest(car.position), 1.0 / 120.0)
	check(car.velocity.dot(outward) < -3.9, "Barrier correction incorrectly rejected inward recovery motion")
	car.reset_to(start.position + outward * (track.barrier_offset + 3.0), start.yaw + PI * 0.5)
	car.velocity = outward * 60.0
	game._enforce_barrier(track.nearest(car.position), 1.0 / 120.0)
	var nose_contact: Dictionary = track.nearest(car.position)
	var normal: Vector3 = (car.position - nose_contact.position).normalized()
	var projected_half_extent: float = absf(normal.dot(-car.basis.z)) * 2.15 + absf(normal.dot(car.basis.x)) * 0.90
	check(nose_contact.distance + projected_half_extent <= track.barrier_offset, "Perpendicular impact leaves the nose beyond the barrier")
	var start_zero: Dictionary = track.sample_at(0.0)
	car.reset_to(start_zero.position, start_zero.yaw)
	check(car.position.distance_to(start_zero.position) < 0.01 and (-car.basis.z).dot(start_zero.forward) > 0.999, "Reset grid heading points against circuit direction")
	var zero: Dictionary = track.sample_at(0.0)
	var wrap: Dictionary = track.sample_at(track.total_length)
	check(zero.position.distance_to(wrap.position) < 0.001, "Circuit finish seam is discontinuous")
	track.free()
	game.free()
	car.free()
	print("INTEGRATION TESTS: %d checks, %d failures | path_projection_error_m=%.6f" % [checks, failures, largest_error])
	quit(0 if failures == 0 else 1)
