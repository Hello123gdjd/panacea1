extends SceneTree

const RulesScript = preload("res://scripts/race_rules.gd")
var checks: int = 0
var failures: int = 0

func check(condition: bool, message: String) -> void:
	checks += 1
	if not condition:
		failures += 1
		push_error(message)

func lap(rules: RefCounted, offtrack_at: int = -1, tick_time: float = 0.1) -> bool:
	var completed: bool = false
	for sample in range(1, 161):
		var progress: float = fposmod(float(sample) * 5.0, 800.0)
		if rules.tick(tick_time, progress, sample != offtrack_at, true, true):
			completed = true
	return completed

func _initialize() -> void:
	var rules = RulesScript.new()
	rules.reset(800.0)
	for tick in range(120):
		rules.tick(1.0 / 120.0, 0.0, true, false, false)
	check(not rules.running and rules.lap_time == 0.0, "Timer started before motion")
	check(lap(rules), "Ordered on-course 16-second lap was not accepted")
	check(rules.completed_laps == 1 and rules.best_time > 15.9 and rules.best_time < 16.1, "Valid lap count or best time incorrect")
	check(rules.next_gate == 1 and rules.valid and rules.lap_time == 0.0, "Finish did not start a clean lap")
	check(lap(rules, -1, 0.12), "A slower valid lap was rejected")
	check(rules.completed_laps == 2 and rules.best_time < 16.1, "Slower lap incorrectly replaced best")
	check(lap(rules, -1, 0.08), "A faster valid lap was rejected")
	check(rules.best_time > 12.7 and rules.best_time < 12.9, "Faster lap did not replace best")
	rules = RulesScript.new()
	rules.reset(800.0)
	check(not lap(rules, 75), "Off-track lap was accepted")
	check(rules.completed_laps == 0 and rules.best_time == 0.0, "Off-track lap updated lap count or record")
	check(rules.next_gate == 1 and rules.valid, "Finishing a discarded lap did not permit a fresh lap")
	check(lap(rules), "A fresh valid lap after discarded lap failed")
	rules = RulesScript.new()
	rules.reset(800.0)
	rules.tick(0.1, 120.0, true, true, true)
	check(not rules.valid and rules.next_gate == 1, "Teleport/sector skip was accepted")
	for sample in range(25, 161):
		rules.tick(0.1, fposmod(float(sample) * 5.0, 800.0), true, true, true)
	check(rules.completed_laps == 0, "Skipped first sector still counted a lap")
	rules = RulesScript.new()
	rules.reset(800.0)
	for sample in range(1, 20):
		rules.tick(0.1, float(sample) * 5.0, true, true, true)
	rules.tick(0.1, 101.0, true, false, true)
	check(rules.next_gate == 1, "Wrong-direction checkpoint crossing advanced the sector")
	rules = RulesScript.new()
	rules.reset(800.0)
	rules.next_gate = 8
	rules.last_progress = 798.0
	rules.lap_time = 20.0
	rules.running = true
	check(not rules.tick(0.1, 2.0, true, false, true) and rules.completed_laps == 0, "Wrong-direction finish counted a lap")
	rules = RulesScript.new()
	rules.reset(800.0)
	rules.next_gate = 8
	rules.last_progress = 798.0
	rules.lap_time = 20.0
	rules.running = true
	check(rules.tick(0.1, 2.0, true, true, true), "Legitimate forward finish wrap was not accepted")
	rules = RulesScript.new()
	rules.reset(800.0)
	check(not lap(rules, -1, 0.02), "Implausibly short lap was accepted")
	check(rules.best_time == 0.0, "Implausibly short lap set a record")
	rules = RulesScript.new()
	rules.reset(800.0)
	for sample in range(1, 15):
		rules.tick(0.1, float(sample) * 5.0, true, true, true)
	var previous_time: float = rules.lap_time
	rules.tick(1.0, 70.0, true, false, false)
	check(rules.lap_time > previous_time + 0.99, "Lap clock must continue while stopped during an active lap")
	rules.valid = false
	rules.reset(800.0, 31.25)
	check(rules.next_gate == 1 and rules.last_progress == 0.0 and rules.lap_time == 0.0 and not rules.running and rules.valid, "Reset retained a partial lap or invalid state")
	check(rules.best_time == 31.25, "Reset failed to preserve supplied best time")
	print("RACE TESTS: %d checks, %d failures" % [checks, failures])
	quit(0 if failures == 0 else 1)
