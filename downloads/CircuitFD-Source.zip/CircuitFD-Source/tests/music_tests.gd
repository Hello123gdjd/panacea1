extends SceneTree
## Runtime audio decode/transport tests. Dummy audio cannot validate listening quality.
const Deck = preload("res://scripts/music_deck.gd")
const FIXTURES: Array[String] = ["res://tests/fixtures/music-tone.wav", "res://tests/fixtures/music-tone.ogg", "res://tests/fixtures/music-tone.mp3"]
var deck: CanvasLayer
var checks: int = 0
var failures: int = 0
var had_library: bool = false
var old_library: PackedByteArray

func check(condition: bool, message: String) -> void:
	checks += 1
	if not condition:
		failures += 1
		push_error("MUSIC TEST: " + message)

func _initialize() -> void:
	if OS.get_environment("CIRCUIT_QA_ISOLATED") != "1":
		push_error("Use CIRCUIT_QA_ISOLATED=1 and isolated XDG user data for the music suite.")
		quit(2)
		return
	call_deferred("run")

func run() -> void:
	had_library = FileAccess.file_exists(Deck.SAVE_PATH)
	if had_library: old_library = FileAccess.get_file_as_bytes(Deck.SAVE_PATH)
	var corrupt = FileAccess.open(Deck.SAVE_PATH, FileAccess.WRITE)
	corrupt.store_string("{ not valid JSON")
	corrupt.close()
	deck = Deck.new()
	root.add_child(deck)
	await process_frame
	check(deck.playlist.size() == 1 and deck.playlist[0].path == Deck.DEMO_PATH, "Corrupt library did not fall back to original demo")
	check(not deck.is_music_playing() and not deck.is_panel_open(), "Music or modal panel starts automatically")
	check(deck.get_current_title().contains("Music Deck"), "Empty transport title is missing")
	var closed: Array[int] = [0]
	deck.panel_closed.connect(func(): closed[0] += 1)
	deck.show_panel()
	check(deck.is_panel_open(), "Show panel failed")
	deck.hide_panel()
	check(not deck.is_panel_open() and closed[0] == 1, "Hide panel did not emit its close signal")
	deck.hide_panel()
	check(closed[0] == 1, "Hiding an already hidden panel emits duplicate close")
	for path in FIXTURES:
		check(deck.add_track(path), "Runtime decoder cannot add " + path.get_extension())
	check(deck.playlist.size() == 4, "Not all three supported formats reached the playlist")
	check(not deck.add_track(FIXTURES[0]), "Duplicate file was accepted")
	check(not deck.add_track("/tmp/circuit-fd-missing-audio.wav"), "Missing file was accepted")
	check(not deck.add_track("https://example.com/music.mp3"), "Network stream accepted despite local-only policy")
	var invalid = FileAccess.open("user://invalid-audio.wav", FileAccess.WRITE)
	invalid.store_string("A deliberately invalid file, no audio header.")
	invalid.close()
	check(not deck.add_track("user://invalid-audio.wav"), "Invalid audio header was accepted")
	check(not deck.play_index(-1) and not deck.play_index(500), "Out-of-range playlist index was accepted")
	deck.previous_track()
	check(deck.current_index == 3, "Previous with no active track did not select the last item")
	check(deck.play_index(0), "Bundled original demo failed to play")
	await process_frame
	check(deck.is_music_playing() and deck.duration() > 38.0, "Original demo playback/duration is wrong")
	check(deck.get_current_title().contains("Afterhours"), "Now-playing title does not reflect current track")
	deck.pause_playback()
	check(not deck.is_music_playing() and deck.player.stream_paused, "Pause failed")
	check(deck.seek_to(4.0), "Paused seek failed")
	deck.toggle_playback()
	await create_timer(0.06).timeout
	check(deck.is_music_playing(), "Toggle did not resume paused track")
	check(deck.player.get_playback_position() >= 3.9, "Real audio transport did not seek to the requested time")
	check(deck.seek_to(-10.0), "Negative seek was not safely clamped")
	check(deck.seek_to(10000.0), "Oversized seek was not safely clamped")
	var master: float = AudioServer.get_bus_volume_db(0)
	deck.set_volume(0.0)
	check(AudioServer.get_bus_volume_db(AudioServer.get_bus_index("Music")) <= -79.9, "Music mute did not affect its bus")
	check(is_equal_approx(AudioServer.get_bus_volume_db(0), master), "Music volume changed the master/engine volume")
	deck.set_volume(180.0)
	check(deck.music_volume == 100.0, "Music volume did not clamp to its upper limit")
	deck.set_volume(38.0)
	for index in range(1, 4):
		check(deck.play_index(index), "Runtime playback failed for supported format index " + str(index))
		check(deck.duration() > 0.7 and deck.duration() < 1.1, "Runtime decoded duration incorrect for index " + str(index))
	deck.play_index(0)
	deck.next_track()
	check(deck.current_index == 1, "Next track order incorrect")
	deck.previous_track()
	check(deck.current_index == 0, "Previous track order incorrect")
	deck.set_repeat_mode(2)
	deck._on_finished()
	check(deck.current_index == 0 and deck.is_music_playing(), "Repeat-one failed")
	deck.set_repeat_mode(1)
	deck.play_index(3)
	deck._on_finished()
	check(deck.current_index == 0, "Repeat-all did not wrap to start")
	deck.set_repeat_mode(0)
	deck.play_index(3)
	deck._on_finished()
	check(not deck.is_music_playing(), "Repeat-off did not stop after last track")
	deck.set_shuffle(true)
	var skips_valid: bool = true
	for _i in range(6):
		var previous: int = deck.current_index
		deck.next_track()
		skips_valid = skips_valid and deck.current_index != previous and deck.current_index >= 0 and deck.current_index < 4
	check(skips_valid, "Shuffle selected the same track or an invalid index")
	deck.remove_track(deck.current_index)
	check(deck.current_index == -1 and not deck.player.stream and not deck.is_music_playing(), "Removing current track did not release transport")
	deck.set_repeat_mode(2)
	deck.set_shuffle(false)
	deck.save_library()
	deck.load_library()
	check(deck.playlist.size() == 3 and deck.current_index == -1, "Saved library did not restore without autoplay")
	check(deck.music_volume == 38.0 and deck.repeat_mode == 2 and not deck.shuffle, "Music settings did not persist")
	var damaged = FileAccess.open(Deck.SAVE_PATH, FileAccess.WRITE)
	damaged.store_string('{"volume":"bad","repeat":null,"shuffle":5,"tracks":[false,{}, {"path": 7}]}')
	damaged.close()
	deck.load_library()
	check(deck.playlist.size() == 1 and deck.playlist[0].path == Deck.DEMO_PATH, "Wrong-type JSON library damaged fallback state")
	deck.shutdown()
	check(not deck.player.playing and not deck.player.stream, "Shutdown left audio active")
	deck.free()
	await create_timer(0.65).timeout
	if had_library:
		var restore = FileAccess.open(Deck.SAVE_PATH, FileAccess.WRITE)
		restore.store_buffer(old_library)
		restore.close()
	else:
		DirAccess.remove_absolute(ProjectSettings.globalize_path(Deck.SAVE_PATH))
	DirAccess.remove_absolute(ProjectSettings.globalize_path("user://invalid-audio.wav"))
	print("MUSIC TESTS: %d checks, %d failures | actual WAV/OGG/MP3 decode | Dummy audio, no listening claim" % [checks, failures])
	quit(0 if failures == 0 else 1)
