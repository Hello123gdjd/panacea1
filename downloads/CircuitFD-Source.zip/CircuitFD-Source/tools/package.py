#!/usr/bin/env python3
"""Package the existing verified Windows export and complete editable project."""
from pathlib import Path
import hashlib
import json
import struct
import zipfile

project = Path(__file__).resolve().parent.parent
artifacts = project / "artifacts"
exe = artifacts / "CircuitFD.exe"
data = exe.read_bytes()
pe = struct.unpack_from("<I", data, 0x3C)[0]
assert data[:2] == b"MZ" and data[pe:pe + 4] == b"PE\0\0", "Not a PE executable"
assert struct.unpack_from("<H", data, pe + 4)[0] == 0x8664, "Not x64"
assert b"GDPC" in data[-32:], "Missing embedded PCK"

skip = {".git", ".godot", ".runtime", "artifacts", "builds", "__pycache__", "export_templates", "feature_profiles", "script_templates", "text_editor_themes"}
source_files = []
for path in sorted(project.rglob("*")):
    relative = path.relative_to(project)
    if any(part in skip for part in relative.parts) or not path.is_file():
        continue
    assert path.resolve().is_relative_to(project), f"External symlink: {relative}"
    source_files.append(path)

with zipfile.ZipFile(artifacts / "CircuitFD-Source.zip", "w", zipfile.ZIP_DEFLATED, compresslevel=8) as archive:
    for path in source_files:
        archive.write(path, Path("CircuitFD-Source") / path.relative_to(project))

with zipfile.ZipFile(artifacts / "CircuitFD-Windows-x64.zip", "w", zipfile.ZIP_DEFLATED, compresslevel=8) as archive:
    archive.write(exe, "CircuitFD/CircuitFD.exe")
    for path in source_files:
        rel = path.relative_to(project)
        if (len(rel.parts) == 1 and (path.suffix == ".md" or path.name.startswith("LICENSE"))) or rel.parts[0] == "docs":
            archive.write(path, Path("CircuitFD") / rel)

records = {}
for name in ["CircuitFD.exe", "CircuitFD-Windows-x64.zip", "CircuitFD-Source.zip"]:
    path = artifacts / name
    records[name] = {"size_bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
(artifacts / "package-manifest.json").write_text(json.dumps(records, indent=2) + "\n", encoding="utf-8")
for name, metadata in records.items():
    print(f"{name}: {metadata['size_bytes']:,} bytes, SHA256 {metadata['sha256']}")
