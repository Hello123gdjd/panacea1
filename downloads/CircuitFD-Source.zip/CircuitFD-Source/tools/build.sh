#!/usr/bin/env bash
set -euo pipefail
project_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
godot_bin=${GODOT_BIN:-godot}
# Use prepared cloud tools when present; otherwise honor the normal Godot installation.
if [[ -d /workspace/.game-tools/data/godot/export_templates/4.6.3.stable ]]; then
  export XDG_CACHE_HOME=${XDG_CACHE_HOME:-/workspace/.game-tools/cache}
  export XDG_DATA_HOME=${XDG_DATA_HOME:-/workspace/.game-tools/data}
  export XDG_CONFIG_HOME=${XDG_CONFIG_HOME:-/workspace/.game-tools/config}
  mkdir -p "$XDG_CACHE_HOME" "$XDG_DATA_HOME" "$XDG_CONFIG_HOME"
fi
mkdir -p "$project_dir/artifacts"
run_checked() {
  local stage=$1
  shift
  local result=0
  "$@" > "$project_dir/artifacts/build-$stage.log" 2>&1 || result=$?
  cat "$project_dir/artifacts/build-$stage.log"
  # Godot may exit successfully even after a GDScript parse error.
  if (( result != 0 )); then return "$result"; fi
  if grep -Eq 'SCRIPT ERROR:|(^|[[:space:]])ERROR:' "$project_dir/artifacts/build-$stage.log"; then
    printf 'Build stage %s reported an engine/script error.\n' "$stage" >&2
    return 1
  fi
}
run_checked import "$godot_bin" --headless --path "$project_dir" --editor --import --quit
run_checked export "$godot_bin" --headless --path "$project_dir" --export-release 'Windows Desktop' "$project_dir/artifacts/CircuitFD.exe"
python3 - "$project_dir/artifacts/CircuitFD.exe" <<'PY'
import struct,sys
from pathlib import Path
p=Path(sys.argv[1]); data=p.read_bytes()
assert data[:2]==b'MZ','Missing DOS executable header'
pe=struct.unpack_from('<I',data,0x3c)[0]
assert data[pe:pe+4]==b'PE\0\0','Missing PE header'
assert struct.unpack_from('<H',data,pe+4)[0]==0x8664,'Executable is not x86-64'
assert struct.unpack_from('<H',data,pe+24)[0]==0x20b,'Executable is not PE32+'
assert b'GDPC' in data[-32:],'Embedded Godot PCK footer not found'
print(f'Verified PE32+ Windows x64 with embedded PCK: {p.name} ({len(data):,} bytes)')
PY
