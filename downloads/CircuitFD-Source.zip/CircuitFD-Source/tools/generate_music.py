#!/usr/bin/env python3
"""Generate Circuit FD's original 38.4 s instrumental. No sampled/copyrighted audio.

The composition and synthesis code are original project assets covered by the
project MIT license. This is a small synth sketch, not an RX-7 engine recording.
"""
from pathlib import Path
import math
import random
import struct
import wave

RATE = 22050
BPM = 100
BEAT = 60 / BPM
SECONDS = 64 * BEAT
OUT = Path(__file__).resolve().parents[1] / "assets/audio/afterhours.wav"
OUT.parent.mkdir(parents=True, exist_ok=True)
rng = random.Random(1024)
chords = [(220., 261.6256, 329.6276), (174.6141, 220., 261.6256),
          (130.8128, 164.8138, 195.9977), (195.9977, 246.9417, 293.6648)]
audio = []
noise_state = 0.
for i in range(round(RATE * SECONDS)):
    t = i / RATE
    beat = t / BEAT
    beat_i = int(beat)
    in_beat = (beat - beat_i) * BEAT
    chord = chords[(beat_i // 8) % 4]
    # Warm, slowly modulated triad; additive harmonics avoid harsh aliasing.
    pad = 0.
    for n, f in enumerate(chord):
        phase = math.tau * f * t
        pad += (math.sin(phase) + .22 * math.sin(phase * 2) + .08 * math.sin(phase * 3)) * (.020 + .005 * math.sin(t * .7 + n))
    pad *= .68 + .32 * min(1., in_beat / .16)
    # Sub/bass rhythm with a restrained, round decay.
    bass_f = chord[0] / 2
    bass = (.10 * math.sin(math.tau * bass_f * t) + .025 * math.sin(math.tau * bass_f * 2 * t)) * math.exp(-in_beat * 4.0)
    # Original repeating arpeggio, step changes receive a smooth attack.
    half = beat * 2
    step = int(half)
    pluck_age = (half - step) * BEAT * .5
    note = chord[[0, 2, 1, 2, 0, 1, 2, 1][step % 8]] * (2 if step % 16 < 8 else 4)
    pluck = math.sin(math.tau * note * pluck_age) * .075 * min(1., pluck_age / .010) * math.exp(-pluck_age * 13)
    # Kick, clap and eighth-note hats are synthesized, never sampled.
    kick = 0.
    if beat_i % 2 == 0 and in_beat < .28:
        phase = math.tau * (45 * in_beat + 28 * .035 * (1 - math.exp(-in_beat / .035)))
        kick = math.sin(phase) * .21 * math.exp(-in_beat * 17)
    white = rng.uniform(-1, 1)
    noise_state = noise_state * .65 + white * .35
    high = white - noise_state
    clap = noise_state * .12 * math.exp(-in_beat * 28) if beat_i % 4 in (1, 3) else 0.
    hat = high * .025 * math.exp(-pluck_age * 85)
    fade = min(1., t / .025, (SECONDS - t) / .025)
    audio.append((pad + bass + pluck + kick + clap + hat) * fade)
peak = max(abs(x) for x in audio)
gain = min(1., .78 / peak)
with wave.open(str(OUT), "wb") as stream:
    stream.setnchannels(1)
    stream.setsampwidth(2)
    stream.setframerate(RATE)
    stream.writeframes(b"".join(struct.pack("<h", round(x * gain * 32767)) for x in audio))
print(f"Original Afterhours: {SECONDS:.1f}s, PCM16 mono {RATE}Hz, peak={peak*gain:.3f}, {OUT.stat().st_size:,} bytes")
