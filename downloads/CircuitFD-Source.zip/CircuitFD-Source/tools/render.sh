#!/usr/bin/env bash
set -euo pipefail
# This helper supports Linux software-rendered validation. It is not needed by Windows players.
xvfb_bin=${XVFB_BIN:-/workspace/.game-tools/root/usr/bin/Xvfb}
export XDG_CACHE_HOME=${XDG_CACHE_HOME:-/workspace/.game-tools/cache}
export XDG_DATA_HOME=${XDG_DATA_HOME:-/workspace/.game-tools/data}
export XDG_CONFIG_HOME=${XDG_CONFIG_HOME:-/workspace/.game-tools/config}
mkdir -p "$XDG_CACHE_HOME" "$XDG_DATA_HOME" "$XDG_CONFIG_HOME"
export LIBGL_ALWAYS_SOFTWARE=1
export DISPLAY=:91
"$xvfb_bin" "$DISPLAY" -screen 0 1600x1000x24 -nolisten tcp -ac > /workspace/.game-tools/xvfb.log 2>&1 &
xvfb_pid=$!
trap 'kill "$xvfb_pid" 2>/dev/null || true' EXIT
for attempt in {1..40}; do
  if xdpyinfo -display "$DISPLAY" >/dev/null 2>&1; then
    "$@"
    exit $?
  fi
  sleep 0.1
done
cat /workspace/.game-tools/xvfb.log >&2
exit 1
