#!/usr/bin/env bash
set -euo pipefail
project_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
godot_bin=${GODOT_BIN:-godot}
qa_root=${CIRCUIT_QA_ROOT:-/tmp/circuit-fd-qa}
export XDG_DATA_HOME="$qa_root/data"
export XDG_CONFIG_HOME="$qa_root/config"
export XDG_CACHE_HOME="$qa_root/cache"
export CIRCUIT_QA_ISOLATED=1
mkdir -p "$XDG_DATA_HOME" "$XDG_CONFIG_HOME" "$XDG_CACHE_HOME" "$project_dir/artifacts"
for suite in physics_tests race_tests car_visual_tests integration_tests route_tests gameplay_tests; do
  log="$project_dir/artifacts/$suite.log"
  "$godot_bin" --headless --audio-driver Dummy --path "$project_dir" --script "res://tests/$suite.gd" > "$log" 2>&1
  cat "$log"
  python3 - "$log" <<'PY'
import sys
from pathlib import Path
text=Path(sys.argv[1]).read_text()
expected=False
for line in text.splitlines():
    if line.startswith('EXPECTED_CORRUPT_CONFIG_BEGIN:'): expected=True
    if line.startswith('EXPECTED_CORRUPT_CONFIG_END:'): expected=False
    if 'SCRIPT ERROR:' in line or ('ERROR:' in line and not expected):
        raise SystemExit('Unexpected engine/script error: '+line)
if expected:
    raise SystemExit('Corrupt-config test did not return from expected failure')
PY
done
"$godot_bin" --headless --audio-driver Dummy --path "$project_dir" -- --smoke-test > "$project_dir/artifacts/scene-smoke.log" 2>&1
cat "$project_dir/artifacts/scene-smoke.log"
rg -q 'SCENE SMOKE PASS' "$project_dir/artifacts/scene-smoke.log"
if rg -q 'SCRIPT ERROR:|^ERROR:' "$project_dir/artifacts/scene-smoke.log"; then exit 1; fi
printf '\nAll six test suites and the scene smoke check completed.\n'
