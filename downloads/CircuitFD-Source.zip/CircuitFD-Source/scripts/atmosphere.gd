class_name CircuitAtmosphere
extends Node3D
## Original low-cost sky and a single environment-only cubemap for the paddock.
## Compatibility renderer: native High-only SSAO; no SSR or dynamic GI.

var world_environment: WorldEnvironment
var sun: DirectionalLight3D
var probe: ReflectionProbe
var sky_material: ShaderMaterial
var time_preset: int = 0
var quality_level: int = 1
var reflections_enabled: bool = true
var _anchor: Vector3 = Vector3(0.0, 2.4, 150.0)
var _built: bool = false
var _capture_revision: int = 0

const SKY_SOURCE: String = """shader_type sky;
uniform vec4 zenith : source_color = vec4(.23,.40,.59,1.);
uniform vec4 horizon : source_color = vec4(.68,.75,.78,1.);
uniform vec4 land : source_color = vec4(.24,.27,.21,1.);
uniform vec4 cloud_lit : source_color = vec4(.90,.91,.88,1.);
uniform vec4 cloud_shade : source_color = vec4(.53,.60,.64,1.);
uniform vec4 solar_color : source_color = vec4(1.,.94,.79,1.);
uniform vec3 solar_direction = vec3(.44,.58,.68);
uniform float cloud_coverage = .49;
uniform float dusk_amount = 0.;

float hash21(vec2 p) {
 p = fract(p*vec2(123.34,456.21));
 p += dot(p,p+45.32);
 return fract(p.x*p.y);
}
float value_noise(vec2 p) {
 vec2 i=floor(p), f=fract(p);f=f*f*(3.-2.*f);
 return mix(mix(hash21(i),hash21(i+vec2(1.,0.)),f.x),
            mix(hash21(i+vec2(0.,1.)),hash21(i+vec2(1.,1.)),f.x),f.y);
}
float broad_cloud(vec2 p) {
 float n=value_noise(p)*.57;
 p=mat2(vec2(1.6,1.2),vec2(-1.2,1.6))*p+vec2(4.7,-3.3);
 n+=value_noise(p)*.29;
 p=mat2(vec2(1.6,1.2),vec2(-1.2,1.6))*p+vec2(-7.1,1.9);
 return n+value_noise(p)*.14;
}
vec3 atmosphere_color(vec3 ray) {
 float elevation=max(ray.y,0.);
 float gradient=pow(elevation,.38);
 vec3 base=mix(horizon.rgb,zenith.rgb,gradient);
 float sun_dot=max(dot(ray,normalize(solar_direction)),0.);
 // Broad, restrained circumsolar haze; the visible disk remains very small.
 base+=solar_color.rgb*pow(sun_dot,24.)*.075;
 base+=solar_color.rgb*pow(sun_dot,220.)*.13;
 vec2 sheet=ray.xz/(max(ray.y,0.)+.19)*.72+vec2(11.7,-6.4);
 float n=broad_cloud(sheet);
 float coverage=smoothstep(cloud_coverage,cloud_coverage+.17,n);
 float horizon_fade=smoothstep(.01,.18,ray.y);
 float thickness=smoothstep(cloud_coverage-.03,.86,n);
 vec3 cloud=mix(cloud_lit.rgb,cloud_shade.rgb,thickness*.55);
 cloud+=solar_color.rgb*pow(sun_dot,9.)*.09;
 base=mix(base,cloud,coverage*horizon_fade*.88);
 float disk=smoothstep(.99993,.999965,sun_dot);
 base+=solar_color.rgb*disk*(1.8-dusk_amount*.6);
 float below=smoothstep(-.035,.015,ray.y);
 vec3 ground=mix(land.rgb*.78,horizon.rgb,max(ray.y+1.,0.)*.30);
 return mix(ground,base,below);
}
void sky() {
 COLOR=atmosphere_color(normalize(EYEDIR));
}
"""

func _ready() -> void:
	_build()

func _build() -> void:
	if _built:
		return
	_built = true
	name = "Atmosphere"
	world_environment = WorldEnvironment.new()
	world_environment.name = "WorldEnvironment"
	var environment := Environment.new()
	var sky := Sky.new()
	var shader := Shader.new()
	shader.code = SKY_SOURCE
	sky_material = ShaderMaterial.new()
	sky_material.shader = shader
	sky.sky_material = sky_material
	sky.radiance_size = Sky.RADIANCE_SIZE_128
	sky.process_mode = Sky.PROCESS_MODE_QUALITY
	environment.sky = sky
	environment.background_mode = Environment.BG_SKY
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	environment.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	environment.tonemap_mode = Environment.TONE_MAPPER_AGX
	environment.tonemap_exposure = 1.35
	environment.tonemap_agx_white = 10.0
	environment.tonemap_agx_contrast = 1.12
	environment.ambient_light_sky_contribution = 0.55
	environment.ambient_light_color = Color("b6c7d3")
	environment.ssao_radius = 1.0
	environment.ssao_intensity = 0.8
	environment.ssao_light_affect = 0.0
	environment.fog_enabled = true
	environment.fog_sky_affect = 0.12
	world_environment.environment = environment
	add_child(world_environment)
	sun = DirectionalLight3D.new()
	sun.name = "Sun"
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
	sun.shadow_bias = 1.5
	sun.shadow_normal_bias = 3.0
	sun.directional_shadow_blend_splits = true
	add_child(sun)
	_apply_time()
	_apply_quality()
	_create_probe()

func set_time(preset: int) -> void:
	time_preset = clampi(preset, 0, 2)
	if not _built:
		return
	_apply_time()
	_create_probe()

func set_quality(level: int) -> void:
	quality_level = clampi(level, 0, 2)
	if not _built:
		return
	_apply_quality()
	_create_probe()

func set_reflections(enabled: bool) -> void:
	reflections_enabled = enabled
	if _built:
		_create_probe()

func set_anchor(position_m: Vector3) -> void:
	_anchor = Vector3(position_m.x, 2.4, position_m.z)
	if _built:
		_create_probe()

func _apply_time() -> void:
	var env: Environment = world_environment.environment
	var colors: Array[Color]
	match time_preset:
		1:
			sun.rotation_degrees = Vector3(-20.0, -125.0, 0.0)
			sun.light_color = Color("ffd8a3")
			sun.light_energy = 0.95
			env.ambient_light_energy = 1.15
			env.ambient_light_color = Color("c4cbd0")
			env.fog_light_color = Color("c1b6a7")
			env.fog_density = 0.00065
			colors = [Color("547ead"), Color("d3c4b2"), Color("434a37"), Color("f3dfc0"), Color("8b8c91"), Color("ffdba8")]
		2:
			sun.rotation_degrees = Vector3(-7.0, -105.0, 0.0)
			sun.light_color = Color("ffc19d")
			sun.light_energy = 0.47
			env.ambient_light_energy = 0.90
			env.ambient_light_color = Color("8b9cb8")
			env.fog_light_color = Color("79869d")
			env.fog_density = 0.0010
			colors = [Color("3e5378"), Color("b99ca8"), Color("343b38"), Color("c1b0c6"), Color("606a87"), Color("ffb38d")]
		_:
			sun.rotation_degrees = Vector3(-36.0, 145.0, 0.0)
			sun.light_color = Color("fff1d8")
			sun.light_energy = 0.92
			env.ambient_light_energy = 1.05
			env.ambient_light_color = Color("b6c7d3")
			env.fog_light_color = Color("a7bac5")
			env.fog_density = 0.00062
			colors = [Color("3f78b0"), Color("aac6d3"), Color("495440"), Color("e1e5e2"), Color("8f9da7"), Color("fff0cd")]
	var names: Array[String] = ["zenith", "horizon", "land", "cloud_lit", "cloud_shade", "solar_color"]
	for i in range(names.size()):
		sky_material.set_shader_parameter(names[i], colors[i])
	# DirectionalLight3D emits along local -Z: +Z is the world vector toward the sun.
	sky_material.set_shader_parameter("solar_direction", sun.basis.z.normalized())
	sky_material.set_shader_parameter("dusk_amount", 1.0 if time_preset == 2 else 0.0)
	sky_material.set_shader_parameter("cloud_coverage", 0.62 if time_preset == 0 else 0.60)

func _apply_quality() -> void:
	sun.shadow_enabled = quality_level > 0
	world_environment.environment.ssao_enabled = quality_level == 2
	sun.directional_shadow_max_distance = 90.0 if quality_level == 1 else 155.0
	RenderingServer.directional_shadow_atlas_set_size(1024 if quality_level == 0 else (2048 if quality_level == 1 else 4096), true)

func _create_probe() -> void:
	if is_instance_valid(probe):
		probe.hide()
		probe.queue_free()
	_capture_revision += 1
	probe = ReflectionProbe.new()
	probe.name = "PaddockReflections"
	probe.position = _anchor
	probe.size = Vector3(84.0, 22.0, 182.0)
	probe.origin_offset = Vector3(0.0, 1.5, 0.0)
	probe.max_distance = 240.0
	probe.blend_distance = 12.0
	probe.cull_mask = 1
	probe.reflection_mask = 1048575
	probe.box_projection = true
	probe.interior = false
	probe.intensity = 0.68
	probe.enable_shadows = false
	probe.ambient_mode = ReflectionProbe.AMBIENT_ENVIRONMENT
	probe.update_mode = ReflectionProbe.UPDATE_ONCE
	probe.visible = reflections_enabled and quality_level > 0
	probe.set_meta("capture_revision", _capture_revision)
	add_child(probe)
