extends Node3D

const VehicleScript = preload("res://scripts/vehicle.gd")
const ModelScript = preload("res://scripts/car_model.gd")
const TrackScript = preload("res://scripts/track.gd")
const HUDScript = preload("res://scripts/hud.gd")
const RulesScript = preload("res://scripts/race_rules.gd")
const AudioScript = preload("res://scripts/engine_audio.gd")

var car: Node3D
var model: Node3D
var track: Node3D
var hud: CanvasLayer
var camera: Camera3D
var sun: DirectionalLight3D
var world_environment: WorldEnvironment
var audio: AudioStreamPlayer
var rules = RulesScript.new()
var playing: bool = false
var camera_mode: int = 0
var reverse_selected: bool = false
var lamps_on: bool = false
var surface: String = "asphalt"
var elapsed: float = 0.0
var collision_cooldown: float = 0.0
var camera_initialized: bool = false
var settings: Dictionary = {"quality": 1, "fov": 72.0, "volume": 55.0, "steering": 1.0, "motion": true, "speed_fov": false, "fullscreen": false, "resolution": Vector2i(1280, 720)}
var settings_file: ConfigFile = ConfigFile.new()
var smoke_test: bool = false
var capture_mode: bool = false
var capture_index: int = 0
var capture_frames: int = 0
var capture_wait: int = 0
var benchmark: bool = false
var frame_times: Array[float] = []
var _baseline_memory: int = 0
var _qa_run: bool = false
var _qa_time: float = 0.0
var _frame_usec: int = 0
var _benchmark_start_usec: int = 0
var _quality_override: int = -1
var _quitting: bool = false

func _ready() -> void:
	_read_args()
	get_tree().auto_accept_quit = false
	_load_settings()
	if _quality_override >= 0:
		settings.quality = _quality_override
	_setup_lighting()
	track = TrackScript.new()
	add_child(track)
	car = VehicleScript.new()
	add_child(car)
	model = ModelScript.new()
	car.add_child(model)
	camera = Camera3D.new()
	camera.near = 0.045
	camera.far = 1200.0
	camera.current = true
	add_child(camera)
	audio = AudioScript.new()
	add_child(audio)
	hud = HUDScript.new()
	add_child(hud)
	hud.drive_requested.connect(_start)
	hud.resume_requested.connect(_start)
	hud.reset_requested.connect(_reset)
	hud.quit_requested.connect(_quit_game)
	hud.setting_changed.connect(_change_setting)
	if hud.has_method("set_map"):
		hud.set_map(track.points)
	for key in settings:
		_apply_setting(key, settings[key])
	if hud.has_method("apply_settings"):
		hud.apply_settings(settings)
	_reset()
	hud.show_menu(true)
	_baseline_memory = OS.get_static_memory_usage()
	_benchmark_start_usec = Time.get_ticks_usec()
	_frame_usec = _benchmark_start_usec
	print("CIRCUIT READY | track_m=", track.total_length, " | fixed_hz=", Engine.physics_ticks_per_second, " | renderer=", RenderingServer.get_current_rendering_method())
	if capture_mode:
		hud.hide_menu()
		_setup_capture(0)
	if _qa_run:
		_start()
	if smoke_test:
		call_deferred("_smoke_finish")

func _read_args() -> void:
	var args: PackedStringArray = OS.get_cmdline_user_args()
	smoke_test = "--smoke-test" in args
	capture_mode = "--capture" in args
	benchmark = "--benchmark" in args
	_qa_run = "--qa-drive" in args or benchmark
	for argument in args:
		if argument.begins_with("--quality="):
			_quality_override = clampi(argument.get_slice("=", 1).to_int(), 0, 2)

func _setup_lighting() -> void:
	world_environment = WorldEnvironment.new()
	var env := Environment.new()
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color("537b9b")
	sky_mat.sky_horizon_color = Color("c5d0ce")
	sky_mat.ground_bottom_color = Color("474b3b")
	sky_mat.ground_horizon_color = Color("adb4a5")
	sky_mat.sky_curve = 0.18
	sky_mat.sun_angle_max = 12.0
	sky.sky_material = sky_mat
	sky.radiance_size = Sky.RADIANCE_SIZE_256
	env.sky = sky
	env.background_mode = Environment.BG_SKY
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.38
	env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_exposure = 1.0
	env.fog_enabled = true
	env.fog_light_color = Color("a9bdc5")
	env.fog_density = 0.00085
	env.fog_sky_affect = 0.18
	world_environment.environment = env
	add_child(world_environment)
	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-32.0, -38.0, 0.0)
	sun.light_color = Color(1.0, 0.94, 0.81)
	sun.light_energy = 0.88
	sun.shadow_enabled = true
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
	sun.directional_shadow_max_distance = 170.0
	sun.shadow_bias = 0.12
	sun.shadow_normal_bias = 0.8
	add_child(sun)

func _start() -> void:
	playing = true
	hud.hide_menu()

func _pause() -> void:
	playing = false
	# Explicit key-up events also cover focus-loss on hosts that retain keyboard state.
	for key in [KEY_W, KEY_S, KEY_A, KEY_D, KEY_UP, KEY_DOWN, KEY_LEFT, KEY_RIGHT, KEY_SPACE]:
		var release := InputEventKey.new()
		release.physical_keycode = key
		release.keycode = key
		release.pressed = false
		Input.parse_input_event(release)
	Input.flush_buffered_events()
	if is_instance_valid(hud):
		hud.show_menu(false)
	_save_settings()

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT and playing and not _qa_run:
		_pause()
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		_save_settings()
		_quit_game()

func _quit_game() -> void:
	if _quitting:
		return
	_quitting = true
	playing = false
	if is_instance_valid(audio):
		audio.shutdown()
	# Let the audio server consume its stop command before process teardown.
	await get_tree().create_timer(0.65).timeout
	get_tree().quit()

func _unhandled_key_input(event: InputEvent) -> void:
	if not event is InputEventKey or not event.pressed or event.echo:
		return
	match event.physical_keycode:
		KEY_ESCAPE:
			if playing: _pause()
			else: _start()
		KEY_ENTER:
			if not playing: _start()
		KEY_C:
			camera_mode = (camera_mode + 1) % 4
			camera_initialized = false
		KEY_R:
			_reset()
		KEY_Q:
			reverse_selected = not reverse_selected
		KEY_L:
			lamps_on = not lamps_on
		KEY_F11:
			_change_setting("fullscreen", DisplayServer.window_get_mode() != DisplayServer.WINDOW_MODE_FULLSCREEN)

func _reset() -> void:
	var start: Dictionary = track.sample_at(0.0)
	car.reset_to(start.position, start.yaw)
	reverse_selected = false
	camera_initialized = false
	rules.reset(track.total_length, rules.best_time)
	if is_instance_valid(model):
		model.rotation = Vector3.ZERO
	_update_camera(1.0, true)

func _physics_process(dt: float) -> void:
	if not is_instance_valid(car) or not playing or capture_mode:
		return
	var gas: float = 1.0 if Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP) else 0.0
	var brake: float = 1.0 if Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN) else 0.0
	var steering: float = float(Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT)) - float(Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT))
	var handbrake: bool = Input.is_physical_key_pressed(KEY_SPACE)
	var near: Dictionary = track.nearest(car.position)
	if _qa_run:
		_qa_time += dt
		var lookahead: float = clampf(absf(car.speed) * 0.45, 4.0, 9.0)
		var target: Dictionary = track.sample_at(near.progress + lookahead)
		var offset: Vector3 = target.position - car.position
		var angle_error: float = wrapf(atan2(-offset.x, -offset.z) - car.rotation.y, -PI, PI)
		var curvature: float = 2.0 * sin(angle_error) / maxf(offset.length(), 1.0)
		var desired_angle: float = atan(curvature * 2.425 * (1.0 + 0.0016 * car.speed * car.speed))
		var max_steer: float = lerpf(0.53, 0.13, clampf(absf(car.speed) / 55.0, 0.0, 1.0))
		steering = clampf(desired_angle / max_steer, -1.0, 1.0)
		var largest_curvature: float = 0.005
		for offset_m in [5.0, 10.0, 20.0, 35.0]:
			var p0: Dictionary = track.sample_at(near.progress + offset_m)
			var p1: Dictionary = track.sample_at(near.progress + offset_m + 6.0)
			largest_curvature = maxf(largest_curvature, absf(wrapf(p1.yaw - p0.yaw, -PI, PI)) / 6.0)
		var target_speed: float = clampf(sqrt(3.0 / largest_curvature), 6.0, 17.0)
		gas = clampf((target_speed - car.speed) * 0.8, 0.0, 1.0)
		brake = clampf((car.speed - target_speed - 0.3) * 0.3, 0.0, 0.7)
		if _qa_time > 125.0 and not benchmark:
			_report_qa()
			_quit_game()
	var distance: float = absf(near.distance)
	surface = "asphalt" if distance <= track.road_half_width else ("grass" if distance < track.road_half_width + 3.0 else "gravel")
	car.step(dt, gas, brake, steering, reverse_selected, handbrake, surface)
	var after: Dictionary = track.nearest(car.position)
	_enforce_barrier(after, dt)
	var before_best: float = rules.best_time
	rules.tick(dt, after.progress, absf(after.distance) <= track.road_half_width + 0.9, car.velocity.dot(after.forward) > 0.3, car.velocity.length() > 0.25)
	if rules.best_time != before_best:
		_save_settings()
	# Subtle sprung-body visual only; wheels remain grounded through small angles.
	var target_roll: float = clampf(car.yaw_rate * car.speed * -0.0018, -0.022, 0.022)
	var target_pitch: float = clampf(car.longitudinal_accel * 0.0015, -0.012, 0.012)
	model.rotation.z = lerpf(model.rotation.z, target_roll, 1.0 - exp(-5.0 * dt))
	model.rotation.x = lerpf(model.rotation.x, target_pitch, 1.0 - exp(-5.0 * dt))

func _enforce_barrier(near: Dictionary, dt: float) -> void:
	collision_cooldown = maxf(0.0, collision_cooldown - dt)
	var outward: Vector3 = car.position - near.position
	outward.y = 0.0
	outward = outward.normalized()
	# Project the oriented body rectangle, so a nose-first impact cannot penetrate.
	var envelope: float = absf(outward.dot(-car.basis.z)) * 2.15 + absf(outward.dot(car.basis.x)) * 0.90
	var limit: float = track.barrier_offset - envelope - 0.08
	if absf(near.distance) > limit:
		car.position = near.position + outward * limit
		var impact: float = car.velocity.dot(outward)
		if impact > 0.0:
			car.velocity -= outward * impact * 1.12
			car.velocity *= 0.72
		car.speed = car.velocity.dot(-car.basis.z)
		car.yaw_rate *= 0.5
		rules.valid = false
		rules.message = "BARRIER CONTACT · lap invalid. R returns safely to the grid."
		collision_cooldown = 1.5

func _process(dt: float) -> void:
	if _quitting:
		return
	if not is_instance_valid(model) or not is_instance_valid(hud):
		return
	elapsed += dt
	model.update_visuals(car.speed if playing else 0.0, car.steer, car.brake, car.rpm, dt, lamps_on)
	if model.has_method("set_cockpit_mode"):
		model.set_cockpit_mode(capture_index == 4 if capture_mode else camera_mode == 3)
	if not capture_mode:
		_update_camera(dt)
	var camera_names: Array[String] = ["CHASE", "WIDE", "BONNET", "COCKPIT"]
	hud.update_state({"speed": absf(car.speed) * 3.6, "gear": "R" if car.gear < 0 else str(car.gear), "rpm": car.rpm, "lap_time": rules.lap_time, "best_time": rules.best_time, "lap": rules.completed_laps + 1, "next_gate": rules.next_gate, "gate_count": rules.gate_count, "camera": camera_names[camera_mode], "surface": surface, "message": rules.message, "paused": not playing, "car_position": car.position, "car_yaw": car.rotation.y})
	audio.target_rpm = car.rpm
	audio.target_load = car.throttle
	audio.target_speed = car.speed
	audio.target_slip = car.lateral_slip
	audio.active = playing
	audio.pitch_scale = 0.84 if camera_mode == 3 else 1.0
	if benchmark:
		var now_usec: int = Time.get_ticks_usec()
		var wall_seconds: float = float(now_usec - _benchmark_start_usec) / 1000000.0
		if wall_seconds > 5.0:
			frame_times.append(float(now_usec - _frame_usec) / 1000.0)
		_frame_usec = now_usec
		if wall_seconds >= 30.0:
			_report_qa()
			_quit_game()
	if capture_mode:
		capture_wait += 1
		if capture_wait == 8:
			_capture_frame.call_deferred()

func _update_camera(dt: float, snap: bool = false) -> void:
	if not is_instance_valid(camera):
		return
	var offsets: Array[Vector3] = [Vector3(0, 2.4, 6.4), Vector3(0, 4.0, 10.0), Vector3(0, 1.04, -1.31), Vector3(0.33, 0.94, 0.20)]
	var desired: Vector3 = car.global_transform * offsets[camera_mode]
	var look: Vector3 = car.global_position + Vector3(0, 0.85, 0) - car.global_basis.z * (5.5 if camera_mode < 2 else 45.0)
	if camera_mode >= 2:
		look.y = desired.y - 0.015
	var blend: float = 1.0 if snap or not camera_initialized or camera_mode >= 2 else 1.0 - exp(-8.5 * dt)
	camera.global_position = camera.global_position.lerp(desired, blend)
	camera.global_position.y = maxf(camera.global_position.y, 0.45)
	if camera_mode < 2:
		var camera_near: Dictionary = track.nearest(camera.global_position)
		if absf(camera_near.distance) > track.road_half_width + 10.0:
			var normal: Vector3 = (camera.global_position - camera_near.position)
			normal.y = 0.0
			var height: float = camera.global_position.y
			camera.global_position = camera_near.position + normal.normalized() * (track.road_half_width + 10.0)
			camera.global_position.y = height
	camera.look_at(look, Vector3.UP)
	var extra_fov: float = clampf(absf(car.speed) / 60.0, 0.0, 1.0) * 5.0 if settings.speed_fov else 0.0
	camera.fov = clampf(float(settings.fov), 60.0, 90.0) + extra_fov - (4.0 if camera_mode == 3 else 0.0)
	if settings.motion and playing and camera_mode < 2:
		camera.rotation.z = clampf(-car.yaw_rate * 0.012, -0.008, 0.008)
	camera_initialized = true

func _change_setting(key: String, value: Variant) -> void:
	settings[key] = value
	_apply_setting(key, value)
	_save_settings()

func _apply_setting(key: String, value: Variant) -> void:
	match key:
		"quality":
			var level: int = clampi(int(value), 0, 2)
			get_viewport().msaa_3d = Viewport.MSAA_DISABLED if level == 0 else (Viewport.MSAA_2X if level == 1 else Viewport.MSAA_4X)
			sun.shadow_enabled = level != 0
			sun.directional_shadow_max_distance = 100.0 if level == 1 else 170.0
			RenderingServer.directional_shadow_atlas_set_size(1024 if level == 0 else (2048 if level == 1 else 4096), true)
			# Tree silhouettes are outside the driving corridor. Reserve their many
			# cascaded shadow draws for High; retain vehicle/track shadows in Balanced.
			for vegetation in get_tree().get_nodes_in_group("vegetation"):
				vegetation.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if level == 2 else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		"volume":
			AudioServer.set_bus_volume_db(0, linear_to_db(clampf(float(value) / 100.0, 0.0001, 1.0)))
		"steering":
			car.steering_sensitivity = clampf(float(value), 0.5, 1.5)
		"fullscreen":
			if not smoke_test:
				DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN if value else DisplayServer.WINDOW_MODE_WINDOWED)
		"resolution":
			if value is Vector2i and not smoke_test:
				DisplayServer.window_set_size(Vector2i(clampi(value.x, 640, 3840), clampi(value.y, 360, 2160)))

func _load_settings() -> void:
	if settings_file.load("user://settings.cfg") != OK:
		return
	for key in settings:
		var value: Variant = settings_file.get_value("settings", key, settings[key])
		if typeof(value) == typeof(settings[key]):
			settings[key] = value
	var best: Variant = settings_file.get_value("records", "best", 0.0)
	if (best is float or best is int) and float(best) > 10.0 and float(best) < 86400.0:
		rules.best_time = float(best)

func _save_settings() -> void:
	for key in settings:
		settings_file.set_value("settings", key, settings[key])
	settings_file.set_value("records", "best", rules.best_time)
	var result: Error = settings_file.save("user://settings.cfg")
	if result != OK:
		push_warning("Settings could not be saved; play continues. Error " + str(result))

func _smoke_finish() -> void:
	await get_tree().process_frame
	assert(track.points.size() > 50, "Track not generated")
	assert(car.get_child_count() > 0, "Car missing")
	assert(camera.current, "Camera not active")
	for view in range(4):
		camera_mode = view
		_update_camera(1.0, true)
		assert(camera.global_position.is_finite(), "Invalid camera")
	for level in range(3):
		_apply_setting("quality", level)
	_reset()
	print("SCENE SMOKE PASS | 4 cameras | 3 quality presets | car, track, HUD, reset")
	_quit_game()

func _report_qa() -> void:
	var report: Dictionary = {"simulated_seconds": _qa_time, "speed_kmh": car.speed * 3.6, "position": str(car.position), "finite": car.position.is_finite(), "laps": rules.completed_laps, "next_gate": rules.next_gate, "lap_valid": rules.valid, "memory_initial_bytes": _baseline_memory, "memory_final_bytes": OS.get_static_memory_usage(), "renderer": RenderingServer.get_current_rendering_method(), "rendered_frames": frame_times.size()}
	report["wall_seconds"] = float(Time.get_ticks_usec() - _benchmark_start_usec) / 1000000.0
	report["viewport"] = str(get_viewport().size)
	report["quality"] = settings.quality
	report["draw_calls"] = Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME)
	report["visible_primitives"] = Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME)
	if frame_times.size() > 20:
		frame_times.sort()
		var sum: float = 0.0
		for sample in frame_times: sum += sample
		report["frame_ms_mean"] = sum / frame_times.size()
		report["frame_ms_p95"] = frame_times[int(frame_times.size() * 0.95)]
		report["frame_ms_p99"] = frame_times[int(frame_times.size() * 0.99)]
	print("QA REPORT ", JSON.stringify(report))
	var file := FileAccess.open("res://artifacts/qa-report.json", FileAccess.WRITE)
	if file: file.store_string(JSON.stringify(report, "  "))

func _setup_capture(index: int) -> void:
	var start: Dictionary = track.sample_at(0.0)
	car.reset_to(start.position, start.yaw)
	model.rotation = Vector3.ZERO
	var offsets: Array[Vector3] = [Vector3(-4.1, 1.85, -5.7), Vector3(4.0, 1.65, 5.8), Vector3(-6.0, 1.25, 0.1), Vector3(-1.75, 0.58, -2.15), Vector3(0.33, 0.94, 0.20), Vector3(0, 2.4, 6.4), Vector3(-4.1, 1.85, -5.7)]
	if index >= offsets.size():
		print("CAPTURE COMPLETE | seven actual gameplay renders")
		_quit_game()
		return
	capture_index = index
	capture_wait = 0
	camera.global_position = car.global_transform * offsets[index]
	var target: Vector3 = car.global_transform * Vector3(0, 0.62, 0)
	if index == 3: target = car.global_transform * Vector3(-0.72, 0.34, -1.21)
	if index == 4: target = car.global_transform * Vector3(0.30, 0.94, -35)
	if index == 5: target = car.global_transform * Vector3(0, 0.8, -8)
	camera.fov = 48.0 if index < 4 or index == 6 else 72.0
	camera.look_at(target, Vector3.UP)
	lamps_on = index == 6
	if model.has_method("set_cockpit_mode"): model.set_cockpit_mode(index == 4)

func _capture_frame() -> void:
	await RenderingServer.frame_post_draw
	var names: Array[String] = ["01-front-three-quarter", "02-rear-three-quarter", "03-side", "04-wheel", "05-cockpit", "06-driving", "07-popups"]
	var image: Image = get_viewport().get_texture().get_image()
	var path: String = "res://artifacts/" + names[capture_index] + ".png"
	var error: Error = image.save_png(path)
	print("CAPTURE ", path, " result=", error)
	_setup_capture(capture_index + 1)
