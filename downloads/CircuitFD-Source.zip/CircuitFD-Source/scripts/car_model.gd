class_name CarModel
extends Node3D
## Original, approximate FD-inspired mesh. Forward is -Z, dimensions are metres.

var wheel_mounts: Array[Node3D] = []
var wheel_spinners: Array[Node3D] = []
var popup_hinges: Array[Node3D] = []
var brake_lenses: Array[MeshInstance3D] = []
var cabin_glass: Array[MeshInstance3D] = []
var head_lights: Array[SpotLight3D] = []
var steering_pivot: Node3D
var speed_needle: Node3D
var rpm_needle: Node3D
var body: Node3D
var paint: StandardMaterial3D
var rubber: StandardMaterial3D
var trim: StandardMaterial3D
var glass: StandardMaterial3D
var alloy: StandardMaterial3D
var brake_mat: StandardMaterial3D
var brake_on_mat: StandardMaterial3D
var lamp_mat: StandardMaterial3D
var popup_amount := 0.0
var wheel_angle := 0.0
var cockpit_active := false

func _ready() -> void:
	paint = _mat(Color(0.82, 0.62, 0.035), 0.25, 0.0)
	paint.clearcoat_enabled = true
	paint.clearcoat = 0.65
	paint.clearcoat_roughness = 0.24
	rubber = _mat(Color(0.023, 0.025, 0.026), 0.92)
	rubber.normal_enabled = true
	rubber.normal_texture = _tire_normal_texture()
	rubber.normal_scale = 0.45
	trim = _mat(Color(0.025, 0.029, 0.031), 0.67)
	alloy = _mat(Color(0.51, 0.54, 0.57), 0.28, 0.87)
	glass = _mat(Color(0.14, 0.20, 0.23, 0.38), 0.12, 0.05)
	glass.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	glass.cull_mode = BaseMaterial3D.CULL_DISABLED
	brake_mat = _mat(Color(0.29, 0.009, 0.008), 0.26)
	brake_on_mat = _mat(Color(0.95, 0.035, 0.012), 0.24)
	brake_on_mat.emission_enabled = true
	brake_on_mat.emission = Color(1.0, 0.04, 0.012)
	brake_on_mat.emission_energy_multiplier = 2.0
	lamp_mat = _mat(Color(0.86, 0.89, 0.80), 0.18, 0.12)
	body = Node3D.new()
	body.name = "Body"
	add_child(body)
	_build_shell()
	_build_glazing_and_roof()
	_build_exterior_details()
	_build_cabin()
	for side in [-1.0, 1.0]:
		for z in [-1.2125, 1.2125]:
			_build_wheel(side, z)
	_batch_static(body)
	for spin in wheel_spinners:
		_batch_static(spin)

func _mat(col: Color, rough: float, metal: float = 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = col
	m.roughness = rough
	m.metallic = metal
	return m

func _tire_normal_texture() -> Texture2D:
	# Original seamless, modest tread relief. UV.x circles the rounded tyre section,
	# UV.y runs around the wheel; only the road-contact crown receives tread cuts.
	var image := Image.create(256, 512, false, Image.FORMAT_L8)
	for y in range(512):
		var v: float = float(y) / 512.0
		for x in range(256):
			var u: float = float(x) / 256.0
			var crown: float = smoothstep(0.35, 0.70, cos(TAU * u))
			var channel_distance: float = minf(absf(wrapf(u - 0.055, -0.5, 0.5)), absf(wrapf(u + 0.055, -0.5, 0.5)))
			var channels: float = 1.0 - smoothstep(0.006, 0.012, channel_distance)
			var diagonal: float = absf(fposmod(v * 64.0 + u * 5.0, 1.0) - 0.5)
			var sipes: float = 1.0 - smoothstep(0.045, 0.12, diagonal)
			var height: float = 0.65 - crown * (channels * 0.26 + sipes * 0.16)
			image.set_pixel(x, y, Color(height, height, height))
	image.bump_map_to_normal_map(2.0)
	image.generate_mipmaps()
	return ImageTexture.create_from_image(image)

func _mesh(st: SurfaceTool, material: Material, parent: Node3D, mesh_name: String = "Detail") -> MeshInstance3D:
	st.generate_normals()
	var n := MeshInstance3D.new()
	n.name = mesh_name
	n.mesh = st.commit()
	n.material_override = material
	parent.add_child(n)
	return n

func _tri(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3) -> void:
	st.add_vertex(a)
	st.add_vertex(c)
	st.add_vertex(b)

func _quad(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, d: Vector3, flip: bool = false) -> void:
	if flip:
		_tri(st, a, c, b)
		_tri(st, a, d, c)
	else:
		_tri(st, a, b, c)
		_tri(st, a, c, d)

func _box(parent: Node3D, pos: Vector3, size: Vector3, material: Material, mesh_name: String = "Detail") -> MeshInstance3D:
	var n := MeshInstance3D.new()
	n.name = mesh_name
	var m := BoxMesh.new()
	m.size = size
	n.mesh = m
	n.material_override = material
	n.position = pos
	parent.add_child(n)
	return n

func _ellipsoid(parent: Node3D, pos: Vector3, size: Vector3, material: Material) -> MeshInstance3D:
	var n := MeshInstance3D.new()
	var m := SphereMesh.new()
	m.radius = 0.5
	m.height = 1.0
	m.radial_segments = 32
	m.rings = 16
	n.mesh = m
	n.position = pos
	n.scale = size
	n.material_override = material
	parent.add_child(n)
	return n

func _cylinder(parent: Node3D, pos: Vector3, radius: float, height: float, material: Material, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var n := MeshInstance3D.new()
	var m := CylinderMesh.new()
	m.top_radius = radius
	m.bottom_radius = radius
	m.height = height
	m.radial_segments = 40
	n.mesh = m
	n.position = pos
	n.rotation = rot
	n.material_override = material
	parent.add_child(n)
	return n

func _array_mesh(parent: Node3D, material: Material, name_: String, vertices: PackedVector3Array, normals: PackedVector3Array, indices: PackedInt32Array, uvs: PackedVector2Array = PackedVector2Array()) -> MeshInstance3D:
	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = vertices
	arrays[Mesh.ARRAY_NORMAL] = normals
	arrays[Mesh.ARRAY_INDEX] = indices
	if uvs.size() == vertices.size(): arrays[Mesh.ARRAY_TEX_UV] = uvs
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	var node := MeshInstance3D.new()
	node.name = name_
	node.mesh = mesh
	node.material_override = material
	parent.add_child(node)
	return node

func _param_surface(parent: Node3D, material: Material, name_: String, rows: int, cols: int, shape: Callable, flip: bool = false, skip: Callable = Callable()) -> MeshInstance3D:
	# Explicit normals come from the same continuous parametric surface as positions.
	# They do not depend on triangulation, duplicate-vertex welding, or tiny floating-point differences.
	var vertices := PackedVector3Array()
	var normals := PackedVector3Array()
	var indices := PackedInt32Array()
	var uv := PackedVector2Array()
	const E := 0.00015
	for i in range(rows + 1):
		var t := float(i) / rows
		for j in range(cols + 1):
			var u := float(j) / cols
			var p: Vector3 = shape.call(t, u)
			var dt: Vector3 = shape.call(t + E, u) - shape.call(t - E, u)
			var du: Vector3 = shape.call(t, u + E) - shape.call(t, u - E)
			var normal := dt.cross(du).normalized()
			if flip: normal = -normal
			vertices.append(p)
			normals.append(normal)
			uv.append(Vector2(u, t))
	for i in range(rows):
		for j in range(cols):
			if skip.is_valid() and skip.call((float(i) + .5) / rows, (float(j) + .5) / cols): continue
			var a := i * (cols + 1) + j
			var b := a + cols + 1
			var c := b + 1
			var d := a + 1
			if flip: indices.append_array(PackedInt32Array([a,b,c,a,c,d]))
			else: indices.append_array(PackedInt32Array([a,c,b,a,d,c]))
	return _array_mesh(parent, material, name_, vertices, normals, indices, uv)

func _line(parent: Node3D, points: PackedVector3Array, radius: float, material: Material) -> void:
	if points.size() < 2: return
	var vertices := PackedVector3Array()
	var normals := PackedVector3Array()
	var indices := PackedInt32Array()
	const SIDES := 8
	var closed := points[0].distance_to(points[-1]) < .0001
	var first_tangent := (points[1] - points[0]).normalized()
	var reference := Vector3.RIGHT if absf(first_tangent.dot(Vector3.RIGHT)) < .9 else Vector3.UP
	var right := first_tangent.cross(reference).normalized()
	for i in range(points.size()):
		var prev := points[maxi(0, i-1)]
		var next := points[mini(points.size()-1, i+1)]
		if closed and (i == 0 or i == points.size()-1):
			prev = points[-2]
			next = points[1]
		var tangent := (next-prev).normalized()
		right = (right - tangent * right.dot(tangent)).normalized()
		if right.length_squared() < .1: right = tangent.cross(Vector3.UP).normalized()
		var up := tangent.cross(right).normalized()
		for j in range(SIDES + 1):
			var angle := TAU * float(j) / SIDES
			var radial := right*cos(angle)+up*sin(angle)
			vertices.append(points[i]+radial*radius)
			normals.append(radial)
	for i in range(points.size()-1):
		for j in range(SIDES):
			var a := i*(SIDES+1)+j
			var b := a+SIDES+1
			indices.append_array(PackedInt32Array([a,b,b+1,a,b+1,a+1]))
	_array_mesh(parent, material, "Smooth_contour", vertices, normals, indices)

func _batch_static(parent: Node3D) -> void:
	# Preserve animated needles, steering pivots, glass visibility and brake-material changes.
	var groups: Dictionary = {}
	for node in parent.get_children():
		if not node is MeshInstance3D or node in cabin_glass or node in brake_lenses: continue
		var key: int = node.material_override.get_instance_id() if node.material_override else 0
		if not groups.has(key): groups[key] = []
		groups[key].append(node)
	for key in groups:
		var nodes: Array = groups[key]
		if nodes.size() < 2: continue
		var vertices := PackedVector3Array()
		var normals := PackedVector3Array()
		var indices := PackedInt32Array()
		var uv := PackedVector2Array()
		for node in nodes:
			var normal_basis: Basis = node.transform.basis.inverse().transposed()
			for surface_idx in range(node.mesh.get_surface_count()):
				var arrays: Array = node.mesh.surface_get_arrays(surface_idx)
				var start := vertices.size()
				var raw: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
				var nn: PackedVector3Array = arrays[Mesh.ARRAY_NORMAL]
				var raw_uv: PackedVector2Array = arrays[Mesh.ARRAY_TEX_UV] if arrays[Mesh.ARRAY_TEX_UV] != null else PackedVector2Array()
				for v in range(raw.size()):
					vertices.append(node.transform * raw[v])
					normals.append((normal_basis * nn[v]).normalized())
					uv.append(raw_uv[v] if raw_uv.size() > v else Vector2.ZERO)
				var raw_indices: PackedInt32Array = arrays[Mesh.ARRAY_INDEX] if arrays[Mesh.ARRAY_INDEX] != null else PackedInt32Array()
				if raw_indices.is_empty():
					for k in range(raw.size()): indices.append(start + k)
				else:
					for k in raw_indices: indices.append(start + k)
		_array_mesh(parent, nodes[0].material_override, "Batched_material", vertices, normals, indices, uv)
		for node in nodes:
			parent.remove_child(node)
			node.free()

func _profile(z: float) -> Vector3:
	# z, half-width, hood/shoulder elevation. Smoothed interpolation preserves rounded FD silhouette.
	var sections := [Vector3(-2.1425, 0.60, 0.475), Vector3(-2.04, 0.755, 0.545), Vector3(-1.81, 0.835, 0.635), Vector3(-1.25, 0.875, 0.730), Vector3(-0.70, 0.825, 0.750), Vector3(0.0, 0.82, 0.745), Vector3(0.72, 0.84, 0.75), Vector3(1.25, 0.88, 0.745), Vector3(1.81, 0.83, 0.70), Vector3(2.04, 0.77, 0.65), Vector3(2.1425, 0.68, 0.58)]
	for i in range(sections.size() - 1):
		if z <= sections[i + 1].x:
			var t: float = inverse_lerp(sections[i].x, sections[i + 1].x, z)
			# Nonuniform cubic Hermite interpolation maintains a shared derivative at every station.
			# The old per-span smoothstep reset derivatives at every station, causing rippled highlights.
			var before: Vector3 = sections[maxi(i - 1, 0)]
			var after: Vector3 = sections[mini(i + 2, sections.size() - 1)]
			var span: float = sections[i + 1].x - sections[i].x
			var m0: Vector3 = (sections[i + 1] - before) / (sections[i + 1].x - before.x)
			var m1: Vector3 = (after - sections[i]) / (after.x - sections[i].x)
			var t2: float = t * t
			var t3: float = t2 * t
			var interpolated: Vector3 = sections[i] * (2.0*t3-3.0*t2+1.0) + m0*span*(t3-2.0*t2+t) + sections[i+1]*(-2.0*t3+3.0*t2) + m1*span*(t3-t2)
			interpolated.x = z
			interpolated.y = minf(interpolated.y, 0.88)
			return interpolated
	return sections[-1]

func _upper(z: float, u: float) -> Vector3:
	var p := _profile(z)
	# Rounded fender crowns sit slightly above the central bonnet, avoiding a single wedge slab.
	var crown: float = 0.028 * exp(-pow((absf(u) - 0.76) / 0.19, 2.0))
	var bonnet_dip: float = 0.017 * exp(-pow(u / 0.53, 2.0))
	return Vector3(p.y * u, p.z - 0.058 * pow(absf(u), 4.0) + crown - bonnet_dip, z)

func _arch_bottom(z: float) -> float:
	var lower := 0.17
	for wz in [-1.2125, 1.2125]:
		var d: float = absf(z - wz)
		if d < 0.355:
			lower = maxf(lower, 0.31 + sqrt(maxf(0.0, 0.355 * 0.355 - d * d)))
	return lower

func _side_point(z: float, t: float, side: float) -> Vector3:
	var upper := _upper(z, side)
	var lower := minf(upper.y-.003, _arch_bottom(z))
	var flare: float = maxf(exp(-pow(absf(z + 1.2125)/.40,6.0)),exp(-pow(absf(z - 1.2125)/.40,6.0)))
	var x := absf(upper.x) * (1.0 - .075*(1.0-flare)*t) + .021*sin(t*PI)*(1.0-.5*flare)
	return Vector3(side*x, lerpf(upper.y,lower,t), z)

func _build_shell() -> void:
	_param_surface(body,paint,"Analytic_continuous_body",128,32,
		func(t: float,u: float) -> Vector3: return _upper(lerpf(-2.1425,2.1425,t),lerpf(-1.0,1.0,u)),false,
		func(t: float,u: float) -> bool:
			var z := lerpf(-2.1425,2.1425,t)
			return z > -.73 and z < 1.46 and absf(u*2.0-1.0) < .82)
	for side in [-1.0,1.0]:
		_param_surface(body,paint,"Analytic_curved_side",192,8,
			func(t: float,u: float) -> Vector3: return _side_point(lerpf(-2.1425,2.1425,t),u,side),side<0.0)
		_box(body,Vector3(side*.780,.190,.0),Vector3(.055,.045,1.67),paint,"Side_sill")
		for wz in [-1.2125,1.2125]:
			var arc := PackedVector3Array()
			var jamb_z: float = wz + .360
			var jamb_t: float = clampf(inverse_lerp(_upper(jamb_z,side).y,_arch_bottom(jamb_z),.18),0.0,1.0)
			var jamb: Vector3 = _side_point(jamb_z,jamb_t,side)
			jamb.x += side*.001
			arc.append(jamb)
			for k in range(65):
				var t := PI*float(k)/64.0
				var z: float = wz+.355*cos(t)
				var y: float = .31+.355*sin(t)
				var fraction: float = clampf(inverse_lerp(_upper(z,side).y,minf(_upper(z,side).y-.003,_arch_bottom(z)),y),0.0,1.0)
				var edge: Vector3 = _side_point(z,fraction,side)
				edge.y = y
				edge.x += side*.001
				arc.append(edge)
			jamb_z = wz - .360
			jamb_t = clampf(inverse_lerp(_upper(jamb_z,side).y,_arch_bottom(jamb_z),.18),0.0,1.0)
			jamb = _side_point(jamb_z,jamb_t,side)
			jamb.x += side*.001
			arc.append(jamb)
			_line(body,arc,.0075,paint)
			for k in range(arc.size()): arc[k].x-=side*.025
			_line(body,arc,.014,trim)
	# Smooth front and rear fascia caps, including slight transverse curvature.
	for end in [-1.0,1.0]:
		_param_surface(body,paint,"Rounded_end_fascia",36,10,
			func(t: float,u: float) -> Vector3:
				var x := lerpf(-.60,.60,t) if end < 0 else lerpf(-.68,.68,t)
				var width := .60 if end < 0 else .68
				var zz: float = end*2.1425 + end*.018*(1.0-pow(x/width,2.0))
				var top := _upper(end*2.1425,x/width).y
				return Vector3(x,lerpf(.17,top,u),zz),end<0.0)

func _pane(points: PackedVector3Array, name_: String) -> MeshInstance3D:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for i in range(1, points.size() - 1):
		_tri(st, points[0], points[i], points[i + 1])
	var n := _mesh(st, glass, body, name_)
	cabin_glass.append(n)
	_line(body, points + PackedVector3Array([points[0]]), 0.014, trim)
	return n

func _roof_point(t: float,u: float) -> Vector3:
	var z := lerpf(-.13,.74,t)
	var x := lerpf(.535,.52,t)*(u*2.0-1.0)
	var y := 1.182+.024*sin(t*PI)+.022*(1.0-pow(u*2.0-1.0,2.0))
	return Vector3(x,y,z)

func _build_glazing_and_roof() -> void:
	# A single coherent closed roof; no intersecting ellipsoid/sheet shells.
	_param_surface(body,paint,"Continuous_closed_roof",24,24,Callable(self,"_roof_point"))
	var lining := _mat(Color(.07,.075,.078),.95)
	_param_surface(body,lining,"Roof_lining",24,24,
		func(t: float,u: float) -> Vector3: return _roof_point(t,u)-Vector3(0,.020,0),true)
	for side in [-1.0,1.0]:
		var edge := PackedVector3Array()
		for i in range(29): edge.append(_roof_point(float(i)/28.0,.0 if side<0 else 1.0)-Vector3(0,.010,0))
		_line(body,edge,.013,paint)
	# Curved windscreen with explicit normals and a rounded upper border.
	var front_shape := func(t: float,u: float) -> Vector3:
		var x := (u*2.0-1.0)*lerpf(.66,.535,t)
		var dome := 1.0-pow(u*2.0-1.0,2.0)
		return Vector3(x,lerpf(.785,1.182,t)+.022*dome,lerpf(-.76,-.13,t)-.045*dome*(1.0-t))
	cabin_glass.append(_param_surface(body,glass,"Curved_windscreen",18,32,front_shape,true))
	for side in [-1.0,1.0]:
		var a := Vector3(side*.66,.785,-.76)
		var b := Vector3(side*.535,1.182,-.13)
		var c := Vector3(side*.52,1.182,.74)
		var d := Vector3(side*.71,.785,1.31)
		var e := Vector3(side*.735,.765,-.38)
		_pane(PackedVector3Array([a,b,c,d,e]),"Side_glass")
		_line(body,PackedVector3Array([a,Vector3(side*.61,.96,-.50),b]),.019,paint)
		_line(body,PackedVector3Array([c,Vector3(side*.60,1.05,.98),Vector3(side*.70,.79,1.46)]),.032,paint)
		# A genuine painted C-pillar bridges roof to rear quarter. The old thin tube
		# read like a roll cage and left the greenhouse visually convertible-like.
		_param_surface(body, paint, "Sculpted_C_pillar", 24, 8,
			func(t: float,u: float) -> Vector3:
				var x: float = side * (lerpf(.52,.72,t) + .005*sin(t*PI))
				var y: float = lerpf(1.182,.785,t)
				var z: float = lerpf(.74,1.46,t) - lerpf(.12,.23,t)*(1.0-u)
				return Vector3(x,y,z), side > 0.0)
		_line(body,PackedVector3Array([Vector3(side*.58,1.06,.94),Vector3(side*.72,.78,.94)]),.010,trim)
		_line(body,PackedVector3Array([a,Vector3(side*.735,.765,-.38),d]),.011,trim)
	var rear_shape := func(t: float,u: float) -> Vector3:
		var v := u*2.0-1.0
		return Vector3(v*lerpf(.52,.70,t),lerpf(1.182,.785,t)+.015*(1.0-v*v),lerpf(.74,1.46,t)+.018*(1.0-v*v)*t)
	cabin_glass.append(_param_surface(body,glass,"Curved_fastback",24,32,rear_shape))
	for end in [0.0,1.0]:
		var points := PackedVector3Array()
		for i in range(33): points.append(front_shape.call(end,float(i)/32.0))
		_line(body,points,.010,trim)
	var hatch_base := PackedVector3Array()
	for i in range(33): hatch_base.append(rear_shape.call(1.0,float(i)/32.0))
	_line(body,hatch_base,.013,trim)
	for side in [-1.0,1.0]:
		_line(body,PackedVector3Array([Vector3(side*.32,.805,-.76),Vector3(side*.47,.835,-.70),Vector3(side*.18,.845,-.69)]),.0045,trim)

func _build_exterior_details() -> void:
	# Continuous narrow shut lines trace hood and doors, inset close to the surface.
	var seams := _mat(Color(.13,.105,.037),.66)
	for side in [-1.0,1.0]:
		var hood := PackedVector3Array()
		for k in range(19):
			var z := lerpf(-1.91,-.76,float(k)/18.0)
			var p := _upper(z,side*.61)
			p.y += .003
			hood.append(p)
		_line(body,hood,.0035,seams)
		var door_gap := PackedVector3Array()
		var outline: Array[Vector2] = [Vector2(.70,-.60),Vector2(.49,-.59),Vector2(.245,-.49),Vector2(.225,.65),Vector2(.28,.78),Vector2(.70,.81)]
		for segment in range(outline.size()-1):
			for step in range(8):
				var yz: Vector2 = outline[segment].lerp(outline[segment+1],float(step)/7.0)
				var fraction: float = clampf(inverse_lerp(_upper(yz.y,side).y,minf(_upper(yz.y,side).y-.003,_arch_bottom(yz.y)),yz.x),0.0,1.0)
				var edge: Vector3 = _side_point(yz.y,fraction,side)
				edge.x += side*.0014
				door_gap.append(edge)
		_line(body,door_gap,.0018,seams)
		_box(body,Vector3(side*.839,.695,.65),Vector3(.013,.026,.105),trim,"Door_handle")
		var mirror := _ellipsoid(body,Vector3(side*.905,.875,-.47),Vector3(.19,.10,.19),paint)
		mirror.rotation.y = side*.16
		_line(body,PackedVector3Array([Vector3(side*.70,.82,-.39),Vector3(side*.86,.85,-.46)]),.022,trim)
		var mirror_glass := _ellipsoid(body,Vector3(side*.906,.874,-.384),Vector3(.13,.065,.009),_mat(Color(.30,.38,.40),.10,.86))
		mirror_glass.name="Decorative_nonfunctional_mirror"
		# Low flush indicator lens.
		_box(body,Vector3(side*.66,.365,-2.048),Vector3(.15,.039,.025),_mat(Color(.72,.30,.027),.21),"Front_indicator")
		var hinge := Node3D.new()
		hinge.name="Popup_hinge"
		body.add_child(hinge)
		hinge.position=Vector3(side*.535,.719,-1.37)
		popup_hinges.append(hinge)
		# Curved lid follows the actual bonnet surface, rather than a raised box.
		_param_surface(hinge, paint, "Flush_curved_popup_cover", 18, 14,
			func(t: float,u: float) -> Vector3:
				var local_x: float = lerpf(-.153,.153,u)
				var local_z: float = lerpf(-.345,-.012,t)
				var world_z: float = hinge.position.z + local_z
				var world_x: float = hinge.position.x + local_x
				var surface_y: float = _upper(world_z,world_x/_profile(world_z).y).y
				return Vector3(local_x,surface_y+.002-hinge.position.y,local_z))
		_box(hinge,Vector3(0,-.068,-.20),Vector3(.29,.065,.28),trim,"Popup_housing")
		var lamp := _box(hinge,Vector3(0,-.045,-.349),Vector3(.25,.072,.014),lamp_mat,"Headlamp_lens")
		lamp.rotation.x=-.80
		var light := SpotLight3D.new()
		light.position=Vector3(0,-.04,-.36)
		light.rotation.x=-.85
		light.light_color=Color(1.0,.91,.76)
		light.light_energy=2.0
		light.spot_range=45.0
		light.spot_angle=34.0
		light.shadow_enabled=false
		hinge.add_child(light)
		head_lights.append(light)
	# Lower grille, lip and tow-point detail.
	var grille := SurfaceTool.new()
	grille.begin(Mesh.PRIMITIVE_TRIANGLES)
	var grille_edge := PackedVector3Array()
	for k in range(49):
		var a := TAU * float(k) / 48.0
		# Superellipse provides softly rounded corners without intersecting the bumper plane.
		var x := .46 * signf(cos(a)) * pow(absf(cos(a)), .45)
		var y := .071 * signf(sin(a)) * pow(absf(sin(a)), .72)
		grille_edge.append(Vector3(x,.285+y,-2.164))
	for k in range(48):
		_tri(grille,Vector3(0,.285,-2.164),grille_edge[k+1],grille_edge[k])
	var grille_material: StandardMaterial3D = trim.duplicate()
	grille_material.cull_mode=BaseMaterial3D.CULL_DISABLED
	_mesh(grille,grille_material,body,"Rounded_front_intake")
	for x in [-.37,-.18,.0,.18,.37]:
		_box(body,Vector3(x,.285,-2.170),Vector3(.009,.110,.007),_mat(Color(.07,.075,.076),.7))
	_ellipsoid(body,Vector3(0,.184,-2.119),Vector3(1.25,.029,.11),trim).name="Curved_front_lip"
	# FD-like full-width black rear light panel, circular lens elements.
	_box(body,Vector3(0,.586,2.132),Vector3(1.30,.145,.035),trim,"Rear_light_panel")
	for side in [-1.0,1.0]:
		for x in [.345,.525]:
			var red := _cylinder(body,Vector3(side*x,.585,2.155),.056,.014,brake_mat,Vector3(PI/2,0,0))
			brake_lenses.append(red)
			_cylinder(body,Vector3(side*x,.585,2.166),.042,.004,brake_mat,Vector3(PI/2,0,0))
		_box(body,Vector3(side*.20,.584,2.154),Vector3(.085,.047,.017),_mat(Color(.67,.67,.62),.23),"Reverse_lens")
	_box(body,Vector3(0,.406,2.147),Vector3(.28,.075,.022),_mat(Color(.87,.88,.84),.75),"Rear_plate")
	_text(body,"FD  •  1991",Vector3(0,.408,2.162),.0019,Color(.10,.13,.15),Vector3(0,PI,0))
	_box(body,Vector3(0,.197,2.08),Vector3(1.21,.05,.13),trim,"Rear_valance")
	for x in [-.56,-.43]:
		_cylinder(body,Vector3(x,.205,2.164),.040,.15,alloy,Vector3(PI/2,0,0))
		_cylinder(body,Vector3(x,.205,2.242),.030,.005,trim,Vector3(PI/2,0,0))
	# Restrained factory-style rear wing and supports.
	for side in [-1.0,1.0]:
		_box(body,Vector3(side*.52,.786,1.84),Vector3(.05,.17,.08),paint,"Wing_support")
	var wing := _ellipsoid(body,Vector3(0,.868,1.87),Vector3(1.48,.055,.235),paint)
	wing.name="Low_rear_wing"

func _text(parent: Node3D, value: String, pos: Vector3, pixels: float, col: Color, rot: Vector3 = Vector3.ZERO) -> Label3D:
	var label := Label3D.new()
	label.text=value
	label.font_size=24
	label.pixel_size=pixels
	label.modulate=col
	label.outline_size=0
	label.position=pos
	label.rotation=rot
	label.no_depth_test=false
	parent.add_child(label)
	return label

func _build_cabin() -> void:
	var fabric := _mat(Color(.048,.055,.061),.98)
	var dash := _mat(Color(.040,.048,.053),.83)
	var accent := _mat(Color(.11,.13,.14),.72)
	_box(body,Vector3(0,.315,.26),Vector3(1.40,.035,1.75),trim,"Cabin_floor")
	# Two sculpted bucket seats; RHD driver's seat is +X.
	for side in [-1.0,1.0]:
		_ellipsoid(body,Vector3(side*.34,.417,.38),Vector3(.42,.17,.48),fabric)
		var back := _ellipsoid(body,Vector3(side*.34,.65,.65),Vector3(.40,.57,.15),fabric)
		back.rotation.x=-.14
		_ellipsoid(body,Vector3(side*.34,.915,.67),Vector3(.22,.19,.12),fabric)
		for bside in [-1.0,1.0]:
			_ellipsoid(body,Vector3(side*.34+bside*.175,.59,.59),Vector3(.07,.38,.16),accent)
		_line(body,PackedVector3Array([Vector3(side*.75,.74,-.48),Vector3(side*.75,.60,.7)]),.028,dash)
		_box(body,Vector3(side*.74,.47,.23),Vector3(.045,.26,1.0),fabric,"Door_card")
		_box(body,Vector3(side*.714,.635,.05),Vector3(.06,.035,.26),accent,"Door_armrest")
	# Low rounded dashboard, instrument binnacle, center stack.
	_ellipsoid(body,Vector3(0,.69,-.49),Vector3(1.40,.21,.36),dash)
	_box(body,Vector3(0,.56,-.37),Vector3(1.35,.24,.16),dash,"Lower_dash")
	_ellipsoid(body,Vector3(.33,.795,-.46),Vector3(.47,.17,.26),dash)
	_box(body,Vector3(0,.56,-.245),Vector3(.235,.29,.09),accent,"Center_stack")
	for z in [.05,.21]:
		_box(body,Vector3(0,.41,z),Vector3(.21,.16,.20),dash,"Console")
	_line(body,PackedVector3Array([Vector3(0,.48,.11),Vector3(0,.57,.08)]),.011,alloy)
	_ellipsoid(body,Vector3(0,.573,.08),Vector3(.039,.046,.039),trim)
	for x in [-.57,-.13,.13,.59]:
		_box(body,Vector3(x,.728,-.286),Vector3(.092,.038,.016),trim,"Dash_vent")
		for k in [-1,0,1]:
			_box(body,Vector3(x,.728+k*.010,-.275),Vector3(.08,.002,.008),accent)
	# Instruments face +Z toward the seated driver, with live analog needles.
	speed_needle=_gauge(Vector3(.447,.807,-.312),.062,"km/h",240.0)
	rpm_needle=_gauge(Vector3(.295,.810,-.301),.078,"rpm ×1000",9.0)
	for x in [-.062,0.0,.062]:
		_cylinder(body,Vector3(x,.532,-.19),.019,.012,trim,Vector3(PI/2,0,0))
	_box(body,Vector3(0,.623,-.19),Vector3(.16,.048,.012),trim,"Radio")
	_text(body,"FM  87.5",Vector3(0,.625,-.181),.0006,Color(.55,.74,.57))
	steering_pivot=Node3D.new()
	steering_pivot.name="Live_steering_wheel"
	steering_pivot.position=Vector3(.33,.75,-.135)
	steering_pivot.rotation.x=.15
	body.add_child(steering_pivot)
	var wheelpts := PackedVector3Array()
	for k in range(49):
		var a:=TAU*float(k)/48.0
		wheelpts.append(Vector3(cos(a)*.147,sin(a)*.147,0))
	_line(steering_pivot,wheelpts,.014,trim)
	for a in [0.0,PI,PI*1.5]:
		_line(steering_pivot,PackedVector3Array([Vector3.ZERO,Vector3(cos(a)*.135,sin(a)*.135,0)]),.016,accent)
	_ellipsoid(steering_pivot,Vector3.ZERO,Vector3(.105,.078,.038),trim)
	# Roof lining is restrained and does not cross the eye position.
	

func _gauge(pos: Vector3, radius: float, caption: String, maximum: float) -> Node3D:
	_cylinder(body,pos,radius+.005,.018,_mat(Color(.11,.13,.14),.72),Vector3(PI/2,0,0))
	_cylinder(body,pos+Vector3(0,0,.012),radius,.006,trim,Vector3(PI/2,0,0))
	var white := _mat(Color(.72,.77,.75),.68)
	for i in range(10):
		var a:=lerpf(deg_to_rad(220),deg_to_rad(-40),float(i)/9.0)
		var p0:=pos+Vector3(cos(a)*radius*.82,sin(a)*radius*.82,.017)
		var p1:=pos+Vector3(cos(a)*radius*.97,sin(a)*radius*.97,.017)
		_line(body,PackedVector3Array([p0,p1]),.0013,white)
		if i % 3 == 0:
			_text(body,str(roundi(maximum*float(i)/9.0)),pos+Vector3(cos(a)*radius*.62,sin(a)*radius*.62,.019),.00038,Color(.8,.85,.81))
	_text(body,caption,pos+Vector3(0,-radius*.33,.020),.0003,Color(.66,.73,.70))
	var needle:=Node3D.new()
	body.add_child(needle)
	needle.position=pos+Vector3(0,0,.023)
	_line(needle,PackedVector3Array([Vector3(-radius*.15,0,0),Vector3(radius*.81,0,0)]),.0018,_mat(Color(.92,.21,.055),.45))
	return needle

func _build_wheel(side: float, z: float) -> void:
	var mount:=Node3D.new()
	mount.name="Front_wheel" if z<0 else "Rear_wheel"
	mount.position=Vector3(side*.735,.31,z)
	add_child(mount)
	wheel_mounts.append(mount)
	var spin:=Node3D.new()
	mount.add_child(spin)
	wheel_spinners.append(spin)
	_param_surface(spin,rubber,"Analytic_treaded_tire_225_50_R16",96,24,
		func(t: float,u: float) -> Vector3:
			var a: float = TAU*t
			var b: float = TAU*u
			var rr: float = .259+.051*cos(b)
			return Vector3(.112*sin(b),rr*cos(a),rr*sin(a)))
	var diskmat:=_mat(Color(.30,.32,.32),.47,.82)
	_cylinder(spin,Vector3(side*.077,0,0),.163,.015,diskmat,Vector3(0,0,PI/2))
	var rotor_dark := _mat(Color(.055,.065,.067),.77,.45)
	for channel_radius in [.125,.144,.156]:
		var rotor_ring := PackedVector3Array()
		for k in range(65):
			var a: float = TAU*float(k)/64.0
			rotor_ring.append(Vector3(side*.086,cos(a)*channel_radius,sin(a)*channel_radius))
		_line(spin,rotor_ring,.0006,rotor_dark)
	for k in range(18):
		var a: float = TAU*float(k)/18.0
		_cylinder(spin,Vector3(side*.086,cos(a)*.137,sin(a)*.137),.0032,.0012,rotor_dark,Vector3(0,0,PI/2))
	# Rim barrel and a six-spoke alloy face, not a filled silver disk.
	var darkmetal:=_mat(Color(.12,.14,.16),.34,.77)
	var barrel_st:=SurfaceTool.new()
	barrel_st.begin(Mesh.PRIMITIVE_TRIANGLES)
	barrel_st.set_smooth_group(0)
	for k in range(48):
		var a0:=TAU*float(k)/48.0
		var a1:=TAU*float(k+1)/48.0
		_quad(barrel_st,Vector3(-.085,cos(a0)*.202,sin(a0)*.202),Vector3(.085,cos(a0)*.202,sin(a0)*.202),Vector3(.085,cos(a1)*.202,sin(a1)*.202),Vector3(-.085,cos(a1)*.202,sin(a1)*.202),true)
	_mesh(barrel_st,darkmetal,spin,"Open_rim_barrel")
	var ring:=PackedVector3Array()
	for k in range(49):
		var a:=TAU*float(k)/48.0
		ring.append(Vector3(side*.105,cos(a)*.198,sin(a)*.198))
	_line(spin,ring,.013,alloy)
	for k in range(5):
		var a: float = TAU*float(k)/5.0
		# Tapered cast spokes have curved faces and a slight sweep, so highlights
		# describe the metal instead of a rectangular cart-wheel cross section.
		_param_surface(spin,alloy,"Sculpted_cast_spoke",14,10,
			func(t: float,u: float) -> Vector3:
				var angle: float = a + .10*sin(t*PI)
				var radius: float = lerpf(.040,.195,t)
				var width: float = lerpf(.021,.013,t)
				var section: float = TAU*u
				var tangent: float = sin(section)*width
				return Vector3(side*(.108+cos(section)*.010),cos(angle)*radius-sin(angle)*tangent,sin(angle)*radius+cos(angle)*tangent),side<0.0)
	_cylinder(spin,Vector3(side*.119,0,0),.046,.018,alloy,Vector3(0,0,PI/2))
	for k in range(5):
		var a:=TAU*float(k)/5.0
		_cylinder(spin,Vector3(side*.130,cos(a)*.032,sin(a)*.032),.006,.006,trim,Vector3(0,0,PI/2))
	# Sidewall moulding and restrained tread channels.
	for rad in [.23,.282]:
		var rimline:=PackedVector3Array()
		for k in range(49):
			var a:=TAU*float(k)/48.0
			rimline.append(Vector3(side*.089,cos(a)*rad,sin(a)*rad))
		_line(spin,rimline,.0015,_mat(Color(.075,.079,.077),.94))
	_text(spin,"CIRCUIT SPORT",Vector3(side*.108,.245,0),.00075,Color(.16,.17,.17),Vector3(0,side*PI/2,0))
	_box(mount,Vector3(side*.093,.10,-.088),Vector3(.034,.105,.05),_mat(Color(.28,.15,.075),.72),"Fixed_brake_caliper")

func update_visuals(speed: float, steer: float, brake: float, rpm: float, dt: float, headlights: bool) -> void:
	if not is_instance_valid(body):
		return
	wheel_angle=fmod(wheel_angle-speed*dt/.31,TAU)
	for i in range(wheel_spinners.size()):
		wheel_spinners[i].rotation.x=wheel_angle
		wheel_mounts[i].rotation.y=steer if wheel_mounts[i].position.z < 0.0 else 0.0
	popup_amount=move_toward(popup_amount,1.0 if headlights else 0.0,dt*2.0)
	for hinge in popup_hinges:
		hinge.rotation.x=popup_amount*deg_to_rad(46.0)
	for light in head_lights:
		light.visible=headlights and popup_amount>.92
	for lens in brake_lenses:
		lens.material_override=brake_on_mat if brake>.04 else brake_mat
	if is_instance_valid(steering_pivot):
		steering_pivot.rotation.z=-steer*5.8
	if is_instance_valid(speed_needle):
		speed_needle.rotation.z=lerp_angle(speed_needle.rotation.z,deg_to_rad(lerpf(220.0,-40.0,clampf(absf(speed)*3.6/240.0,0,1))),1.0-exp(-dt*12.0))
	if is_instance_valid(rpm_needle):
		rpm_needle.rotation.z=lerp_angle(rpm_needle.rotation.z,deg_to_rad(lerpf(220.0,-40.0,clampf(rpm/9000.0,0,1))),1.0-exp(-dt*12.0))

func set_cockpit_mode(active: bool) -> void:
	cockpit_active=active
	# No opaque tint over the road in driver view; exterior window geometry remains present otherwise.
	for pane in cabin_glass:
		pane.visible=not active
