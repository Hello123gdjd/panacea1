class_name CarModel
extends Node3D
## Original, approximate FD-inspired mesh. Forward is -Z, dimensions are metres.

var wheel_mounts: Array[Node3D] = []
var wheel_spinners: Array[Node3D] = []
var popup_hinges: Array[Node3D] = []
var brake_lenses: Array[MeshInstance3D] = []
var cabin_glass: Array[MeshInstance3D] = []
var head_lights: Array[SpotLight3D] = []
var steering_pivot: Node3D
var speed_needle: Node3D
var rpm_needle: Node3D
var body: Node3D
var paint: StandardMaterial3D
var rubber: StandardMaterial3D
var trim: StandardMaterial3D
var glass: StandardMaterial3D
var alloy: StandardMaterial3D
var brake_mat: StandardMaterial3D
var brake_on_mat: StandardMaterial3D
var lamp_mat: StandardMaterial3D
var popup_amount := 0.0
var wheel_angle := 0.0
var cockpit_active := false

func _ready() -> void:
	paint = _mat(Color(0.74, 0.48, 0.028), 0.30, 0.0)
	paint.clearcoat_enabled = true
	paint.clearcoat = 0.78
	paint.clearcoat_roughness = 0.19
	rubber = _mat(Color(0.023, 0.025, 0.026), 0.92)
	trim = _mat(Color(0.025, 0.029, 0.031), 0.67)
	alloy = _mat(Color(0.51, 0.54, 0.57), 0.28, 0.87)
	glass = _mat(Color(0.19, 0.26, 0.29, 0.30), 0.12, 0.12)
	glass.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	glass.cull_mode = BaseMaterial3D.CULL_DISABLED
	brake_mat = _mat(Color(0.29, 0.009, 0.008), 0.26)
	brake_on_mat = _mat(Color(0.95, 0.035, 0.012), 0.24)
	brake_on_mat.emission_enabled = true
	brake_on_mat.emission = Color(1.0, 0.04, 0.012)
	brake_on_mat.emission_energy_multiplier = 2.0
	lamp_mat = _mat(Color(0.86, 0.89, 0.80), 0.18, 0.12)
	body = Node3D.new()
	body.name = "Body"
	add_child(body)
	_build_shell()
	_build_glazing_and_roof()
	_build_exterior_details()
	_build_cabin()
	for side in [-1.0, 1.0]:
		for z in [-1.2125, 1.2125]:
			_build_wheel(side, z)

func _mat(col: Color, rough: float, metal: float = 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = col
	m.roughness = rough
	m.metallic = metal
	return m

func _mesh(st: SurfaceTool, material: Material, parent: Node3D, mesh_name: String = "Detail") -> MeshInstance3D:
	st.generate_normals()
	var n := MeshInstance3D.new()
	n.name = mesh_name
	n.mesh = st.commit()
	n.material_override = material
	parent.add_child(n)
	return n

func _tri(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3) -> void:
	st.add_vertex(a)
	st.add_vertex(c)
	st.add_vertex(b)

func _quad(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, d: Vector3, flip: bool = false) -> void:
	if flip:
		_tri(st, a, c, b)
		_tri(st, a, d, c)
	else:
		_tri(st, a, b, c)
		_tri(st, a, c, d)

func _box(parent: Node3D, pos: Vector3, size: Vector3, material: Material, mesh_name: String = "Detail") -> MeshInstance3D:
	var n := MeshInstance3D.new()
	n.name = mesh_name
	var m := BoxMesh.new()
	m.size = size
	n.mesh = m
	n.material_override = material
	n.position = pos
	parent.add_child(n)
	return n

func _ellipsoid(parent: Node3D, pos: Vector3, size: Vector3, material: Material) -> MeshInstance3D:
	var n := MeshInstance3D.new()
	var m := SphereMesh.new()
	m.radius = 0.5
	m.height = 1.0
	m.radial_segments = 32
	m.rings = 16
	n.mesh = m
	n.position = pos
	n.scale = size
	n.material_override = material
	parent.add_child(n)
	return n

func _cylinder(parent: Node3D, pos: Vector3, radius: float, height: float, material: Material, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var n := MeshInstance3D.new()
	var m := CylinderMesh.new()
	m.top_radius = radius
	m.bottom_radius = radius
	m.height = height
	m.radial_segments = 40
	n.mesh = m
	n.position = pos
	n.rotation = rot
	n.material_override = material
	parent.add_child(n)
	return n

func _line(parent: Node3D, points: PackedVector3Array, radius: float, material: Material) -> void:
	# One mesh per polyline rather than a node per segment.
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	st.set_smooth_group(0)
	for i in range(points.size() - 1):
		var a := points[i]
		var b := points[i + 1]
		var tangent := (b - a).normalized()
		var axis := Vector3.UP if absf(tangent.dot(Vector3.UP)) < 0.95 else Vector3.RIGHT
		var right := tangent.cross(axis).normalized() * radius
		var up := tangent.cross(right).normalized() * radius
		for j in range(6):
			var t0 := TAU * float(j) / 6.0
			var t1 := TAU * float(j + 1) / 6.0
			var r0 := right * cos(t0) + up * sin(t0)
			var r1 := right * cos(t1) + up * sin(t1)
			_quad(st, a + r0, b + r0, b + r1, a + r1, true)
	_mesh(st, material, parent, "Contour")

func _profile(z: float) -> Vector3:
	# z, half-width, hood/shoulder elevation. Smoothed interpolation preserves rounded FD silhouette.
	var sections := [Vector3(-2.1425, 0.61, 0.46), Vector3(-2.03, 0.76, 0.56), Vector3(-1.76, 0.835, 0.665), Vector3(-1.25, 0.88, 0.735), Vector3(-0.70, 0.825, 0.755), Vector3(0.0, 0.82, 0.745), Vector3(0.72, 0.84, 0.75), Vector3(1.25, 0.88, 0.745), Vector3(1.81, 0.83, 0.70), Vector3(2.04, 0.77, 0.65), Vector3(2.1425, 0.68, 0.58)]
	for i in range(sections.size() - 1):
		if z <= sections[i + 1].x:
			var t: float = inverse_lerp(sections[i].x, sections[i + 1].x, z)
			# Nonuniform cubic Hermite interpolation maintains a shared derivative at every station.
			# The old per-span smoothstep reset derivatives at every station, causing rippled highlights.
			var before: Vector3 = sections[maxi(i - 1, 0)]
			var after: Vector3 = sections[mini(i + 2, sections.size() - 1)]
			var span: float = sections[i + 1].x - sections[i].x
			var m0: Vector3 = (sections[i + 1] - before) / (sections[i + 1].x - before.x)
			var m1: Vector3 = (after - sections[i]) / (after.x - sections[i].x)
			var t2: float = t * t
			var t3: float = t2 * t
			var interpolated: Vector3 = sections[i] * (2.0*t3-3.0*t2+1.0) + m0*span*(t3-2.0*t2+t) + sections[i+1]*(-2.0*t3+3.0*t2) + m1*span*(t3-t2)
			interpolated.x = z
			interpolated.y = minf(interpolated.y, 0.88)
			return interpolated
	return sections[-1]

func _upper(z: float, u: float) -> Vector3:
	var p := _profile(z)
	# Rounded fender crowns sit slightly above the central bonnet, avoiding a single wedge slab.
	var crown: float = 0.028 * exp(-pow((absf(u) - 0.76) / 0.19, 2.0))
	var bonnet_dip: float = 0.017 * exp(-pow(u / 0.53, 2.0))
	return Vector3(p.y * u, p.z - 0.058 * pow(absf(u), 4.0) + crown - bonnet_dip, z)

func _arch_bottom(z: float) -> float:
	var lower := 0.29
	for wz in [-1.2125, 1.2125]:
		var d: float = absf(z - wz)
		if d < 0.355:
			lower = maxf(lower, 0.31 + sqrt(maxf(0.0, 0.355 * 0.355 - d * d)))
	return lower

func _build_shell() -> void:
	var top := SurfaceTool.new()
	top.begin(Mesh.PRIMITIVE_TRIANGLES)
	top.set_smooth_group(0)
	var sides := SurfaceTool.new()
	sides.begin(Mesh.PRIMITIVE_TRIANGLES)
	sides.set_smooth_group(0)
	var count := 128
	for i in range(count):
		var z0 := lerpf(-2.1425, 2.1425, float(i) / count)
		var z1 := lerpf(-2.1425, 2.1425, float(i + 1) / count)
		for j in range(24):
			var u0 := lerpf(-1.0, 1.0, float(j) / 24.0)
			var u1 := lerpf(-1.0, 1.0, float(j + 1) / 24.0)
			# Leave the cabin open beneath the roof and glass, rather than a yellow solid slab through the seats.
			if not (z0 > -0.69 and z1 < 1.46 and absf((u0 + u1) * 0.5) < 0.81):
				_quad(top, _upper(z0, u0), _upper(z1, u0), _upper(z1, u1), _upper(z0, u1))
		for side in [-1.0, 1.0]:
			var a := _upper(z0, side)
			var b := _upper(z1, side)
			var lower0 := minf(a.y - 0.005, _arch_bottom(z0))
			var lower1 := minf(b.y - 0.005, _arch_bottom(z1))
			for k in range(6):
				var t0 := float(k) / 6.0
				var t1 := float(k + 1) / 6.0
				var va := Vector3(a.x * (1.0 - .055 * t0) + side * sin(t0 * PI) * .014,lerpf(a.y, lower0, t0),z0)
				var vb := Vector3(b.x * (1.0 - .055 * t0) + side * sin(t0 * PI) * .014,lerpf(b.y, lower1, t0),z1)
				var vc := Vector3(b.x * (1.0 - .055 * t1) + side * sin(t1 * PI) * .014,lerpf(b.y, lower1, t1),z1)
				var vd := Vector3(a.x * (1.0 - .055 * t1) + side * sin(t1 * PI) * .014,lerpf(a.y, lower0, t1),z0)
				_quad(sides, va, vb, vc, vd, side < 0.0)
	_mesh(top, paint, body, "Continuous_curved_body")
	_mesh(sides, paint, body, "Cutout_wheel_arches")
	# Close nose and tail, leaving visible bumpers fully solid.
	for z in [-2.1425, 2.1425]:
		var p := _profile(z)
		var st := SurfaceTool.new()
		st.begin(Mesh.PRIMITIVE_TRIANGLES)
		_quad(st, Vector3(-p.y, p.z - 0.058, z), Vector3(p.y, p.z - 0.058, z), Vector3(p.y * 0.97, 0.29, z), Vector3(-p.y * 0.97, 0.29, z), z > 0.0)
		_mesh(st, paint, body, "Bumper")
	# Lower sill remains interrupted at the four wheel apertures.
	for side in [-1.0, 1.0]:
		_box(body, Vector3(side * 0.794, 0.305, 0.0), Vector3(0.06, 0.055, 1.67), paint, "Side_sill")
		for wz in [-1.2125, 1.2125]:
			var arc := PackedVector3Array()
			for k in range(33):
				var t := PI * float(k) / 32.0
				var z: float = wz + 0.356 * cos(t)
				arc.append(Vector3(_profile(z).y * side + 0.001 * side, 0.31 + 0.356 * sin(t), z))
			_line(body, arc, 0.012, paint)
			# Dark recessed arch liner gives depth without covering the visible tire.
			for k in range(arc.size()):
				arc[k].x -= side * 0.032
			_line(body, arc, 0.017, trim)

func _pane(points: PackedVector3Array, name_: String) -> MeshInstance3D:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for i in range(1, points.size() - 1):
		_tri(st, points[0], points[i], points[i + 1])
	var n := _mesh(st, glass, body, name_)
	cabin_glass.append(n)
	_line(body, points + PackedVector3Array([points[0]]), 0.014, trim)
	return n

func _build_glazing_and_roof() -> void:
	# Curved windshield segmented across width, with coherent A pillars.
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	st.set_smooth_group(0)
	for j in range(24):
		var u0 := lerpf(-1.0, 1.0, float(j) / 24.0)
		var u1 := lerpf(-1.0, 1.0, float(j + 1) / 24.0)
		var a := Vector3(u0 * 0.66, 0.773 + 0.025 * (1.0-u0*u0), -0.69 - 0.065*(1.0-u0*u0))
		var b := Vector3(u1 * 0.66, 0.773 + 0.025 * (1.0-u1*u1), -0.69 - 0.065*(1.0-u1*u1))
		var c := Vector3(u1 * 0.52, 1.177 + 0.022*(1.0-u1*u1), -0.035)
		var d := Vector3(u0 * 0.52, 1.177 + 0.022*(1.0-u0*u0), -0.035)
		_quad(st,a,b,c,d)
	cabin_glass.append(_mesh(st, glass, body, "Curved_windscreen"))
	# Smooth roof, low and gently arched in both axes.
	var roof := SurfaceTool.new()
	roof.begin(Mesh.PRIMITIVE_TRIANGLES)
	roof.set_smooth_group(0)
	for i in range(16):
		for j in range(20):
			var verts := PackedVector3Array()
			for ij in [Vector2(i,j),Vector2(i+1,j),Vector2(i+1,j+1),Vector2(i,j+1)]:
				var t: float = ij.x / 16.0
				var u: float = ij.y / 20.0 * 2.0 - 1.0
				verts.append(Vector3(u * lerpf(0.52,0.515,t), 1.18 + sin(t*PI)*0.027 + (1.0-u*u)*0.022, lerpf(-0.035,0.675,t)))
			_quad(roof,verts[0],verts[1],verts[2],verts[3])
	var roof_paint: StandardMaterial3D = paint.duplicate()
	roof_paint.cull_mode = BaseMaterial3D.CULL_DISABLED
	_mesh(roof,roof_paint,body,"Curved_roof")
	# A closed, shallow curved roof gives the thin sheet a solid underside and sealed perimeter.
	_ellipsoid(body,Vector3(0,1.194,.32),Vector3(1.07,.068,.84),paint).name="Sealed_roof_shell"
	for side in [-1.0,1.0]:
		var a := Vector3(side*0.66,0.773,-0.69)
		var b := Vector3(side*0.52,1.177,-0.035)
		var c := Vector3(side*0.515,1.18,0.675)
		var d := Vector3(side*0.71,0.785,1.18)
		var e := Vector3(side*0.735,0.765,-0.39)
		_pane(PackedVector3Array([a,b,c,d,e]),"Side_glass")
		_line(body,PackedVector3Array([a,b]),0.024,paint)
		_line(body,PackedVector3Array([b,c]),0.022,paint)
		_line(body,PackedVector3Array([c,Vector3(side*0.69,0.79,1.46)]),0.042,paint)
		_line(body,PackedVector3Array([Vector3(side*0.59,1.05,0.90),Vector3(side*0.72,0.785,0.90)]),0.015,trim)
		_line(body,PackedVector3Array([a,Vector3(side*0.52,1.177,-0.035)]),0.014,trim)
	# Broad hatch glass, characteristic rear fastback rather than a box cabin.
	var rear := SurfaceTool.new()
	rear.begin(Mesh.PRIMITIVE_TRIANGLES)
	rear.set_smooth_group(0)
	for j in range(24):
		var u0 := lerpf(-1.0,1.0,float(j)/24.0)
		var u1 := lerpf(-1.0,1.0,float(j+1)/24.0)
		_quad(rear,Vector3(u0*.515,1.18,.675),Vector3(u1*.515,1.18,.675),Vector3(u1*.69,.785,1.46),Vector3(u0*.69,.785,1.46),true)
	cabin_glass.append(_mesh(rear,glass,body,"Fastback_rear_glass"))
	_line(body,PackedVector3Array([Vector3(-.69,.786,1.46),Vector3(0,.795,1.49),Vector3(.69,.786,1.46)]),.019,trim)
	# Windshield cowl hides the cabin floor at the base; wipers sit on the glass.
	_line(body,PackedVector3Array([Vector3(-.66,.777,-.69),Vector3(0,.799,-.755),Vector3(.66,.777,-.69)]),.022,trim)
	for side in [-1.0,1.0]:
		_line(body,PackedVector3Array([Vector3(side*.30,.80,-.73),Vector3(side*.46,.84,-.67),Vector3(side*.19,.85,-.66)]),.006,trim)

func _build_exterior_details() -> void:
	# Continuous narrow shut lines trace hood and doors, inset close to the surface.
	var seams := _mat(Color(.13,.105,.037),.66)
	for side in [-1.0,1.0]:
		var hood := PackedVector3Array()
		for k in range(19):
			var z := lerpf(-1.91,-.76,float(k)/18.0)
			var p := _upper(z,side*.61)
			p.y += .003
			hood.append(p)
		_line(body,hood,.0035,seams)
		_line(body,PackedVector3Array([Vector3(side*.814,.69,-.58),Vector3(side*.809,.47,-.52),Vector3(side*.795,.36,-.42),Vector3(side*.795,.355,.77),Vector3(side*.828,.49,.87),Vector3(side*.838,.72,.87)]),.004,seams)
		_box(body,Vector3(side*.839,.695,.65),Vector3(.013,.026,.105),trim,"Door_handle")
		var mirror := _ellipsoid(body,Vector3(side*.905,.875,-.47),Vector3(.19,.10,.19),paint)
		mirror.rotation.y = side*.16
		_line(body,PackedVector3Array([Vector3(side*.70,.82,-.39),Vector3(side*.86,.85,-.46)]),.022,trim)
		var mirror_glass := _ellipsoid(body,Vector3(side*.906,.874,-.384),Vector3(.13,.065,.009),_mat(Color(.30,.38,.40),.10,.86))
		mirror_glass.name="Decorative_nonfunctional_mirror"
		# Low flush indicator lens.
		_box(body,Vector3(side*.66,.418,-2.048),Vector3(.15,.039,.025),_mat(Color(.72,.30,.027),.21),"Front_indicator")
		var hinge := Node3D.new()
		hinge.name="Popup_hinge"
		body.add_child(hinge)
		hinge.position=Vector3(side*.535,.719,-1.37)
		popup_hinges.append(hinge)
		var cover := _box(hinge,Vector3(0,-.024,-.18),Vector3(.31,.014,.345),paint,"Popup_cover")
		cover.rotation.x=-.12
		_box(hinge,Vector3(0,-.068,-.20),Vector3(.29,.065,.28),trim,"Popup_housing")
		var lamp := _box(hinge,Vector3(0,-.045,-.349),Vector3(.25,.072,.014),lamp_mat,"Headlamp_lens")
		lamp.rotation.x=-.80
		var light := SpotLight3D.new()
		light.position=Vector3(0,-.04,-.36)
		light.rotation.x=-.85
		light.light_color=Color(1.0,.91,.76)
		light.light_energy=2.0
		light.spot_range=45.0
		light.spot_angle=34.0
		light.shadow_enabled=false
		hinge.add_child(light)
		head_lights.append(light)
	# Lower grille, lip and tow-point detail.
	var grille := SurfaceTool.new()
	grille.begin(Mesh.PRIMITIVE_TRIANGLES)
	var grille_edge := PackedVector3Array()
	for k in range(49):
		var a := TAU * float(k) / 48.0
		# Superellipse provides softly rounded corners without intersecting the bumper plane.
		var x := .46 * signf(cos(a)) * pow(absf(cos(a)), .45)
		var y := .053 * signf(sin(a)) * pow(absf(sin(a)), .72)
		grille_edge.append(Vector3(x,.385+y,-2.164))
	for k in range(48):
		_tri(grille,Vector3(0,.385,-2.164),grille_edge[k+1],grille_edge[k])
	var grille_material: StandardMaterial3D = trim.duplicate()
	grille_material.cull_mode=BaseMaterial3D.CULL_DISABLED
	_mesh(grille,grille_material,body,"Rounded_front_intake")
	for x in [-.37,-.18,.0,.18,.37]:
		_box(body,Vector3(x,.385,-2.170),Vector3(.009,.085,.007),_mat(Color(.07,.075,.076),.7))
	_ellipsoid(body,Vector3(0,.302,-2.119),Vector3(1.25,.029,.11),trim).name="Curved_front_lip"
	# FD-like full-width black rear light panel, circular lens elements.
	_box(body,Vector3(0,.586,2.132),Vector3(1.30,.145,.035),trim,"Rear_light_panel")
	for side in [-1.0,1.0]:
		for x in [.345,.525]:
			var red := _cylinder(body,Vector3(side*x,.585,2.155),.056,.014,brake_mat,Vector3(PI/2,0,0))
			brake_lenses.append(red)
			_cylinder(body,Vector3(side*x,.585,2.166),.042,.004,brake_mat,Vector3(PI/2,0,0))
		_box(body,Vector3(side*.20,.584,2.154),Vector3(.085,.047,.017),_mat(Color(.67,.67,.62),.23),"Reverse_lens")
	_box(body,Vector3(0,.406,2.147),Vector3(.28,.075,.022),_mat(Color(.87,.88,.84),.75),"Rear_plate")
	_text(body,"FD  •  1991",Vector3(0,.408,2.162),.0019,Color(.10,.13,.15),Vector3(0,PI,0))
	_box(body,Vector3(0,.284,2.08),Vector3(1.21,.065,.13),trim,"Rear_valance")
	for x in [-.56,-.43]:
		_cylinder(body,Vector3(x,.283,2.164),.040,.15,alloy,Vector3(PI/2,0,0))
		_cylinder(body,Vector3(x,.283,2.242),.030,.005,trim,Vector3(PI/2,0,0))
	# Restrained factory-style rear wing and supports.
	for side in [-1.0,1.0]:
		_box(body,Vector3(side*.52,.786,1.84),Vector3(.05,.17,.08),paint,"Wing_support")
	var wing := _ellipsoid(body,Vector3(0,.868,1.87),Vector3(1.48,.055,.235),paint)
	wing.name="Low_rear_wing"

func _text(parent: Node3D, value: String, pos: Vector3, pixels: float, col: Color, rot: Vector3 = Vector3.ZERO) -> Label3D:
	var label := Label3D.new()
	label.text=value
	label.font_size=24
	label.pixel_size=pixels
	label.modulate=col
	label.outline_size=0
	label.position=pos
	label.rotation=rot
	label.no_depth_test=false
	parent.add_child(label)
	return label

func _build_cabin() -> void:
	var fabric := _mat(Color(.048,.055,.061),.98)
	var dash := _mat(Color(.040,.048,.053),.83)
	var accent := _mat(Color(.11,.13,.14),.72)
	_box(body,Vector3(0,.315,.26),Vector3(1.40,.035,1.75),trim,"Cabin_floor")
	# Two sculpted bucket seats; RHD driver's seat is +X.
	for side in [-1.0,1.0]:
		_ellipsoid(body,Vector3(side*.34,.417,.38),Vector3(.42,.17,.48),fabric)
		var back := _ellipsoid(body,Vector3(side*.34,.65,.65),Vector3(.40,.57,.15),fabric)
		back.rotation.x=-.14
		_ellipsoid(body,Vector3(side*.34,.915,.67),Vector3(.22,.19,.12),fabric)
		for bside in [-1.0,1.0]:
			_ellipsoid(body,Vector3(side*.34+bside*.175,.59,.59),Vector3(.07,.38,.16),accent)
		_line(body,PackedVector3Array([Vector3(side*.75,.74,-.48),Vector3(side*.75,.60,.7)]),.028,dash)
		_box(body,Vector3(side*.74,.47,.23),Vector3(.045,.26,1.0),fabric,"Door_card")
		_box(body,Vector3(side*.714,.635,.05),Vector3(.06,.035,.26),accent,"Door_armrest")
	# Low rounded dashboard, instrument binnacle, center stack.
	_ellipsoid(body,Vector3(0,.69,-.49),Vector3(1.40,.21,.36),dash)
	_box(body,Vector3(0,.56,-.37),Vector3(1.35,.24,.16),dash,"Lower_dash")
	_ellipsoid(body,Vector3(.33,.795,-.46),Vector3(.47,.17,.26),dash)
	_box(body,Vector3(0,.56,-.245),Vector3(.235,.29,.09),accent,"Center_stack")
	for z in [.05,.21]:
		_box(body,Vector3(0,.41,z),Vector3(.21,.16,.20),dash,"Console")
	_line(body,PackedVector3Array([Vector3(0,.48,.11),Vector3(0,.57,.08)]),.011,alloy)
	_ellipsoid(body,Vector3(0,.573,.08),Vector3(.039,.046,.039),trim)
	for x in [-.57,-.13,.13,.59]:
		_box(body,Vector3(x,.728,-.286),Vector3(.092,.038,.016),trim,"Dash_vent")
		for k in [-1,0,1]:
			_box(body,Vector3(x,.728+k*.010,-.275),Vector3(.08,.002,.008),accent)
	# Instruments face +Z toward the seated driver, with live analog needles.
	speed_needle=_gauge(Vector3(.447,.807,-.312),.062,"km/h",240.0)
	rpm_needle=_gauge(Vector3(.295,.810,-.301),.078,"rpm ×1000",9.0)
	for x in [-.062,0.0,.062]:
		_cylinder(body,Vector3(x,.532,-.19),.019,.012,trim,Vector3(PI/2,0,0))
	_box(body,Vector3(0,.623,-.19),Vector3(.16,.048,.012),trim,"Radio")
	_text(body,"FM  87.5",Vector3(0,.625,-.181),.0006,Color(.55,.74,.57))
	steering_pivot=Node3D.new()
	steering_pivot.name="Live_steering_wheel"
	steering_pivot.position=Vector3(.33,.75,-.135)
	steering_pivot.rotation.x=.15
	body.add_child(steering_pivot)
	var wheelpts := PackedVector3Array()
	for k in range(49):
		var a:=TAU*float(k)/48.0
		wheelpts.append(Vector3(cos(a)*.147,sin(a)*.147,0))
	_line(steering_pivot,wheelpts,.014,trim)
	for a in [0.0,PI,PI*1.5]:
		_line(steering_pivot,PackedVector3Array([Vector3.ZERO,Vector3(cos(a)*.135,sin(a)*.135,0)]),.016,accent)
	_ellipsoid(steering_pivot,Vector3.ZERO,Vector3(.105,.078,.038),trim)
	# Roof lining is restrained and does not cross the eye position.
	_box(body,Vector3(0,1.176,.34),Vector3(.93,.018,.57),fabric,"Roof_lining")

func _gauge(pos: Vector3, radius: float, caption: String, maximum: float) -> Node3D:
	_cylinder(body,pos,radius+.005,.018,_mat(Color(.11,.13,.14),.72),Vector3(PI/2,0,0))
	_cylinder(body,pos+Vector3(0,0,.012),radius,.006,trim,Vector3(PI/2,0,0))
	var white := _mat(Color(.72,.77,.75),.68)
	for i in range(10):
		var a:=lerpf(deg_to_rad(220),deg_to_rad(-40),float(i)/9.0)
		var p0:=pos+Vector3(cos(a)*radius*.82,sin(a)*radius*.82,.017)
		var p1:=pos+Vector3(cos(a)*radius*.97,sin(a)*radius*.97,.017)
		_line(body,PackedVector3Array([p0,p1]),.0013,white)
		if i % 3 == 0:
			_text(body,str(roundi(maximum*float(i)/9.0)),pos+Vector3(cos(a)*radius*.62,sin(a)*radius*.62,.019),.00038,Color(.8,.85,.81))
	_text(body,caption,pos+Vector3(0,-radius*.33,.020),.0003,Color(.66,.73,.70))
	var needle:=Node3D.new()
	body.add_child(needle)
	needle.position=pos+Vector3(0,0,.023)
	_line(needle,PackedVector3Array([Vector3(-radius*.15,0,0),Vector3(radius*.81,0,0)]),.0018,_mat(Color(.92,.21,.055),.45))
	return needle

func _build_wheel(side: float, z: float) -> void:
	var mount:=Node3D.new()
	mount.name="Front_wheel" if z<0 else "Rear_wheel"
	mount.position=Vector3(side*.735,.31,z)
	add_child(mount)
	wheel_mounts.append(mount)
	var spin:=Node3D.new()
	mount.add_child(spin)
	wheel_spinners.append(spin)
	var tire:=SurfaceTool.new()
	tire.begin(Mesh.PRIMITIVE_TRIANGLES)
	tire.set_smooth_group(0)
	for i in range(64):
		for j in range(16):
			var verts:=PackedVector3Array()
			for ij in [Vector2(i,j),Vector2(i+1,j),Vector2(i+1,j+1),Vector2(i,j+1)]:
				var a:float=TAU*ij.x/64.0
				var b:float=TAU*ij.y/16.0
				var rr:float=.259+.051*cos(b)
				verts.append(Vector3(.112*sin(b),rr*cos(a),rr*sin(a)))
			_quad(tire,verts[0],verts[1],verts[2],verts[3])
	_mesh(tire,rubber,spin,"Rounded_tire_225_50_R16")
	var diskmat:=_mat(Color(.30,.32,.32),.47,.82)
	_cylinder(spin,Vector3(side*.077,0,0),.163,.015,diskmat,Vector3(0,0,PI/2))
	# Rim barrel and a six-spoke alloy face, not a filled silver disk.
	var darkmetal:=_mat(Color(.12,.14,.16),.34,.77)
	var barrel_st:=SurfaceTool.new()
	barrel_st.begin(Mesh.PRIMITIVE_TRIANGLES)
	barrel_st.set_smooth_group(0)
	for k in range(48):
		var a0:=TAU*float(k)/48.0
		var a1:=TAU*float(k+1)/48.0
		_quad(barrel_st,Vector3(-.085,cos(a0)*.202,sin(a0)*.202),Vector3(.085,cos(a0)*.202,sin(a0)*.202),Vector3(.085,cos(a1)*.202,sin(a1)*.202),Vector3(-.085,cos(a1)*.202,sin(a1)*.202),true)
	_mesh(barrel_st,darkmetal,spin,"Open_rim_barrel")
	var ring:=PackedVector3Array()
	for k in range(49):
		var a:=TAU*float(k)/48.0
		ring.append(Vector3(side*.105,cos(a)*.198,sin(a)*.198))
	_line(spin,ring,.013,alloy)
	for k in range(6):
		var a:=TAU*float(k)/6.0
		var spoke:=_box(spin,Vector3(side*.109,cos(a)*.119,sin(a)*.119),Vector3(.020,.15,.034),alloy,"Alloy_spoke")
		spoke.rotation.x=a
	_cylinder(spin,Vector3(side*.119,0,0),.046,.018,alloy,Vector3(0,0,PI/2))
	for k in range(5):
		var a:=TAU*float(k)/5.0
		_cylinder(spin,Vector3(side*.130,cos(a)*.032,sin(a)*.032),.006,.006,trim,Vector3(0,0,PI/2))
	# Sidewall moulding and restrained tread channels.
	for rad in [.23,.282]:
		var rimline:=PackedVector3Array()
		for k in range(49):
			var a:=TAU*float(k)/48.0
			rimline.append(Vector3(side*.089,cos(a)*rad,sin(a)*rad))
		_line(spin,rimline,.0015,_mat(Color(.075,.079,.077),.94))
	_box(mount,Vector3(side*.093,.10,-.088),Vector3(.034,.105,.05),_mat(Color(.28,.15,.075),.72),"Fixed_brake_caliper")

func update_visuals(speed: float, steer: float, brake: float, rpm: float, dt: float, headlights: bool) -> void:
	if not is_instance_valid(body):
		return
	wheel_angle=fmod(wheel_angle-speed*dt/.31,TAU)
	for i in range(wheel_spinners.size()):
		wheel_spinners[i].rotation.x=wheel_angle
		wheel_mounts[i].rotation.y=steer if wheel_mounts[i].position.z < 0.0 else 0.0
	popup_amount=move_toward(popup_amount,1.0 if headlights else 0.0,dt*2.0)
	for hinge in popup_hinges:
		hinge.rotation.x=popup_amount*deg_to_rad(46.0)
	for light in head_lights:
		light.visible=headlights and popup_amount>.92
	for lens in brake_lenses:
		lens.material_override=brake_on_mat if brake>.04 else brake_mat
	if is_instance_valid(steering_pivot):
		steering_pivot.rotation.z=-steer*5.8
	if is_instance_valid(speed_needle):
		speed_needle.rotation.z=lerp_angle(speed_needle.rotation.z,deg_to_rad(lerpf(220.0,-40.0,clampf(absf(speed)*3.6/240.0,0,1))),1.0-exp(-dt*12.0))
	if is_instance_valid(rpm_needle):
		rpm_needle.rotation.z=lerp_angle(rpm_needle.rotation.z,deg_to_rad(lerpf(220.0,-40.0,clampf(rpm/9000.0,0,1))),1.0-exp(-dt*12.0))

func set_cockpit_mode(active: bool) -> void:
	cockpit_active=active
	# No opaque tint over the road in driver view; exterior window geometry remains present otherwise.
	for pane in cabin_glass:
		pane.visible=not active
