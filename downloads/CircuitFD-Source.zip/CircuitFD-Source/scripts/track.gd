class_name CircuitTrack
extends Node3D
## Original park circuit. Coordinates are metres; -Z is forward at the start line.

var points: PackedVector3Array = PackedVector3Array()
var road_half_width: float = 6.0
var barrier_offset: float = 18.0
var total_length: float = 0.0
var segment_lengths: PackedFloat32Array = PackedFloat32Array()
var cumulative: PackedFloat32Array = PackedFloat32Array()
var _rng: RandomNumberGenerator = RandomNumberGenerator.new()
var _steel: StandardMaterial3D
var _concrete: StandardMaterial3D
var _dark: StandardMaterial3D
var _white: StandardMaterial3D
var _blue: StandardMaterial3D
var _red: StandardMaterial3D
var static_box_batch_stats: Dictionary = {}
var wet: bool = false
var _road_material: ShaderMaterial
var _wet_materials: Array[ShaderMaterial] = []
var _glazing: StandardMaterial3D
var _accent: StandardMaterial3D
var _rubber: StandardMaterial3D

func _ready() -> void:
	_rng.seed = 19813
	_make_path()
	_make_materials()
	_make_ground()
	_make_road()
	_make_barriers()
	_make_paddock()
	_make_grandstand()
	_make_scenery()
	_make_brake_boards()
	_make_pit_details()
	_make_verge_details()
	_batch_static_boxes()
	set_wet(wet)

func set_wet(enabled: bool) -> void:
	wet = enabled
	for material in _wet_materials:
		material.set_shader_parameter("wetness", 1.0 if enabled else 0.0)

func surface_at(point: Vector3) -> String:
	# The pit apron is paved even though it is outside the main racing strip.
	var distance: float = nearest(point).distance
	var paved: bool = distance <= road_half_width or (point.x >= -17.0 and point.x <= -9.0 and point.z >= -123.0 and point.z <= 167.0)
	if paved:
		return "wet" if wet else "asphalt"
	return "grass" if distance < 9.0 else "gravel"

func _make_path() -> void:
	var knots: Array[Vector3] = [
		Vector3(0, 0, 150), Vector3(0, 0, 70), Vector3(0, 0, -70), Vector3(0, 0, -175),
		Vector3(4, 0, -205), Vector3(-8, 0, -241), Vector3(12, 0, -278), Vector3(28, 0, -300),
		Vector3(66, 0, -325), Vector3(138, 0, -318), Vector3(184, 0, -260), Vector3(195, 0, -185),
		Vector3(168, 0, -122), Vector3(190, 0, -78), Vector3(230, 0, -43), Vector3(238, 0, 15),
		Vector3(210, 0, 67), Vector3(184, 0, 101), Vector3(192, 0, 135), Vector3(176, 0, 169),
		Vector3(184, 0, 202), Vector3(170, 0, 230), Vector3(139, 0, 254), Vector3(100, 0, 270),
		Vector3(50, 0, 255), Vector3(16, 0, 226), Vector3(0, 0, 194)
	]
	var dense: PackedVector3Array = PackedVector3Array()
	for i in range(knots.size()):
		var p0: Vector3 = knots[posmod(i - 1, knots.size())]
		var p1: Vector3 = knots[i]
		var p2: Vector3 = knots[(i + 1) % knots.size()]
		var p3: Vector3 = knots[(i + 2) % knots.size()]
		for j in range(30):
			var t: float = float(j) / 30.0
			var p: Vector3 = 0.5 * ((2.0 * p1) + (-p0 + p2) * t + (2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3) * t * t + (-p0 + 3.0 * p1 - 3.0 * p2 + p3) * t * t * t)
			dense.append(p)
	dense.append(dense[0])
	var walked: float = 0.0
	var next_sample: float = 0.0
	for i in range(dense.size() - 1):
		var span: float = dense[i].distance_to(dense[i + 1])
		while next_sample <= walked + span:
			points.append(dense[i].lerp(dense[i + 1], clampf((next_sample - walked) / maxf(span, 0.0001), 0.0, 1.0)))
			next_sample += 3.0
		walked += span
	# Avoid a tiny final seam segment while preserving a closed, nonduplicated path.
	if points[-1].distance_to(points[0]) < 1.0:
		points.remove_at(points.size() - 1)
	cumulative.append(0.0)
	for i in range(points.size()):
		var length: float = points[i].distance_to(points[(i + 1) % points.size()])
		segment_lengths.append(length)
		total_length += length
		cumulative.append(total_length)

func sample_at(distance: float) -> Dictionary:
	var d: float = fposmod(distance, total_length)
	var low: int = 0
	var high: int = points.size() - 1
	while low < high:
		var mid: int = (low + high + 1) / 2
		if cumulative[mid] <= d:
			low = mid
		else:
			high = mid - 1
	var i: int = low
	var f: float = (d - cumulative[i]) / maxf(segment_lengths[i], 0.001)
	var forward: Vector3 = (points[(i + 1) % points.size()] - points[i]).normalized()
	return {"position": points[i].lerp(points[(i + 1) % points.size()], f), "forward": forward, "yaw": atan2(-forward.x, -forward.z), "index": i, "progress": d}

func nearest(point: Vector3) -> Dictionary:
	var q: Vector3 = Vector3(point.x, 0, point.z)
	var best_sq: float = INF
	var best_i: int = 0
	var best_t: float = 0.0
	var best_point: Vector3 = points[0]
	for i in range(points.size()):
		var a: Vector3 = points[i]
		var segment: Vector3 = points[(i + 1) % points.size()] - a
		var t: float = clampf((q - a).dot(segment) / maxf(segment.length_squared(), 0.0001), 0, 1)
		var p: Vector3 = a + segment * t
		var sq: float = p.distance_squared_to(q)
		if sq < best_sq:
			best_sq = sq
			best_i = i
			best_t = t
			best_point = p
	var forward: Vector3 = (points[(best_i + 1) % points.size()] - points[best_i]).normalized()
	var right: Vector3 = forward.cross(Vector3.UP)
	return {"position": best_point, "forward": forward, "distance": sqrt(best_sq), "lateral": (q - best_point).dot(right), "progress": cumulative[best_i] + segment_lengths[best_i] * best_t, "yaw": atan2(-forward.x, -forward.z), "index": best_i}

func barrier_limit(_progress: float = 0.0) -> float:
	return barrier_offset

func _material(color: Color, roughness: float = 0.9, metallic: float = 0.0) -> StandardMaterial3D:
	var mat: StandardMaterial3D = StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = roughness
	mat.metallic = metallic
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	return mat

func _make_materials() -> void:
	_steel = _material(Color("8d999d"), 0.55, 0.65)
	_concrete = _material(Color("b5b5aa"))
	_dark = _material(Color("202d35"), 0.72)
	_white = _material(Color("d8d6c9"), 0.91)
	_blue = _material(Color("476575"), 0.8)
	_red = _material(Color("9e3029"), 0.9)
	_glazing = _material(Color("253c46"), 0.18, 0.24)
	_accent = _material(Color("c8ab5b"), 0.55, 0.20)
	_rubber = _material(Color("1b2020"), 0.96)
	_road_material = _asphalt_material()

func _asphalt_material() -> ShaderMaterial:
	var shader := Shader.new()
	shader.code = """shader_type spatial;
render_mode cull_disabled;
varying vec3 world_position;
uniform float wetness = 0.0;
float hash(vec2 p) { p=fract(p*vec2(123.34,345.45)); p+=dot(p,p+34.345); return fract(p.x*p.y); }
float noise(vec2 p) {
 vec2 i=floor(p), f=fract(p); f=f*f*(3.0-2.0*f);
 return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);
}
void vertex() {world_position=(MODEL_MATRIX*vec4(VERTEX,1.0)).xyz;}
void fragment() {
 vec2 p=world_position.xz;
 float macro=noise(p*.12);
 float aggregate=noise(p*38.0);
 float footprint=max(length(dFdx(p)),length(dFdy(p)))*38.0;
 aggregate=mix(.5,aggregate,1.0-smoothstep(.35,1.2,footprint));
 float worn=noise(p*1.8);
 float puddles=smoothstep(.59,.82,noise(p*.21));
 float darkening=mix(1.0,.68,wetness);
 ALBEDO=vec3(.054,.060,.063)*(1.0+(macro-.5)*.15+(worn-.5)*.075+(aggregate-.5)*.20)*darkening;
 ROUGHNESS=mix(.86+(aggregate-.5)*.12,mix(.36,.13,puddles),wetness);
 SPECULAR=.43;
 METALLIC=0.0;
}
"""
	var material := ShaderMaterial.new()
	material.shader = shader
	_wet_materials.append(material)
	return material

func _noise_material(base: Color, variation: float, detail_scale: float, large_scale: float) -> ShaderMaterial:
	var shader: Shader = Shader.new()
	shader.code = """shader_type spatial;
render_mode cull_disabled;
varying vec3 world_position;
uniform vec4 base_color : source_color;
uniform float variation = 0.2;
uniform float detail_scale = 30.0;
uniform float large_scale = 0.04;
float hash(vec2 p) { p=fract(p*vec2(123.34,345.45)); p+=dot(p,p+34.345); return fract(p.x*p.y); }
float noise(vec2 p) {
 vec2 i=floor(p); vec2 f=fract(p); f=f*f*(3.0-2.0*f);
 return mix(mix(hash(i),hash(i+vec2(1.,0.)),f.x),mix(hash(i+vec2(0.,1.)),hash(i+vec2(1.,1.)),f.x),f.y);
}
void vertex() { world_position=(MODEL_MATRIX*vec4(VERTEX,1.0)).xyz; }
void fragment() {
 float footprint=max(length(dFdx(world_position.xz)),length(dFdy(world_position.xz)))*detail_scale;
 float fine=mix(.5,noise(world_position.xz*detail_scale),1.0-smoothstep(.35,1.0,footprint));
 float macro=noise(world_position.xz*large_scale);
 ALBEDO=base_color.rgb * (1.0 + (fine-.5)*variation*0.40 + (macro-.5)*variation);
 ROUGHNESS=0.94;
}
"""
	var mat: ShaderMaterial = ShaderMaterial.new()
	mat.shader = shader
	mat.set_shader_parameter("base_color", base)
	mat.set_shader_parameter("variation", variation)
	mat.set_shader_parameter("detail_scale", detail_scale)
	mat.set_shader_parameter("large_scale", large_scale)
	return mat

func _instance(mesh: Mesh, material: Material, p: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var item: MeshInstance3D = MeshInstance3D.new()
	item.mesh = mesh
	item.material_override = material
	item.position = p
	add_child(item)
	return item

func _box(p: Vector3, size: Vector3, mat: Material, yaw: float = 0.0) -> MeshInstance3D:
	var mesh: BoxMesh = BoxMesh.new()
	mesh.size = size
	var node: MeshInstance3D = _instance(mesh, mat, p)
	node.rotation.y = yaw
	return node

func _label(caption: String, p: Vector3, font_size: int, pixel_size: float, color: Color = Color("f1ecdc"), yaw: float = 0.0) -> void:
	var label: Label3D = Label3D.new()
	label.text = caption
	label.position = p
	label.font_size = font_size
	label.pixel_size = pixel_size
	label.modulate = color
	label.outline_size = 4
	label.rotation.y = yaw
	label.no_depth_test = false
	label.shaded = true
	label.double_sided = true
	add_child(label)

func _make_ground() -> void:
	var ground: PlaneMesh = PlaneMesh.new()
	ground.size = Vector2(2200, 2200)
	var g: MeshInstance3D = _instance(ground, _noise_material(Color("4d593b"), 0.30, 35.0, 0.025), Vector3(50, -0.055, -10))
	g.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	# Gentle distant landforms close the horizon without placing decorative rocks beside apexes.
	var hill_material: StandardMaterial3D = _material(Color("4d593e"))
	for k in range(14):
		var angle: float = float(k) / 14.0 * TAU
		var center: Vector3 = Vector3(90 + cos(angle) * 690, -18, -20 + sin(angle) * 770)
		var sphere: SphereMesh = SphereMesh.new()
		sphere.radius = 1.0
		sphere.height = 2.0
		sphere.radial_segments = 24
		sphere.rings = 10
		var hill: MeshInstance3D = _instance(sphere, hill_material, center)
		hill.scale = Vector3(_rng.randf_range(150, 240), _rng.randf_range(35, 62), _rng.randf_range(145, 235))

func _right_at(i: int) -> Vector3:
	return (points[(i + 1) % points.size()] - points[posmod(i - 1, points.size())]).normalized().cross(Vector3.UP)

func _surface() -> SurfaceTool:
	var st: SurfaceTool = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	return st

func _quad(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, d: Vector3, uv_a: Vector2 = Vector2.ZERO, uv_b: Vector2 = Vector2.RIGHT, uv_c: Vector2 = Vector2.ONE, uv_d: Vector2 = Vector2.DOWN, normal: Vector3 = Vector3.UP) -> void:
	# Explicit normals plus two-sided material keep the thin safety and road ribbons reliable.
	for v in [0, 2, 1, 0, 3, 2]:
		st.set_normal(normal)
		match v:
			0:
				st.set_uv(uv_a)
				st.add_vertex(a)
			1:
				st.set_uv(uv_b)
				st.add_vertex(b)
			2:
				st.set_uv(uv_c)
				st.add_vertex(c)
			3:
				st.set_uv(uv_d)
				st.add_vertex(d)

func _commit(st: SurfaceTool, mat: Material, shadow: bool = true) -> MeshInstance3D:
	var instance: MeshInstance3D = _instance(st.commit(), mat)
	if not shadow:
		instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return instance

func _strip(st: SurfaceTool, i: int, offset_a: float, offset_b: float, height: float) -> void:
	var j: int = (i + 1) % points.size()
	var ra: Vector3 = _right_at(i)
	var rb: Vector3 = _right_at(j)
	_quad(st, points[i] + ra * offset_a + Vector3.UP * height, points[i] + ra * offset_b + Vector3.UP * height, points[j] + rb * offset_b + Vector3.UP * height, points[j] + rb * offset_a + Vector3.UP * height)

func _make_road() -> void:
	var road: SurfaceTool = _surface()
	var gravel: SurfaceTool = _surface()
	var red_kerb: SurfaceTool = _surface()
	var white_kerb: SurfaceTool = _surface()
	var edges: SurfaceTool = _surface()
	var rubber: SurfaceTool = _surface()
	for i in range(points.size()):
		_strip(road, i, -6.0, 6.0, 0.015)
		_strip(edges, i, -5.85, -5.74, 0.023)
		_strip(edges, i, 5.74, 5.85, 0.023)
		var f0: Vector3 = (points[i] - points[posmod(i - 2, points.size())]).normalized()
		var f1: Vector3 = (points[(i + 2) % points.size()] - points[i]).normalized()
		var curve: float = f0.signed_angle_to(f1, Vector3.UP)
		if absf(curve) > 0.035:
			for side in [-1.0, 1.0]:
				_strip(gravel, i, side * 8.3, side * 16.6, -0.015)
				var kerb: SurfaceTool = red_kerb if (i / 2) % 2 == 0 else white_kerb
				_strip(kerb, i, side * 6.02, side * 7.12, 0.058)
		# Paired restrained rubber traces follow real corner approaches and the racing line.
		if absf(curve) > 0.055 or (points[i].z < -110 and points[i].z > -190 and absf(points[i].x) < 4):
			var line_offset: float = -signf(curve) * 1.8
			_strip(rubber, i, line_offset - 0.88, line_offset - 0.67, 0.026)
			_strip(rubber, i, line_offset + 0.67, line_offset + 0.88, 0.026)
	_commit(road, _road_material, false)
	_commit(gravel, _noise_material(Color("b4a586"), 0.36, 38.0, 0.23), false)
	_commit(red_kerb, _kerb_material(Color("a33b31")), false)
	_commit(white_kerb, _kerb_material(Color("cecfc1")), false)
	_commit(edges, _white, false)
	_commit(rubber, _material(Color("303335")), false)
	# Checker start line: metres, not a billboard laid over the road.
	for x in range(16):
		for z in range(2):
			_box(Vector3(-5.625 + float(x) * 0.75, 0.031, 150.0 + float(z) * 0.75), Vector3(0.75, 0.012, 0.75), _white if (x + z) % 2 == 0 else _dark)
	for row in range(6):
		var z: float = 160 + float(row) * 8.0
		var x: float = -2.3 if row % 2 == 0 else 2.3
		_box(Vector3(x, 0.031, z), Vector3(2.0, 0.012, 0.09), _white)
		_box(Vector3(x - 1, 0.031, z + 1.6), Vector3(0.09, 0.012, 3.2), _white)
		_box(Vector3(x + 1, 0.031, z + 1.6), Vector3(0.09, 0.012, 3.2), _white)

func _segment_box(st: SurfaceTool, a: Vector3, b: Vector3, width: float, height: float) -> void:
	var f: Vector3 = (b - a).normalized()
	var r: Vector3 = f.cross(Vector3.UP) * width * 0.5
	var h: Vector3 = Vector3.UP * height * 0.5
	_quad(st, a - r - h, a + r - h, b + r - h, b - r - h, Vector2.ZERO, Vector2.RIGHT, Vector2.ONE, Vector2.DOWN, Vector3.DOWN)
	_quad(st, a - r + h, b - r + h, b + r + h, a + r + h)
	_quad(st, a - r - h, b - r - h, b - r + h, a - r + h, Vector2.ZERO, Vector2.RIGHT, Vector2.ONE, Vector2.DOWN, -r.normalized())
	_quad(st, a + r - h, a + r + h, b + r + h, b + r - h, Vector2.ZERO, Vector2.RIGHT, Vector2.ONE, Vector2.DOWN, r.normalized())

func _make_barriers() -> void:
	var rails: SurfaceTool = _surface()
	var posts: SurfaceTool = _surface()
	var fence: SurfaceTool = _surface()
	for i in range(points.size()):
		var j: int = (i + 1) % points.size()
		for side in [-1.0, 1.0]:
			var a: Vector3 = points[i] + _right_at(i) * 18.0 * side
			var b: Vector3 = points[j] + _right_at(j) * 18.0 * side
			for rail_height in [0.40, 0.68, 0.96]:
				_segment_box(rails, a + Vector3.UP * rail_height, b + Vector3.UP * rail_height, 0.13, 0.20)
			if i % 4 == 0:
				_segment_box(posts, a - Vector3.FORWARD * 0.055 + Vector3.UP * 0.55, a + Vector3.FORWARD * 0.055 + Vector3.UP * 0.55, 0.12, 1.1)
				_segment_box(posts, a - Vector3.FORWARD * 0.045 + Vector3.UP * 2.0, a + Vector3.FORWARD * 0.045 + Vector3.UP * 2.0, 0.09, 4.0)
			var offset: Vector3 = _right_at(i) * side * 0.15
			_quad(fence, a + offset + Vector3.UP * 1.0, b + offset + Vector3.UP * 1.0, b + offset + Vector3.UP * 3.9, a + offset + Vector3.UP * 3.9, Vector2(cumulative[i], 0.0), Vector2(cumulative[i + 1], 0.0), Vector2(cumulative[i + 1], 2.9), Vector2(cumulative[i], 2.9), _right_at(i) * side)
	_commit(rails, _steel)
	_commit(posts, _steel)
	var fs: Shader = Shader.new()
	fs.code = """shader_type spatial;
render_mode cull_disabled, shadows_disabled;
void fragment() {
 vec2 grid=abs(fract(UV*3.5)-.5);
 vec2 w=max(fwidth(UV*3.5),vec2(.012));
 float wire=1.0-min(smoothstep(.018,.018+w.x,grid.x),smoothstep(.018,.018+w.y,grid.y));
 float distance_fade=1.0-smoothstep(.22,.65,max(w.x,w.y));
 ALBEDO=vec3(.065,.085,.075); ROUGHNESS=.86;
 ALPHA=wire*.70*distance_fade; ALPHA_SCISSOR_THRESHOLD=.35;
}
"""
	var fm: ShaderMaterial = ShaderMaterial.new()
	fm.shader = fs
	_commit(fence, fm, false)

func _make_paddock() -> void:
	var pit_asphalt: Material = _road_material
	_box(Vector3(-13, -0.005, 22), Vector3(8.0, 0.03, 290), pit_asphalt)
	# Entry and exit fan into the road without a wall intersecting the drivable pit apron.
	var apron: SurfaceTool = _surface()
	_quad(apron, Vector3(-17, 0.016, 167), Vector3(-9, 0.016, 167), Vector3(-5.5, 0.016, 198), Vector3(-7.0, 0.016, 198))
	_quad(apron, Vector3(-17, 0.016, -123), Vector3(-9, 0.016, -123), Vector3(-5.0, 0.016, -168), Vector3(-7.3, 0.016, -168))
	_commit(apron, pit_asphalt, false)
	for i in range(26):
		_box(Vector3(-8.8, 0.035, -111 + i * 10.5), Vector3(0.13, 0.02, 5), _white)
	_box(Vector3(-29, 3.8, 28), Vector3(18, 7.6, 192), _concrete)
	_box(Vector3(-29, 7.85, 28), Vector3(19.8, 0.45, 194), _dark)
	_box(Vector3(-19.8, 5.7, 28), Vector3(0.12, 2.2, 187), _blue)
	_box(Vector3(-19.55, 5.85, 28), Vector3(0.13, 0.10, 190), _steel)
	var garage: StandardMaterial3D = _material(Color("4e5859"), 0.65, 0.15)
	for bay in range(18):
		var z: float = -61 + float(bay) * 10.5
		_box(Vector3(-19.85, 1.65, z), Vector3(0.16, 3.1, 8.0), garage)
		_box(Vector3(-19.7, 3.35, z), Vector3(0.18, 0.25, 8.3), _red if bay % 3 == 0 else _blue)
		for seam in range(5):
			_box(Vector3(-19.72, 0.4 + seam * 0.52, z), Vector3(0.08, 0.025, 7.9), _steel)
		_box(Vector3(-15.5, 0.03, z), Vector3(4.2, 0.02, 0.07), _white)
		_label("%02d" % (bay + 1), Vector3(-19.5, 3.9, z), 52, 0.012, Color("ede9dd"), PI * 0.5)
	# Low control tower with a glazed upper storey. Approximate decorative glass, no functional mirrors.
	_box(Vector3(-28, 10.2, 138), Vector3(15, 20.4, 16), _concrete)
	_box(Vector3(-28, 19.3, 138), Vector3(18.5, 5.0, 19.5), _blue)
	_box(Vector3(-28, 22.0, 138), Vector3(20.5, 0.5, 21.5), _dark)
	for z in [131.0, 138.0, 145.0]:
		_box(Vector3(-18.65, 19.3, z), Vector3(0.15, 5.2, 0.16), _steel)
	_label("CIRCUIT FD", Vector3(-18.48, 14.3, 138), 80, 0.018, Color("e4ded0"), PI * 0.5)
	# Gantry has 5.8 m clear headroom; supports stay outside the logical 18 m barrier corridor.
	for x in [-19.5, 19.5]:
		_box(Vector3(x, 3.6, 150), Vector3(0.48, 7.2, 0.72), _steel)
	_box(Vector3(0, 7.1, 150), Vector3(17.0, 1.5, 1.12), _dark)
	_box(Vector3(0, 5.9, 150), Vector3(39.5, .18, .7), _steel)
	_box(Vector3(0, 8.3, 150), Vector3(39.5, .18, .7), _steel)
	var truss: SurfaceTool = _surface()
	for i in range(16):
		var a: Vector3 = Vector3(-19.5 + float(i) * 2.4375, 5.98 if i % 2 == 0 else 8.22, 150)
		var b: Vector3 = Vector3(-19.5 + float(i + 1) * 2.4375, 5.98 if (i + 1) % 2 == 0 else 8.22, 150)
		_segment_box(truss, a, b, .30, .18)
	_commit(truss, _steel)
	_label("CIRCUIT  FD", Vector3(0, 7.13, 150.58), 96, 0.014)
	for x in [-2.1, -1.05, 0.0, 1.05, 2.1]:
		_box(Vector3(x, 5.52, 149.5), Vector3(0.46, 0.46, 0.28), _dark)
	# Static red starting lamps, decorative rather than a race countdown.
		var sphere: SphereMesh = SphereMesh.new()
		sphere.radius = 0.13
		sphere.height = 0.26
		sphere.radial_segments = 12
		sphere.rings = 6
		_instance(sphere, _red, Vector3(x, 5.52, 149.32))

func _make_grandstand() -> void:
	# One restrained permanent grandstand, ascending away from the racing surface.
	var seat_surface: SurfaceTool = _surface()
	for row in range(9):
		var x: float = 26.0 + float(row) * 1.12
		var y: float = 1.2 + float(row) * 0.60
		_box(Vector3(x, y * 0.5, 83), Vector3(1.12, y, 105), _concrete)
		for col in range(100):
			if col % 25 >= 22:
				continue
			var z: float = 32 + float(col) * 1.02
			# Seat cushions and short backs batched in a single surface.
			_segment_box(seat_surface, Vector3(x - 0.22, y + 0.12, z), Vector3(x + 0.22, y + 0.12, z), 0.68, 0.15)
			_segment_box(seat_surface, Vector3(x + 0.26, y + 0.32, z - 0.02), Vector3(x + 0.30, y + 0.32, z + 0.02), 0.66, 0.55)
	_commit(seat_surface, _blue)
	for z in [29.0, 54.5, 80.0, 105.5, 137.0]:
		_box(Vector3(35.3, 5.8, z), Vector3(0.32, 11.6, 0.32), _steel)
	_box(Vector3(29.9, 10.8, 83), Vector3(13.7, 0.38, 111), _white)
	_box(Vector3(23.0, 10.35, 83), Vector3(0.26, 1.1, 111), _dark)
	_label("PARK  GRANDSTAND", Vector3(22.8, 10.3, 82), 90, 0.016, Color("d6d7cf"), -PI * 0.5)
	for z in [25.0, 141.0]:
		_box(Vector3(30, 1.4, z), Vector3(13.0, 2.8, 2.6), _concrete)
	# Marshals' huts are outside the barriers, never placed on the racing line.
	for progress in [340.0, 620.0, 930.0]:
		var data: Dictionary = sample_at(progress)
		var forward: Vector3 = data.forward
		var pos: Vector3 = data.position + forward.cross(Vector3.UP) * 24
		var yaw: float = data.yaw
		_box(pos + Vector3.UP * 1.3, Vector3(4, 2.6, 3), _white, yaw)
		_box(pos + Vector3.UP * 2.75, Vector3(4.5, 0.3, 3.6), _dark, yaw)

func _batch_instances(mesh: Mesh, material: Material, transforms: Array[Transform3D], shadow: bool = true, group_name: String = "vegetation") -> void:
	if transforms.is_empty():
		return
	# One enormous MultiMesh AABB would submit all trees whenever any one tree is
	# visible. Local 100 m cells allow the renderer's frustum/shadow culling to work.
	var cells: Dictionary = {}
	for transform in transforms:
		var cell: Vector2i = Vector2i(floori(transform.origin.x / 100.0), floori(transform.origin.z / 100.0))
		if not cells.has(cell):
			cells[cell] = []
		cells[cell].append(transform)
	for cell_key in cells:
		var cell: Vector2i = cell_key
		var cell_origin: Vector3 = Vector3(float(cell.x) * 100.0, 0, float(cell.y) * 100.0)
		var items: Array = cells[cell_key]
		var multi: MultiMesh = MultiMesh.new()
		multi.transform_format = MultiMesh.TRANSFORM_3D
		multi.mesh = mesh
		multi.instance_count = items.size()
		for i in range(items.size()):
			var local_transform: Transform3D = items[i]
			local_transform.origin -= cell_origin
			multi.set_instance_transform(i, local_transform)
		var node: MultiMeshInstance3D = MultiMeshInstance3D.new()
		node.name = "Trees_%d_%d" % [cell.x, cell.y]
		node.position = cell_origin
		node.multimesh = multi
		node.material_override = material
		if not shadow:
			node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		node.add_to_group(group_name)
		add_child(node)

func _make_scenery() -> void:
	var trunks: Array[Transform3D] = []
	var crowns_a: Array[Transform3D] = []
	var crowns_b: Array[Transform3D] = []
	var crowns_c: Array[Transform3D] = []
	var accepted: int = 0
	for attempt in range(2500):
		if accepted >= 820:
			break
		var p: Vector3 = Vector3(_rng.randf_range(-300, 540), 0, _rng.randf_range(-520, 470))
		if p.x > -50 and p.x < 45 and p.z > -95 and p.z < 175:
			continue
		var close: Dictionary = nearest(p)
		if float(close.distance) < 30:
			continue
		var scale: float = _rng.randf_range(0.82, 1.30)
		var yaw: float = _rng.randf_range(0, TAU)
		var basis: Basis = Basis(Vector3.UP, yaw).scaled(Vector3(scale, scale, scale))
		trunks.append(Transform3D(basis, p + Vector3.UP * (2.25 * scale)))
		match accepted % 3:
			0:
				crowns_a.append(Transform3D(basis.scaled(Vector3(1, 1.2, 1)), p + Vector3.UP * 5.8 * scale))
			1:
				crowns_b.append(Transform3D(basis.scaled(Vector3(1.18, 0.95, 1.0)), p + Vector3.UP * 5.8 * scale))
			2:
				crowns_c.append(Transform3D(basis, p + Vector3.UP * 5.6 * scale))
		accepted += 1
	var trunk_mesh: CylinderMesh = CylinderMesh.new()
	trunk_mesh.top_radius = 0.19
	trunk_mesh.bottom_radius = 0.33
	trunk_mesh.height = 4.5
	trunk_mesh.radial_segments = 7
	_batch_instances(trunk_mesh, _bark_material(), trunks)
	var broadleaf: ArrayMesh = _canopy_mesh(false)
	_batch_instances(broadleaf, _leaf_material(Color("354c30")), crowns_a)
	_batch_instances(broadleaf, _leaf_material(Color("475a36")), crowns_b)
	_batch_instances(_canopy_mesh(true), _leaf_material(Color("2e4634")), crowns_c)

func _canopy_mesh(conifer: bool) -> ArrayMesh:
	var st: SurfaceTool = _surface()
	if conifer:
		# Three overlapping whorls soften the single-cone silhouette.
		for tier in range(4):
			var cone: CylinderMesh = CylinderMesh.new()
			cone.top_radius = 0.10
			cone.bottom_radius = 2.60 - float(tier) * 0.48
			cone.height = 3.8 - float(tier) * 0.38
			cone.radial_segments = 11
			cone.rings = 1
			var transform: Transform3D = Transform3D(Basis(Vector3.UP, float(tier) * 0.71), Vector3(0, -1.4 + float(tier) * 1.15, 0))
			st.append_from(cone, 0, transform)
	else:
		var lobes: Array[Vector3] = [Vector3(-1.45, -.35, .45), Vector3(1.38, -.15, .22), Vector3(.05, -.35, -1.28), Vector3(-.9, 1.25, -.4), Vector3(.85, 1.5, .1), Vector3(0, .25, 1.1)]
		for i in range(lobes.size()):
			var sphere: SphereMesh = SphereMesh.new()
			sphere.radius = 2.0 + float(i % 2) * .22
			sphere.height = sphere.radius * 2.0
			sphere.radial_segments = 10
			sphere.rings = 6
			var transform: Transform3D = Transform3D(Basis(Vector3.UP, float(i) * .89).scaled(Vector3(1., 1.0 + float(i % 3) * .12, .9)), lobes[i])
			st.append_from(_irregular_crown(sphere), 0, transform)
	return st.commit()

func _irregular_crown(source: SphereMesh) -> ArrayMesh:
	# Break the perfectly manufactured ellipsoid silhouette at the same vertex budget.
	var arrays: Array=source.surface_get_arrays(0)
	var vertices: PackedVector3Array=arrays[Mesh.ARRAY_VERTEX]
	for i in range(vertices.size()):
		var p: Vector3=vertices[i]
		var displacement: float=.037*sin(p.x*4.7+p.z*3.1)+.028*sin(p.y*5.4-p.z*2.3)
		vertices[i]=p*(1.0+displacement)
	arrays[Mesh.ARRAY_VERTEX]=vertices
	var mesh:=ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,arrays)
	return mesh

func _leaf_material(color: Color) -> ShaderMaterial:
	var shader: Shader = Shader.new()
	shader.code = """shader_type spatial;
varying vec3 world_position;
uniform vec4 leaf_color:source_color;
varying float local_height;
float hash(vec3 p) { p=fract(p*vec3(.1031,.1030,.0973)); p+=dot(p,p.yxz+33.33); return fract((p.x+p.y)*p.z); }
float noise(vec3 p) {
 vec3 i=floor(p);vec3 f=fract(p);f=f*f*(3.-2.*f);
 return mix(mix(mix(hash(i),hash(i+vec3(1,0,0)),f.x),mix(hash(i+vec3(0,1,0)),hash(i+vec3(1,1,0)),f.x),f.y),mix(mix(hash(i+vec3(0,0,1)),hash(i+vec3(1,0,1)),f.x),mix(hash(i+vec3(0,1,1)),hash(i+vec3(1,1,1)),f.x),f.y),f.z);
}
void vertex() {world_position=(MODEL_MATRIX*vec4(VERTEX,1.)).xyz;local_height=VERTEX.y;}
void fragment() {
 float patches=noise(world_position*.92);
 float fine=hash(floor(world_position*7.0));
 float footprint=max(length(dFdx(world_position)),length(dFdy(world_position)))*7.0;
 float filter=1.0-smoothstep(.25,1.0,footprint);
 float height_tint=.80+clamp((local_height+3.0)/8.0,0.0,1.0)*.22;
 ALBEDO=leaf_color.rgb*(.78+patches*.39+(fine-.5)*.13*filter)*height_tint;
 ROUGHNESS=.96;
}
"""
	var mat: ShaderMaterial = ShaderMaterial.new()
	mat.shader = shader
	mat.set_shader_parameter("leaf_color", color)
	return mat

func _make_brake_boards() -> void:
	for metres in [150, 100, 50]:
		var pos: Vector3 = Vector3(19.3, 1.7, -225 + metres)
		_box(pos, Vector3(2.1, 1.55, 0.14), _white)
		_box(pos + Vector3(0, -1.0, 0), Vector3(0.12, 1.4, 0.12), _steel)
		_label(str(metres), pos + Vector3(0, 0, 0.085), 100, 0.012, Color("222b2b"))
	# Directional boards warn about the two original chicanes; they are not Monza corner claims.
	for progress in [345.0, 990.0]:
		var d: Dictionary = sample_at(progress)
		var f: Vector3 = d.forward
		var p: Vector3 = d.position + f.cross(Vector3.UP) * 20.0 + Vector3.UP * 1.5
		_box(p, Vector3(3, 1.5, 0.18), _dark, float(d.yaw))
		_label("CHICANE", p + f * -0.12, 75, 0.011, Color("e2d5a0"), float(d.yaw))

func _transformed_bounds(box: AABB, transform: Transform3D) -> AABB:
	var bounds: AABB = AABB(transform * box.position, Vector3.ZERO)
	for x in [0.0, 1.0]:
		for y in [0.0, 1.0]:
			for z in [0.0, 1.0]:
				bounds = bounds.expand(transform * (box.position + box.size * Vector3(x, y, z)))
	return bounds

func _mesh_triangle_count(mesh: Mesh) -> int:
	var triangles: int = 0
	for surface in range(mesh.get_surface_count()):
		var arrays: Array = mesh.surface_get_arrays(surface)
		var indices: PackedInt32Array = arrays[Mesh.ARRAY_INDEX]
		var vertices: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
		triangles += indices.size() / 3 if not indices.is_empty() else vertices.size() / 3
	return triangles

func _batch_static_boxes() -> void:
	# All track boxes are static scenery. Combine by material identity and shadow
	# setting so the many garage seams, grid markers and structure members do not
	# each become a separate draw in every directional-shadow cascade.
	var batches: Dictionary = {}
	var originals: Array[MeshInstance3D] = []
	var before_triangles: int = 0
	for child in get_children():
		if not child is MeshInstance3D:
			continue
		var item: MeshInstance3D = child
		if not item.mesh is BoxMesh:
			continue
		var material: Material = item.material_override
		if material == null:
			material = item.mesh.surface_get_material(0)
		var material_id: int = material.get_instance_id() if material != null else 0
		var key: String = str(material_id) + ":" + str(item.cast_shadow)
		if not batches.has(key):
			batches[key] = {"surface": _surface(), "material": material, "shadow": item.cast_shadow, "triangles": 0, "bounds": _transformed_bounds(item.mesh.get_aabb(), item.transform)}
		var batch: Dictionary = batches[key]
		var surface: SurfaceTool = batch.surface
		surface.append_from(item.mesh, 0, item.transform)
		var count: int = _mesh_triangle_count(item.mesh)
		batch.triangles = int(batch.triangles) + count
		batch.bounds = (batch.bounds as AABB).merge(_transformed_bounds(item.mesh.get_aabb(), item.transform))
		before_triangles += count
		originals.append(item)
	var after_triangles: int = 0
	var max_bounds_error: float = 0.0
	for key in batches:
		var batch: Dictionary = batches[key]
		var mesh: ArrayMesh = (batch.surface as SurfaceTool).commit()
		var triangles: int = _mesh_triangle_count(mesh)
		assert(triangles == int(batch.triangles), "Static-box batching changed triangle count")
		var expected_bounds: AABB = batch.bounds
		var actual_bounds: AABB = mesh.get_aabb()
		var bounds_error: float = maxf(actual_bounds.position.distance_to(expected_bounds.position), actual_bounds.end.distance_to(expected_bounds.end))
		max_bounds_error = maxf(max_bounds_error, bounds_error)
		assert(bounds_error < 0.002, "Static-box batching changed transformed geometry bounds")
		var merged: MeshInstance3D = _instance(mesh, batch.material)
		merged.name = "StaticArchitectureBatch"
		merged.cast_shadow = int(batch.shadow)
		after_triangles += triangles
	for item in originals:
		item.free()
	assert(before_triangles == after_triangles)
	static_box_batch_stats = {"before_nodes": originals.size(), "after_nodes": batches.size(), "triangles_before": before_triangles, "triangles_after": after_triangles, "maximum_bounds_error_m": max_bounds_error}
	print("TRACK STATIC BOX BATCHES | ", JSON.stringify(static_box_batch_stats))

func _kerb_material(base: Color) -> ShaderMaterial:
	var shader := Shader.new()
	shader.code = """shader_type spatial;
render_mode cull_disabled;
varying vec3 world_position;
uniform vec4 paint_color:source_color;
uniform float wetness=0.0;
float hash(vec2 p){p=fract(p*vec2(123.34,345.45));p+=dot(p,p+34.345);return fract(p.x*p.y);}
void vertex(){world_position=(MODEL_MATRIX*vec4(VERTEX,1.)).xyz;}
void fragment(){
 vec2 p=world_position.xz;
 float grain=hash(floor(p*34.0));
 float fade=1.0-smoothstep(.3,1.2,max(length(dFdx(p)),length(dFdy(p)))*34.0);
 float wear=smoothstep(.74,.96,hash(floor(p*2.0)))*.12;
 ALBEDO=paint_color.rgb*(1.0-wear+(grain-.5)*.12*fade)*mix(1.0,.81,wetness);
 ROUGHNESS=mix(.82,.28,wetness);
 SPECULAR=.35;
}
"""
	var material := ShaderMaterial.new()
	material.shader=shader
	material.set_shader_parameter("paint_color",base)
	_wet_materials.append(material)
	return material

func _bark_material() -> ShaderMaterial:
	var shader := Shader.new()
	shader.code = """shader_type spatial;
void fragment(){
 float grooves=sin(UV.x*110.0+sin(UV.y*29.0)*.7)*.5+.5;
 float broken=sin(UV.x*47.0+UV.y*22.0)*.5+.5;
 ALBEDO=mix(vec3(.105,.075,.047),vec3(.21,.16,.10),grooves*.66+broken*.24);
 ROUGHNESS=.97;
}
"""
	var material := ShaderMaterial.new()
	material.shader=shader
	return material

func _append_detail_cylinder(st: SurfaceTool, p: Vector3, radius: float, height: float, rotation_: Vector3 = Vector3.ZERO) -> void:
	var mesh := CylinderMesh.new()
	mesh.top_radius=radius
	mesh.bottom_radius=radius
	mesh.height=height
	mesh.radial_segments=16
	mesh.rings=1
	st.append_from(mesh,0,Transform3D(Basis.from_euler(rotation_),p))

func _make_pit_details() -> void:
	# An original club-racing paddock with useful scale cues, not branded scenery.
	# Every tall object remains outside the 18 m logical driving perimeter.
	var rail := _surface()
	for bay in range(18):
		var z: float=-61.0+float(bay)*10.5
		_box(Vector3(-19.62,5.7,z),Vector3(.10,1.84,7.75),_glazing)
		for dz in [-3.95,0.0,3.95]:
			_box(Vector3(-19.53,5.7,z+dz),Vector3(.09,2.01,.09),_steel)
		_box(Vector3(-19.56,4.61,z),Vector3(.10,.12,8.15),_accent if bay%3==0 else _steel)
		_box(Vector3(-19.51,5.72,z),Vector3(.08,.08,7.82),_steel)
		# Slim architectural ribs break the huge blank facade into individual bays.
		_box(Vector3(-19.65,3.8,z-4.95),Vector3(.30,7.6,.26),_white)
		if bay%3==1:
			_box(Vector3(-19.63,1.55,z),Vector3(.12,2.78,7.42),_dark)
			_box(Vector3(-19.51,1.25,z+2.7),Vector3(.09,1.52,.92),_blue)
		if bay in [2,8,14]:
			_label("FD / MOTOR CLUB",Vector3(-19.47,3.78,z),48,.009,Color("d2bb78"),PI*.5)
	for z in range(-68,125,8):
		_segment_box(rail,Vector3(-19.10,8.04,z),Vector3(-19.10,9.15,z),.075,.075)
	for y in [8.42,9.13]:
		_segment_box(rail,Vector3(-19.10,y,-69),Vector3(-19.10,y,125),.08,.07)
	_commit(rail,_steel)
	# Shared roof equipment: identifiable HVAC housings and louvered fronts.
	for z in [-44.0,-9.0,26.0,61.0,96.0]:
		_box(Vector3(-28.2,8.54,z),Vector3(3.6,1.12,4.2),_white)
		_box(Vector3(-26.32,8.52,z),Vector3(.12,.85,3.85),_dark)
		for louver in range(5):
			_box(Vector3(-26.23,8.2+float(louver)*.14,z),Vector3(.09,.045,3.85),_steel)
	# Tower glass and mullions are opaque-tinted approximations, not ray-traced rooms.
	_box(Vector3(-18.59,19.36,138),Vector3(.09,4.15,17.3),_glazing)
	for z in [130.0,134.0,138.0,142.0,146.0]:
		_box(Vector3(-18.50,19.36,z),Vector3(.08,4.35,.10),_steel)
	_box(Vector3(-18.48,19.34,138),Vector3(.08,.08,17.4),_steel)
	_label("RACE CONTROL",Vector3(-18.42,22.65,138),58,.014,Color("e0c779"),PI*.5)
	# Original sponsor-style track banners sit behind the safety mesh.
	for z in [42.0,105.0,169.0]:
		_box(Vector3(18.45,1.84,z),Vector3(.10,1.12,18.0),_dark)
		_box(Vector3(18.37,1.31,z),Vector3(.08,.10,18.0),_accent)
		_label("FD  /  PARK CIRCUIT",Vector3(18.33,1.82,z),70,.013,Color("e1d4a7"),-PI*.5)
	# A small original support van; it remains wholly beyond the barrier.
	_box(Vector3(24,.90,162),Vector3(1.88,1.16,4.45),_white)
	_box(Vector3(24,1.47,162.84),Vector3(1.88,1.36,2.70),_white)
	_box(Vector3(24,1.52,160.63),Vector3(1.80,.69,1.37),_white)
	_box(Vector3(24,1.56,159.91),Vector3(1.60,.52,.055),_glazing)
	for x in [23.05,24.95]:
		_box(Vector3(x,1.56,160.58),Vector3(.055,.48,1.13),_glazing)
		_box(Vector3(x,1.05,162.2),Vector3(.07,.22,3.93),_accent)
	_box(Vector3(24,.55,159.70),Vector3(1.82,.21,.22),_dark)
	_box(Vector3(24,1.98,160.65),Vector3(.65,.18,.30),_accent)
	_label("FD  ROAD SERVICE",Vector3(22.99,1.55,162.89),52,.011,Color("243d48"),-PI*.5)
	var tyres := _surface()
	var hubs := _surface()
	for x in [23.04,24.96]:
		for z in [160.62,163.47]:
			_append_detail_cylinder(tyres,Vector3(x,.285,z),.34,.24,Vector3(0,0,PI*.5))
			_append_detail_cylinder(hubs,Vector3(x+(-.13 if x<24 else .13),.285,z),.21,.03,Vector3(0,0,PI*.5))
	# Tire racks and pit carts are scale cues, not obstacles hidden on the racing line.
	for x in [20.05,20.88,21.71]:
		for layer in range(3):
			_append_detail_cylinder(tyres,Vector3(x,.055+layer*.23,177),.36,.22)
	for z in [-41.0,23.0,86.0]:
		_box(Vector3(-19.10,.67,z),Vector3(.70,1.04,1.36),_dark)
		_box(Vector3(-19.10,1.22,z),Vector3(.78,.12,1.44),_accent)
		for dz in [-.49,.49]:
			_append_detail_cylinder(tyres,Vector3(-19.10,.085,z+dz),.14,.65,Vector3(0,0,PI*.5))
	_commit(tyres,_rubber)
	_commit(hubs,_steel)

func _make_verge_details() -> void:
	# Short crossed opaque blades add near-ground texture without alpha overdraw.
	var mesh_surface := _surface()
	for blade in range(6):
		var angle: float=float(blade)*TAU/6.0
		var axis: Vector3=Vector3(cos(angle),0,sin(angle))
		var side: Vector3=axis.cross(Vector3.UP)*.014
		var base: Vector3=axis*.025
		var tip: Vector3=axis*.086+Vector3.UP*(.15+float(blade%3)*.038)
		for point in [base-side,tip,base+side]:
			mesh_surface.set_normal(Vector3.UP)
			mesh_surface.add_vertex(point)
	var grass_mesh: ArrayMesh=mesh_surface.commit()
	var material := ShaderMaterial.new()
	var shader := Shader.new()
	shader.code="""shader_type spatial;
render_mode cull_disabled;
varying vec3 world_position;
varying vec3 grass_up;
void vertex(){world_position=(MODEL_MATRIX*vec4(VERTEX,1.)).xyz;grass_up=(MODELVIEW_MATRIX*vec4(0,1,0,0)).xyz;VERTEX.x+=sin(TIME*1.4+world_position.x*.6+world_position.z*.18)*VERTEX.y*.10;}
void fragment(){NORMAL=normalize(grass_up);float n=fract(sin(dot(floor(world_position.xz*1.4),vec2(12.9898,78.233)))*43758.5453);ALBEDO=mix(vec3(.09,.126,.041),vec3(.19,.24,.075),n);ROUGHNESS=.98;}
"""
	material.shader=shader
	var detail_rng:=RandomNumberGenerator.new()
	detail_rng.seed=24686
	var transforms: Array[Transform3D]=[]
	for i in range(0,points.size(),2):
		var f0: Vector3=(points[i]-points[posmod(i-2,points.size())]).normalized()
		var f1: Vector3=(points[(i+2)%points.size()]-points[i]).normalized()
		if absf(f0.signed_angle_to(f1,Vector3.UP))>.035:
			continue # Gravel remains bare; no decorative grass growing through it.
		for side in [-1.0,1.0]:
			if side<0.0 and absf(points[i].x)<6 and points[i].z>-130 and points[i].z<175:
				continue # Do not cover the paved pit apron.
			for tuft in range(10):
				var p: Vector3=points[i]+_right_at(i)*side*detail_rng.randf_range(6.55,8.05)+f1*detail_rng.randf_range(-2.7,2.7)
				p.y=-.045
				var scale_:float=detail_rng.randf_range(.68,1.42)
				transforms.append(Transform3D(Basis(Vector3.UP,detail_rng.randf_range(0,TAU)).scaled(Vector3.ONE*scale_),p))
	_batch_instances(grass_mesh,material,transforms,false,"verge_detail")
