extends AudioStreamPlayer
## Original synthetic sound. This is not a recording or an accurate rotary-engine model.
var _playback: AudioStreamGeneratorPlayback
var _phase: float = 0.0
var _sub_phase: float = 0.0
var _frequency: float = 38.0
var _level: float = 0.0
var _noise: RandomNumberGenerator = RandomNumberGenerator.new()
var target_rpm: float = 950.0
var target_load: float = 0.0
var target_speed: float = 0.0
var target_slip: float = 0.0
var active: bool = false
var muted: bool = false

func _exit_tree() -> void:
	shutdown()

func shutdown() -> void:
	set_process(false)
	stop()
	_playback = null
	stream = null

func _ready() -> void:
	var generator := AudioStreamGenerator.new()
	generator.mix_rate = 22050.0
	generator.buffer_length = 0.15
	stream = generator
	volume_db = -9.0
	play()
	_playback = get_stream_playback()
	_noise.seed = 7315

func _process(_dt: float) -> void:
	if not _playback:
		return
	var available: int = _playback.get_frames_available()
	for _i in range(available):
		_frequency = lerpf(_frequency, target_rpm / 60.0 * 1.5, 0.0007)
		_level = lerpf(_level, (0.16 + 0.11 * target_load) if active and not muted else 0.0, 0.0014)
		_phase = fposmod(_phase + TAU * _frequency / 22050.0, TAU)
		_sub_phase = fposmod(_sub_phase + TAU * _frequency * 0.503 / 22050.0, TAU)
		var noise: float = _noise.randf_range(-1.0, 1.0)
		var motor: float = sin(_phase) * 0.55 + sin(_phase * 2.0) * 0.19 + sin(_phase * 3.0) * 0.10 + sin(_sub_phase) * 0.16
		var wind: float = noise * minf(absf(target_speed) / 65.0, 1.0) * 0.10
		var tyre: float = noise * clampf(absf(target_slip) / 5.0, 0.0, 1.0) * 0.18
		var sample: float = (motor + wind + tyre) * _level
		_playback.push_frame(Vector2(sample, sample))
