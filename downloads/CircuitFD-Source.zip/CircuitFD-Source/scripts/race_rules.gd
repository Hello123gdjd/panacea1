class_name CircuitRules
extends RefCounted
## Ordered sector validation. Reset always invalidates partial laps.
var total_length: float = 1000.0
var gate_count: int = 8
var next_gate: int = 1
var lap_time: float = 0.0
var best_time: float = 0.0
var completed_laps: int = 0
var valid: bool = true
var last_progress: float = 0.0
var running: bool = false
var message: String = "Cross the line and keep all eight sectors in order."

func reset(length_m: float, best: float = 0.0) -> void:
	total_length = maxf(length_m, 100.0)
	best_time = best
	next_gate = 1
	lap_time = 0.0
	valid = true
	last_progress = 0.0
	running = false
	message = "Eight ordered sectors · stay inside the circuit limits"

func tick(dt: float, progress_m: float, on_course: bool, moving_forward: bool, moving: bool) -> bool:
	if moving:
		running = true
	if running:
		lap_time += dt
	if not on_course and running:
		valid = false
		message = "LAP INVALID · track limits exceeded. Complete the lap or reset."
	var advance: float = fposmod(progress_m - last_progress + total_length * 0.5, total_length) - total_length * 0.5
	# Any discontinuous teleport cannot satisfy a sector.
	if absf(advance) > 12.0:
		valid = false
		message = "LAP INVALID · discontinuous progress"
	var completed: bool = false
	if advance > 0.0 and advance <= 12.0 and on_course and moving_forward:
		var target: float = total_length * float(next_gate) / gate_count
		var before: float = last_progress
		var after: float = last_progress + advance
		# The finish target is total_length, so forward wrap is handled explicitly.
		if next_gate < gate_count and before <= target and after >= target:
			next_gate += 1
		elif next_gate == gate_count and after >= total_length:
			if valid and lap_time > 10.0:
				completed_laps += 1
				if best_time <= 0.0 or lap_time < best_time:
					best_time = lap_time
				message = "VALID LAP · best %02d:%05.2f" % [int(best_time) / 60, fmod(best_time, 60.0)]
				completed = true
			else:
				message = "Lap discarded · a fresh lap starts now"
			next_gate = 1
			lap_time = 0.0
			valid = true
			running = true
	last_progress = progress_m
	return completed
