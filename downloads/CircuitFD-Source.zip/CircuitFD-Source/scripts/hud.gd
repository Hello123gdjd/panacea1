class_name CircuitHUD
extends CanvasLayer

signal drive_requested
signal resume_requested
signal reset_requested
signal setting_changed(key: String, value: Variant)
signal quit_requested
signal music_requested

const INK = Color("10191d")
const PANEL = Color(0.035, 0.048, 0.057, 0.95)
const WHITE = Color("edf1ec")
const MUTED = Color("99aaa9")
const ACCENT = Color("dfba60")

var root: Control
var menu: PanelContainer
var telemetry: PanelContainer
var top_card: PanelContainer
var brand: VBoxContainer
var hints: Label
var notice: Label
var speed_label: Label
var gear_label: Label
var rpm_bar: ProgressBar
var lap_label: Label
var time_label: Label
var best_label: Label
var camera_label: Label
var surface_label: Label
var drive_button: Button
var reset_button: Button
var minimap: TrackMap
var music_button: Button
var music_title_label: Label
var music_status_label: Label
var menu_music_button: Button
var initial_menu = true
var setting_controls: Dictionary = {}


class TrackMap extends Control:

	var points = PackedVector3Array()
	var car_position = Vector3.ZERO
	var car_yaw = 0.0

	func _draw() -> void:
		draw_rect(Rect2(Vector2.ZERO, size), Color(0.035, 0.048, 0.057, 0.88))
		draw_line(Vector2(0, 0), Vector2(size.x, 0), Color(0.87, 0.73, 0.37, 0.6), 1.0)
		draw_string(ThemeDB.fallback_font, Vector2(12, 18), "CIRCUIT MAP", HORIZONTAL_ALIGNMENT_LEFT, -1, 10, Color("99aaa9"))
		if points.size() < 2:
			return
		var low = Vector2(INF, INF)
		var high = Vector2(-INF, -INF)
		for p in points:
			low = low.min(Vector2(p.x, p.z))
			high = high.max(Vector2(p.x, p.z))
		var dimensions = high - low
		var scale_factor = minf((size.x - 32.0) / maxf(dimensions.x, 1.0), (size.y - 56.0) / maxf(dimensions.y, 1.0))
		var origin = size * 0.5 - (high + low) * 0.5 * scale_factor + Vector2(0, 10)
		var line = PackedVector2Array()
		for p in points:
			line.append(origin + Vector2(p.x, p.z) * scale_factor)
		line.append(line[0])
		draw_polyline(line, Color(0.22, 0.29, 0.29, 0.95), 6.0, true)
		draw_polyline(line, Color("a0aeaa"), 1.4, true)
		var start = origin + Vector2(points[0].x, points[0].z) * scale_factor
		draw_circle(start, 3.0, Color("ecf1ec"))
		var marker = origin + Vector2(car_position.x, car_position.z) * scale_factor
		var direction = Vector2(-sin(car_yaw), -cos(car_yaw))
		var side = direction.orthogonal()
		var tri = PackedVector2Array([marker + direction * 7.0, marker - direction * 4.0 + side * 4.5, marker - direction * 4.0 - side * 4.5])
		draw_colored_polygon(tri, Color("e2be57"))


func _ready() -> void:
	layer = 10
	root = Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)
	var theme = Theme.new()
	theme.default_font_size = 15
	theme.set_color("font_color", "Label", WHITE)
	theme.set_color("font_color", "Button", WHITE)
	theme.set_color("font_color", "OptionButton", WHITE)
	theme.set_color("font_color", "CheckButton", WHITE)
	theme.set_stylebox("normal", "Button", _box(Color("1c282e"), 5))
	theme.set_stylebox("hover", "Button", _box(Color("2c3b41"), 5))
	theme.set_stylebox("pressed", "Button", _box(Color("405252"), 5))
	theme.set_stylebox("focus", "Button", _outline())
	theme.set_stylebox("normal", "OptionButton", _box(Color("1c282e"), 4))
	theme.set_stylebox("hover", "OptionButton", _box(Color("2c3b41"), 4))
	root.theme = theme
	_build_brand()
	_build_telemetry()
	_build_timing()
	_build_map()
	_build_music_card()
	_build_menu()
	hints = _label("W / S  throttle / brake      A / D  steer      Q  reverse      C  view      L  lamps      R  reset      ESC  pause", 13, MUTED)
	root.add_child(hints)
	hints.add_theme_color_override("font_outline_color", Color(0.025, 0.04, 0.05, 0.85))
	hints.add_theme_constant_override("outline_size", 3)
	hints.mouse_filter = Control.MOUSE_FILTER_IGNORE
	notice = _label("", 17, ACCENT)
	notice.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	notice.add_theme_color_override("font_outline_color", Color(0.025, 0.04, 0.05, 0.85))
	notice.add_theme_constant_override("outline_size", 4)
	root.add_child(notice)
	notice.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.resized.connect(_layout)
	_layout()
	show_menu(true)


func _box(color: Color, radius: int = 9) -> StyleBoxFlat:
	var style = StyleBoxFlat.new()
	style.bg_color = color
	style.border_color = Color(0.5, 0.62, 0.65, 0.11)
	style.set_border_width_all(1)
	style.corner_radius_top_left = radius
	style.corner_radius_top_right = radius
	style.corner_radius_bottom_left = radius
	style.corner_radius_bottom_right = radius
	style.content_margin_left = 14
	style.content_margin_right = 14
	style.content_margin_top = 10
	style.content_margin_bottom = 10
	return style


func _outline() -> StyleBoxFlat:
	var style = _box(Color(0, 0, 0, 0), 7)
	style.border_color = ACCENT
	style.set_border_width_all(2)
	return style


func _label(text: String, size_px: int, color: Color = WHITE) -> Label:
	var item = Label.new()
	item.text = text
	item.add_theme_font_size_override("font_size", size_px)
	item.add_theme_color_override("font_color", color)
	return item


func _build_brand() -> void:
	brand = VBoxContainer.new()
	brand.add_theme_constant_override("separation", 1)
	root.add_child(brand)
	brand.add_child(_label("CIRCUIT / FD", 27))
	brand.add_child(_label("PARKLAND MOTOR CIRCUIT   /   02", 10, ACCENT))
	brand.mouse_filter = Control.MOUSE_FILTER_IGNORE


func _build_telemetry() -> void:
	telemetry = PanelContainer.new()
	var telemetry_style = _box(PANEL, 5)
	telemetry_style.border_width_left = 3
	telemetry_style.border_color = Color(0.87, 0.73, 0.37, 0.78)
	telemetry.add_theme_stylebox_override("panel", telemetry_style)
	root.add_child(telemetry)
	var column = VBoxContainer.new()
	column.add_theme_constant_override("separation", 2)
	telemetry.add_child(column)
	var row = HBoxContainer.new()
	row.add_theme_constant_override("separation", 16)
	column.add_child(row)
	speed_label = _label("000", 59)
	speed_label.custom_minimum_size = Vector2(118, 66)
	row.add_child(speed_label)
	var gear_column = VBoxContainer.new()
	gear_column.add_theme_constant_override("separation", 0)
	row.add_child(gear_column)
	gear_column.add_child(_label("GEAR", 10, MUTED))
	gear_label = _label("1", 32, ACCENT)
	gear_column.add_child(gear_label)
	gear_column.add_child(_label("KM / H", 10, MUTED))
	rpm_bar = ProgressBar.new()
	rpm_bar.show_percentage = false
	rpm_bar.min_value = 0
	rpm_bar.max_value = 8500
	rpm_bar.custom_minimum_size = Vector2(0, 5)
	var rpm_background = StyleBoxFlat.new()
	rpm_background.bg_color = Color("344144")
	var rpm_fill = StyleBoxFlat.new()
	rpm_fill.bg_color = ACCENT
	rpm_bar.add_theme_stylebox_override("background", rpm_background)
	rpm_bar.add_theme_stylebox_override("fill", rpm_fill)
	column.add_child(rpm_bar)
	var footer = HBoxContainer.new()
	column.add_child(footer)
	camera_label = _label("CHASE", 10, MUTED)
	camera_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	footer.add_child(camera_label)
	surface_label = _label("ASPHALT", 10, MUTED)
	footer.add_child(surface_label)


func _build_timing() -> void:
	top_card = PanelContainer.new()
	top_card.add_theme_stylebox_override("panel", _box(PANEL, 8))
	root.add_child(top_card)
	var row = HBoxContainer.new()
	row.add_theme_constant_override("separation", 24)
	top_card.add_child(row)
	var lap_column = VBoxContainer.new()
	lap_column.add_theme_constant_override("separation", 1)
	row.add_child(lap_column)
	lap_column.add_child(_label("LAP / SECTOR", 10, MUTED))
	lap_label = _label("01 / 01", 18, ACCENT)
	lap_column.add_child(lap_label)
	var time_column = VBoxContainer.new()
	time_column.add_theme_constant_override("separation", 1)
	row.add_child(time_column)
	time_column.add_child(_label("CURRENT", 10, MUTED))
	time_label = _label("00:00.00", 23)
	time_column.add_child(time_label)
	var best_column = VBoxContainer.new()
	best_column.add_theme_constant_override("separation", 1)
	row.add_child(best_column)
	best_column.add_child(_label("BEST", 10, MUTED))
	best_label = _label("— — : — —", 18, MUTED)
	best_column.add_child(best_label)


func _build_map() -> void:
	minimap = TrackMap.new()
	minimap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(minimap)


func _setting_row(parent: VBoxContainer, key: String, title: String, control: Control) -> void:
	setting_controls[key] = control
	var row = HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	parent.add_child(row)
	var label = _label(title, 13, MUTED)
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	label.custom_minimum_size.x = 134
	row.add_child(label)
	control.custom_minimum_size.x = 160
	control.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(control)


func _dropdown(items: Array[String], selected: int, callback: Callable) -> OptionButton:
	var control = OptionButton.new()
	for text in items:
		control.add_item(text)
	control.selected = selected
	control.item_selected.connect(callback)
	return control


func _slider(minimum: float, maximum: float, initial: float, increment: float, callback: Callable) -> HBoxContainer:
	var row = HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	var control = HSlider.new()
	control.min_value = minimum
	control.max_value = maximum
	control.step = increment
	control.value = initial
	control.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(control)
	var value_label = _label(("%.2f" if increment < 1.0 else "%d") % initial, 12, ACCENT)
	value_label.custom_minimum_size.x = 34
	value_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	row.add_child(value_label)
	control.value_changed.connect(func(value: float):
		value_label.text = ("%.2f" if increment < 1.0 else "%d") % value
		callback.call(value)
	)
	return row


func _check(enabled: bool, callback: Callable) -> CheckButton:
	var control = CheckButton.new()
	control.button_pressed = enabled
	control.text = "On" if enabled else "Off"
	control.toggled.connect(func(value: bool):
		control.text = "On" if value else "Off"
		callback.call(value)
	)
	return control


func _build_music_card() -> void:
	music_button = Button.new()
	music_button.text = ""
	music_button.tooltip_text = "Open Music Deck  /  M"
	music_button.add_theme_stylebox_override("normal", _box(Color(0.035, 0.048, 0.057, 0.87), 5))
	music_button.pressed.connect(func(): music_requested.emit())
	root.add_child(music_button)
	var column = VBoxContainer.new()
	column.position = Vector2(14, 8)
	column.mouse_filter = Control.MOUSE_FILTER_IGNORE
	column.add_theme_constant_override("separation", 2)
	music_button.add_child(column)
	music_status_label = _label("MUSIC DECK   /   M", 10, ACCENT)
	music_status_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	column.add_child(music_status_label)
	music_title_label = _label("Choose your soundtrack", 12, WHITE)
	music_title_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	music_title_label.custom_minimum_size.x = 240
	music_title_label.clip_text = true
	column.add_child(music_title_label)


func _tab(title: String, tabs: TabContainer) -> VBoxContainer:
	var wrapper = MarginContainer.new()
	wrapper.name = title
	wrapper.add_theme_constant_override("margin_top", 18)
	wrapper.add_theme_constant_override("margin_left", 0)
	wrapper.add_theme_constant_override("margin_right", 0)
	wrapper.add_theme_constant_override("margin_bottom", 8)
	tabs.add_child(wrapper)
	var scroll = ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	wrapper.add_child(scroll)
	var column = VBoxContainer.new()
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_theme_constant_override("separation", 12)
	scroll.add_child(column)
	return column


func _section(parent: VBoxContainer, text: String) -> void:
	parent.add_child(_label(text, 10, ACCENT))


func _build_menu() -> void:
	menu = PanelContainer.new()
	var style = _box(PANEL, 8)
	style.content_margin_left = 24
	style.content_margin_right = 24
	style.content_margin_top = 22
	style.content_margin_bottom = 20
	style.border_color = Color(0.87, 0.73, 0.37, 0.3)
	menu.add_theme_stylebox_override("panel", style)
	root.add_child(menu)
	var column = VBoxContainer.new()
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_theme_constant_override("separation", 12)
	menu.add_child(column)
	column.add_child(_label("THE PARKLAND SESSION   /   02", 10, ACCENT))
	column.add_child(_label("Built for the drive.", 29))
	column.add_child(_label("FD-inspired yellow coupe. Your circuit. Your soundtrack.", 12, MUTED))
	var buttons = HBoxContainer.new()
	buttons.add_theme_constant_override("separation", 8)
	column.add_child(buttons)
	drive_button = Button.new()
	drive_button.text = "DRIVE"
	drive_button.custom_minimum_size.y = 46
	drive_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for state in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
		drive_button.add_theme_color_override(state, INK)
	drive_button.add_theme_stylebox_override("normal", _box(ACCENT, 5))
	drive_button.add_theme_stylebox_override("hover", _box(Color("f4d67c"), 5))
	drive_button.pressed.connect(func():
		if initial_menu:
			drive_requested.emit()
		else:
			resume_requested.emit()
	)
	buttons.add_child(drive_button)
	reset_button = Button.new()
	reset_button.text = "RESET"
	reset_button.custom_minimum_size = Vector2(90, 46)
	reset_button.pressed.connect(func(): reset_requested.emit())
	buttons.add_child(reset_button)
	# Library access remains visible while the settings tabs scroll independently.
	menu_music_button = Button.new()
	menu_music_button.text = "OPEN MUSIC DECK     /     M"
	menu_music_button.custom_minimum_size.y = 40
	menu_music_button.pressed.connect(func(): music_requested.emit())
	column.add_child(menu_music_button)
	var tabs = TabContainer.new()
	tabs.size_flags_vertical = Control.SIZE_EXPAND_FILL
	tabs.custom_minimum_size.y = 280
	var tab_bar = tabs.get_tab_bar()
	tab_bar.add_theme_font_size_override("font_size", 12)
	tab_bar.add_theme_color_override("font_selected_color", ACCENT)
	tab_bar.add_theme_color_override("font_unselected_color", MUTED)
	tab_bar.add_theme_color_override("font_hovered_color", WHITE)
	var selected_tab = _box(Color(0.16, 0.19, 0.19, 0.85), 2)
	selected_tab.border_width_bottom = 2
	selected_tab.border_color = ACCENT
	selected_tab.content_margin_left = 10
	selected_tab.content_margin_right = 10
	selected_tab.content_margin_top = 7
	selected_tab.content_margin_bottom = 7
	tab_bar.add_theme_stylebox_override("tab_selected", selected_tab)
	tabs.add_theme_stylebox_override("tab_selected", selected_tab)
	tabs.add_theme_color_override("font_selected_color", ACCENT)
	var idle_tab = _box(Color(0.05, 0.07, 0.08, 0.65), 2)
	idle_tab.set_border_width_all(0)
	idle_tab.content_margin_left = 10
	idle_tab.content_margin_right = 10
	idle_tab.content_margin_top = 7
	idle_tab.content_margin_bottom = 7
	tab_bar.add_theme_stylebox_override("tab_unselected", idle_tab)
	tabs.add_theme_stylebox_override("tab_unselected", idle_tab)
	tab_bar.add_theme_stylebox_override("tab_hovered", _box(Color("29383c"), 2))
	tabs.add_theme_stylebox_override("panel", _box(Color(0, 0, 0, 0), 0))
	column.add_child(tabs)
	var session = _tab("SESSION", tabs)
	_section(session, "ATMOSPHERE")
	_setting_row(session, "time_of_day", "Time of day", _dropdown(["Day", "Golden hour", "Dusk"], 0, func(index: int): setting_changed.emit("time_of_day", index)))
	_setting_row(session, "weather", "Track surface", _dropdown(["Dry", "Wet"], 0, func(index: int): setting_changed.emit("weather", index)))
	_setting_row(session, "volume", "Master volume", _slider(0, 100, 55, 1, func(value: float): setting_changed.emit("volume", value)))
	_section(session, "THE SOUNDTRACK")
	var music_note = _label("Play your session soundtrack from the Music Deck.
M   Music Deck     P   Photo mode\nT   Time of day     F2   Dry / wet track", 12, MUTED)
	music_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	session.add_child(music_note)
	var camera_tab = _tab("CAR + CAMERA", tabs)
	_section(camera_tab, "CONTROL & VIEW")
	_setting_row(camera_tab, "steering", "Steering", _slider(0.5, 1.5, 1.0, 0.05, func(value: float): setting_changed.emit("steering", value)))
	_setting_row(camera_tab, "fov", "Field of view", _slider(60, 90, 72, 1, func(value: float): setting_changed.emit("fov", value)))
	_setting_row(camera_tab, "motion", "Camera motion", _check(true, func(value: bool): setting_changed.emit("motion", value)))
	_setting_row(camera_tab, "speed_fov", "Speed field of view", _check(false, func(value: bool): setting_changed.emit("speed_fov", value)))
	_section(camera_tab, "KEYBOARD")
	var controls = _label("W / S   Throttle / brake     A / D   Steer
Q   Forward / reverse     Space   Handbrake
C   Four cameras     L   Popup headlights
R   Reset     Esc   Pause", 12, MUTED)
	controls.add_theme_constant_override("line_spacing", 4)
	camera_tab.add_child(controls)
	var graphics = _tab("DISPLAY", tabs)
	_section(graphics, "IMAGE QUALITY")
	_setting_row(graphics, "quality", "Rendering", _dropdown(["Performance", "Balanced", "High"], 1, func(index: int): setting_changed.emit("quality", index)))
	_setting_row(graphics, "reflections", "Local reflections", _check(true, func(value: bool): setting_changed.emit("reflections", value)))
	_setting_row(graphics, "resolution", "Resolution", _dropdown(["1280 × 720", "1600 × 900", "1920 × 1080"], 0, func(index: int):
		var sizes = [Vector2i(1280, 720), Vector2i(1600, 900), Vector2i(1920, 1080)]
		setting_changed.emit("resolution", sizes[index])
	))
	_setting_row(graphics, "fullscreen", "Fullscreen", _check(false, func(value: bool): setting_changed.emit("fullscreen", value)))
	var graphics_note = _label("Performance reduces antialiasing and shadows.
Reflections and weather can increase GPU cost.", 12, MUTED)
	graphics_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	graphics.add_child(graphics_note)
	var quit = Button.new()
	quit.text = "EXIT SESSION"
	quit.custom_minimum_size.y = 33
	quit.pressed.connect(func(): quit_requested.emit())
	column.add_child(quit)


func _layout() -> void:
	if root == null or not is_instance_valid(menu):
		return
	var size = root.size
	brand.position = Vector2(28, 24)
	telemetry.position = Vector2(26, size.y - 187)
	telemetry.size = Vector2(230, 133)
	top_card.position = Vector2(size.x * 0.5 - 202, 24)
	top_card.size = Vector2(404, 66)
	minimap.position = Vector2(size.x - 220, size.y - 235)
	minimap.size = Vector2(196, 168)
	music_button.position = Vector2(size.x - 294, 24)
	music_button.size = Vector2(268, 57)
	if size.x < 1100:
		top_card.position.x = size.x - 404 - 26
		music_button.position.y = 104
	if size.x < 760:
		top_card.size.x = 360
		top_card.position.x = size.x - 360 - 26
	hints.position = Vector2(28, size.y - 32)
	hints.size = Vector2(maxf(size.x - 56, 1), 22)
	if size.x < 1100:
		hints.text = "W/S  drive    A/D  steer    C  view    M  music    P  photo    ESC  pause"
	else:
		hints.text = "W/S  drive    A/D  steer    SPACE  handbrake    Q  reverse    C  view    L  lamps    M  music    P  photo    T  time    F2  weather    ESC  pause"
	notice.position = Vector2(size.x * 0.5 - 280, size.y - 75)
	notice.size = Vector2(560, 28)
	var menu_width = clampf(size.x * 0.335, 420, 500)
	var menu_height = clampf(size.y - 80.0, 540.0, 650.0)
	menu.position = Vector2(size.x - menu_width - 32, (size.y - menu_height) * 0.5)
	menu.size = Vector2(menu_width, menu_height)


func set_map(points: PackedVector3Array) -> void:
	minimap.points = points
	minimap.queue_redraw()


func _format_time(seconds: float) -> String:
	if seconds < 0.0 or not is_finite(seconds):
		return "— — : — —"
	var hundredths = int(seconds * 100.0)
	return "%02d:%02d.%02d" % [hundredths / 6000, (hundredths / 100) % 60, hundredths % 100]


func update_state(data: Dictionary) -> void:
	speed_label.text = "%03d" % roundi(absf(float(data.get("speed", 0.0))))
	gear_label.text = str(data.get("gear", "1"))
	rpm_bar.value = float(data.get("rpm", 0.0))
	lap_label.text = "%02d / %02d·%02d" % [int(data.get("lap", 1)), int(data.get("next_gate", 1)), int(data.get("gate_count", 1))]
	time_label.text = _format_time(float(data.get("lap_time", 0.0)))
	best_label.text = _format_time(float(data.get("best_time", -1.0)))
	camera_label.text = str(data.get("camera", "CHASE")).to_upper()
	surface_label.text = str(data.get("surface", "asphalt")).to_upper()
	notice.text = str(data.get("message", ""))
	minimap.car_position = data.get("car_position", Vector3.ZERO)
	minimap.car_yaw = float(data.get("car_yaw", 0.0))
	minimap.queue_redraw()
	var music_title = str(data.get("music_title", ""))
	var music_playing = bool(data.get("music_playing", false))
	music_title_label.text = music_title if not music_title.is_empty() else "Choose your soundtrack"
	music_status_label.text = ("NOW PLAYING" if music_playing else "MUSIC DECK") + "   /   M"


func show_menu(initial: bool = false) -> void:
	initial_menu = initial
	menu.show()
	drive_button.text = "DRIVE" if initial else "RESUME"
	reset_button.visible = not initial
	top_card.hide()
	telemetry.hide()
	minimap.hide()
	music_button.hide()
	hints.hide()
	notice.hide()
	drive_button.grab_focus()


func hide_menu() -> void:
	initial_menu = false
	menu.hide()
	top_card.show()
	telemetry.show()
	minimap.show()
	music_button.show()
	hints.show()
	notice.show()


func apply_settings(values: Dictionary) -> void:
	# Config loading must update widgets without triggering saves or runtime changes.
	for key in values:
		if not setting_controls.has(key):
			continue
		var control: Control = setting_controls[key]
		var value: Variant = values[key]
		if control is OptionButton:
			var selected = 0
			if key == "resolution":
				var resolutions = [Vector2i(1280, 720), Vector2i(1600, 900), Vector2i(1920, 1080)]
				selected = resolutions.find(value)
				if selected < 0:
					selected = 0
			else:
				selected = clampi(int(value), 0, control.item_count - 1)
			control.select(selected)
		elif control is CheckButton:
			control.set_pressed_no_signal(bool(value))
			control.text = "On" if bool(value) else "Off"
		elif control is HBoxContainer and control.get_child_count() == 2:
			var slider: HSlider = control.get_child(0)
			var value_label: Label = control.get_child(1)
			slider.set_value_no_signal(float(value))
			value_label.text = ("%.2f" if slider.step < 1.0 else "%d") % slider.value
