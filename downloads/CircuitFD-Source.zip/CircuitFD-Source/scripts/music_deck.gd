class_name MusicDeck
extends CanvasLayer
## Local music library. Files stay on the player's computer; nothing is uploaded.
signal panel_closed
signal track_changed(title: String)

const DEMO_PATH: String = "res://assets/audio/afterhours.wav"
const SAVE_PATH: String = "user://music-library.json"
const GOLD := Color("e2be57")
const WHITE := Color("edf1ec")
const MUTED := Color("98aaa9")
const MAX_FILE_BYTES: int = 268435456

var panel: Control
var player: AudioStreamPlayer
var playlist: Array[Dictionary] = []
var current_index: int = -1
var repeat_mode: int = 1 # 0 off, 1 whole library, 2 current track
var shuffle: bool = false
var music_volume: float = 55.0
var last_error: String = ""
var _rng := RandomNumberGenerator.new()
var _root: Control
var _list: ItemList
var _title: Label
var _artist: Label
var _status: Label
var _time: Label
var _seek: HSlider
var _volume: HSlider
var _play_button: Button
var _repeat_button: Button
var _shuffle_button: Button
var _dialog: FileDialog
var _seeking: bool = false
var _ticker: float = 0.0
var _shutdown: bool = false

func _ready() -> void:
	layer = 25
	_rng.randomize()
	_ensure_bus()
	player = AudioStreamPlayer.new()
	player.bus = "Music"
	add_child(player)
	player.finished.connect(_on_finished)
	_build_ui()
	load_library()
	set_volume(music_volume, false)
	_refresh_list()
	_refresh_transport()
	_root.hide()

func _ensure_bus() -> void:
	if AudioServer.get_bus_index("Music") < 0:
		AudioServer.add_bus()
		var index: int = AudioServer.bus_count - 1
		AudioServer.set_bus_name(index, "Music")
		AudioServer.set_bus_send(index, "Master")

func _style(color: Color, radius: int = 12) -> StyleBoxFlat:
	var box := StyleBoxFlat.new()
	box.bg_color = color
	box.set_corner_radius_all(radius)
	box.content_margin_left = 18
	box.content_margin_right = 18
	box.content_margin_top = 12
	box.content_margin_bottom = 12
	return box

func _label(text: String, font_size: int = 16, color: Color = WHITE) -> Label:
	var label := Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	return label

func _button(text: String, callable: Callable) -> Button:
	var button := Button.new()
	button.text = text
	button.custom_minimum_size = Vector2(0, 40)
	button.pressed.connect(callable)
	return button

func _build_ui() -> void:
	_root = Control.new()
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(_root)
	var shade := ColorRect.new()
	shade.color = Color(0.016, 0.026, 0.035, 0.82)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_root.add_child(shade)
	panel = PanelContainer.new()
	panel.add_theme_stylebox_override("panel", _style(Color("101a20"), 18))
	_root.add_child(panel)
	var theme := Theme.new()
	theme.default_font_size = 16
	theme.set_color("font_color", "Button", WHITE)
	theme.set_stylebox("normal", "Button", _style(Color("25343c"), 7))
	theme.set_stylebox("hover", "Button", _style(Color("394b51"), 7))
	theme.set_stylebox("pressed", "Button", _style(Color("50605d"), 7))
	panel.theme = theme
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	panel.add_child(scroll)
	var column := VBoxContainer.new()
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_theme_constant_override("separation", 12)
	scroll.add_child(column)
	var heading := HBoxContainer.new()
	column.add_child(heading)
	var title_box := VBoxContainer.new()
	title_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	heading.add_child(title_box)
	title_box.add_child(_label("FD / MUSIC DECK", 28))
	title_box.add_child(_label("YOUR LOCAL LIBRARY  /  NO STREAMING OR UPLOAD", 11, GOLD))
	heading.add_child(_button("BACK TO GAME", hide_panel))
	var track_card := PanelContainer.new()
	track_card.add_theme_stylebox_override("panel", _style(Color("1c2a32"), 10))
	column.add_child(track_card)
	var track_row := HBoxContainer.new()
	track_row.add_theme_constant_override("separation", 18)
	track_card.add_child(track_row)
	var cover := PanelContainer.new()
	cover.custom_minimum_size = Vector2(82, 82)
	cover.add_theme_stylebox_override("panel", _style(Color("64522d"), 12))
	track_row.add_child(cover)
	var cover_label := _label("FD\nAUDIO", 22, GOLD)
	cover_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	cover.add_child(cover_label)
	var detail := VBoxContainer.new()
	detail.alignment = BoxContainer.ALIGNMENT_CENTER
	detail.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	track_row.add_child(detail)
	_title = _label("Choose a track", 24)
	_title.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	detail.add_child(_title)
	_artist = _label("Original demo included. Add music from your computer.", 13, MUTED)
	_artist.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	detail.add_child(_artist)
	_list = ItemList.new()
	_list.custom_minimum_size = Vector2(0, 160)
	_list.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_list.add_theme_stylebox_override("panel", _style(Color("0b1319"), 8))
	_list.add_theme_font_size_override("font_size", 17)
	_list.add_theme_color_override("font_color", WHITE)
	_list.add_theme_color_override("font_selected_color", Color("111b1f"))
	_list.add_theme_stylebox_override("selected", _style(GOLD, 5))
	_list.item_activated.connect(func(index: int): play_index(index))
	column.add_child(_list)
	var library_buttons := HBoxContainer.new()
	library_buttons.add_theme_constant_override("separation", 8)
	column.add_child(library_buttons)
	library_buttons.add_child(_button("+ ADD FILES", _open_file_picker))
	library_buttons.add_child(_button("PLAY SELECTED", _play_selected))
	library_buttons.add_child(_button("REMOVE", _remove_selected))
	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	library_buttons.add_child(spacer)
	library_buttons.add_child(_label("MP3  /  OGG VORBIS  /  WAV", 11, MUTED))
	var progress := HBoxContainer.new()
	column.add_child(progress)
	_seek = HSlider.new()
	_seek.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_seek.custom_minimum_size = Vector2(0, 28)
	_seek.min_value = 0.0
	_seek.max_value = 1.0
	_seek.step = 0.1
	_seek.drag_started.connect(func(): _seeking = true)
	_seek.drag_ended.connect(func(changed: bool):
		_seeking = false
		if changed: seek_to(_seek.value))
	_seek.value_changed.connect(func(value: float):
		if _seeking: _time.text = _format_time(value) + " / " + _format_time(duration()))
	progress.add_child(_seek)
	_time = _label("00:00 / 00:00", 13, MUTED)
	_time.custom_minimum_size = Vector2(110, 0)
	_time.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	progress.add_child(_time)
	var transport := HBoxContainer.new()
	transport.add_theme_constant_override("separation", 8)
	column.add_child(transport)
	transport.add_child(_button("PREV", previous_track))
	_play_button = _button("PLAY", toggle_playback)
	_play_button.custom_minimum_size.x = 100
	_play_button.add_theme_stylebox_override("normal", _style(GOLD, 7))
	_play_button.add_theme_stylebox_override("hover", _style(Color("efcf74"), 7))
	_play_button.add_theme_stylebox_override("pressed", _style(Color("b59b4e"), 7))
	_play_button.add_theme_color_override("font_color", Color("101a20"))
	_play_button.add_theme_color_override("font_hover_color", Color("101a20"))
	_play_button.add_theme_color_override("font_pressed_color", Color("101a20"))
	transport.add_child(_play_button)
	transport.add_child(_button("NEXT", next_track))
	_shuffle_button = _button("SHUFFLE OFF", func(): set_shuffle(not shuffle))
	transport.add_child(_shuffle_button)
	_repeat_button = _button("REPEAT ALL", func(): set_repeat_mode((repeat_mode + 1) % 3))
	transport.add_child(_repeat_button)
	var vol_spacer := Control.new()
	vol_spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	transport.add_child(vol_spacer)
	transport.add_child(_label("MUSIC", 11, MUTED))
	_volume = HSlider.new()
	_volume.min_value = 0
	_volume.max_value = 100
	_volume.step = 1
	_volume.custom_minimum_size.x = 110
	_volume.value_changed.connect(func(value: float): set_volume(value))
	transport.add_child(_volume)
	_status = _label("Music keeps playing when you return to driving. Nothing starts automatically.", 12, MUTED)
	_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(_status)
	_dialog = FileDialog.new()
	_dialog.title = "Add local music — MP3 / OGG Vorbis / WAV"
	_dialog.access = FileDialog.ACCESS_FILESYSTEM
	_dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILES
	_dialog.filters = PackedStringArray(["*.mp3 ; MP3 audio", "*.ogg ; Ogg Vorbis audio", "*.wav ; WAV audio"])
	_dialog.use_native_dialog = true
	_dialog.files_selected.connect(add_files)
	var music_directory: String = OS.get_system_dir(OS.SYSTEM_DIR_MUSIC)
	if not music_directory.is_empty() and DirAccess.dir_exists_absolute(music_directory):
		_dialog.current_dir = music_directory
	add_child(_dialog)
	_root.resized.connect(_layout)
	_layout()

func _layout() -> void:
	if not panel or not _root:
		return
	var available: Vector2 = get_viewport().get_visible_rect().size
	var width: float = maxf(300.0, minf(900.0, available.x - 32.0))
	var height: float = maxf(260.0, minf(660.0, available.y - 32.0))
	panel.size = Vector2(width, height)
	panel.position = (available - panel.size) * 0.5

func show_panel() -> void:
	_root.show()
	_refresh_list()
	_refresh_transport()
	_layout()

func hide_panel() -> void:
	var was_visible: bool = _root.visible
	_root.hide()
	if was_visible:
		panel_closed.emit()

func toggle_panel() -> void:
	if _root.visible: hide_panel()
	else: show_panel()

func is_panel_open() -> bool:
	return is_instance_valid(_root) and _root.visible

func _open_file_picker() -> void:
	_dialog.popup_centered_ratio(0.75)

func _play_selected() -> void:
	var selected: PackedInt32Array = _list.get_selected_items()
	if selected.size() > 0: play_index(selected[0])
	elif not playlist.is_empty(): play_index(0)

func _remove_selected() -> void:
	var selected: PackedInt32Array = _list.get_selected_items()
	if selected.size() > 0: remove_track(selected[0])

func _error(message: String) -> void:
	last_error = message
	if is_instance_valid(_status):
		_status.text = message
		_status.add_theme_color_override("font_color", Color("edb18b"))

func _validate_path(path: String) -> bool:
	if path.begins_with("http:") or path.begins_with("https:"):
		_error("Choose a local file. Internet streams are not supported.")
		return false
	if not path.is_absolute_path() and not path.begins_with("res://") and not path.begins_with("user://"):
		_error("The music path must point to a local file.")
		return false
	if not FileAccess.file_exists(path) and not ResourceLoader.exists(path):
		_error("File not found: " + path.get_file())
		return false
	if path.get_extension().to_lower() not in ["mp3", "ogg", "wav"]:
		_error("Supported formats are MP3, OGG Vorbis and WAV.")
		return false
	var file := FileAccess.open(path, FileAccess.READ)
	if not file:
		# The bundled WAV can exist only as an imported resource in an exported pack.
		return path == DEMO_PATH and ResourceLoader.exists(path)
	if file.get_length() > MAX_FILE_BYTES:
		_error("File exceeds the 256 MiB per-track limit.")
		return false
	var bytes: PackedByteArray = file.get_buffer(16)
	var extension: String = path.get_extension().to_lower()
	var valid_header: bool = false
	if extension == "wav":
		valid_header = bytes.size() >= 12 and bytes.slice(0, 4).get_string_from_ascii() == "RIFF" and bytes.slice(8, 12).get_string_from_ascii() == "WAVE"
	elif extension == "ogg":
		valid_header = bytes.size() >= 4 and bytes.slice(0, 4).get_string_from_ascii() == "OggS"
	elif extension == "mp3":
		valid_header = bytes.size() >= 3 and (bytes.slice(0, 3).get_string_from_ascii() == "ID3" or (bytes[0] == 255 and (bytes[1] & 224) == 224))
	if not valid_header:
		_error("The file header is not valid " + extension.to_upper() + " audio: " + path.get_file())
	return valid_header

func _load_stream(path: String) -> AudioStream:
	if not _validate_path(path):
		return null
	if path == DEMO_PATH:
		var bundled: Resource = load(DEMO_PATH)
		return bundled as AudioStream
	match path.get_extension().to_lower():
		"mp3": return AudioStreamMP3.load_from_file(path)
		"ogg": return AudioStreamOggVorbis.load_from_file(path)
		"wav": return AudioStreamWAV.load_from_file(path)
	return null

func add_files(paths: PackedStringArray) -> void:
	var added: int = 0
	for path in paths:
		if add_track(path, false): added += 1
	save_library()
	_refresh_list()
	if added > 0:
		_status.text = "%d track(s) added. Double-click a title or choose PLAY SELECTED." % added
		_status.add_theme_color_override("font_color", MUTED)

func add_track(path: String, save: bool = true) -> bool:
	if playlist.size() >= 300:
		_error("The library is limited to 300 local tracks.")
		return false
	for item in playlist:
		if item.path == path:
			_error("This file is already in your library.")
			return false
	var stream: AudioStream = _load_stream(path)
	if not stream or stream.get_length() <= 0.0:
		_error("Cannot decode this track. Use a valid MP3, OGG Vorbis or PCM WAV file.")
		return false
	var title: String = "Afterhours — original Circuit FD mix" if path == DEMO_PATH else path.get_file().get_basename().replace("_", " ")
	playlist.append({"path": path, "title": title})
	if save: save_library()
	_refresh_list()
	return true

func remove_track(index: int) -> void:
	if index < 0 or index >= playlist.size(): return
	if index == current_index:
		stop_playback()
		player.stream = null
		current_index = -1
	elif index < current_index:
		current_index -= 1
	playlist.remove_at(index)
	save_library()
	_refresh_list()
	_refresh_transport()

func play_index(index: int) -> bool:
	if _shutdown or index < 0 or index >= playlist.size():
		return false
	var stream: AudioStream = _load_stream(playlist[index].path)
	if not stream or stream.get_length() <= 0.0:
		_error("This track is missing or cannot be decoded. Remove it or add the file again.")
		return false
	player.stop()
	player.stream = stream
	player.stream_paused = false
	player.play()
	current_index = index
	last_error = ""
	_status.text = "Playing local audio. M opens the music deck while driving."
	_status.add_theme_color_override("font_color", MUTED)
	_refresh_list()
	_refresh_transport()
	track_changed.emit(playlist[index].title)
	return true

func toggle_playback() -> void:
	# Godot reports playing=false while stream_paused=true. Resume that playback
	# before considering a new play_index(), otherwise every resume restarts at zero.
	if player.stream and player.stream_paused:
		player.stream_paused = false
	elif player.playing:
		player.stream_paused = true
	elif current_index >= 0 and current_index < playlist.size():
		play_index(current_index)
	elif not playlist.is_empty():
		play_index(0)
	_refresh_transport()

func pause_playback() -> void:
	if player.playing:
		player.stream_paused = true
	_refresh_transport()

func stop_playback() -> void:
	player.stop()
	player.stream_paused = false
	_refresh_transport()

func is_playing() -> bool:
	return is_instance_valid(player) and player.playing and not player.stream_paused

func is_music_playing() -> bool:
	return is_playing()

func get_current_title() -> String:
	if current_index >= 0 and current_index < playlist.size():
		return str(playlist[current_index].title)
	return "Music Deck · choose your soundtrack"

func next_track() -> void:
	if playlist.is_empty(): return
	var next: int = (current_index + 1) % playlist.size()
	if shuffle and playlist.size() > 1:
		if current_index < 0:
			next = _rng.randi_range(0, playlist.size() - 1)
		else:
			next = _rng.randi_range(0, playlist.size() - 2)
			if next >= current_index: next += 1
	play_index(next)

func previous_track() -> void:
	if playlist.is_empty(): return
	if current_index < 0:
		play_index(playlist.size() - 1)
	elif current_index >= 0 and (player.playing or player.stream_paused) and player.get_playback_position() > 3.0:
		seek_to(0.0)
	else:
		play_index(posmod(current_index - 1, playlist.size()))

func duration() -> float:
	return player.stream.get_length() if is_instance_valid(player) and player.stream else 0.0

func seek_to(seconds: float) -> bool:
	if not player.stream or duration() <= 0.0:
		return false
	var destination: float = clampf(seconds, 0.0, maxf(0.0, duration() - 0.01))
	if not player.playing:
		player.play(destination)
		player.stream_paused = true
	else:
		player.seek(destination)
	_refresh_transport()
	return true

func set_volume(value: float, save: bool = true) -> void:
	music_volume = clampf(value, 0.0, 100.0)
	_ensure_bus()
	AudioServer.set_bus_volume_db(AudioServer.get_bus_index("Music"), linear_to_db(maxf(music_volume / 100.0, 0.0001)))
	if is_instance_valid(_volume): _volume.set_value_no_signal(music_volume)
	if save: save_library()

func set_shuffle(enabled: bool) -> void:
	shuffle = enabled
	save_library()
	_refresh_transport()

func set_repeat_mode(mode: int) -> void:
	repeat_mode = clampi(mode, 0, 2)
	save_library()
	_refresh_transport()

func _on_finished() -> void:
	if _shutdown: return
	if repeat_mode == 2 and current_index >= 0:
		play_index(current_index)
	elif shuffle and playlist.size() > 1:
		next_track()
	elif current_index + 1 < playlist.size():
		play_index(current_index + 1)
	elif repeat_mode == 1 and not playlist.is_empty():
		play_index(0)
	else:
		stop_playback()
	_refresh_transport()

func _refresh_list() -> void:
	if not is_instance_valid(_list): return
	var selected: PackedInt32Array = _list.get_selected_items()
	var previous: int = selected[0] if selected.size() > 0 else current_index
	_list.clear()
	for i in range(playlist.size()):
		_list.add_item(("NOW  " if i == current_index else "%02d    " % [i + 1]) + str(playlist[i].title))
	if previous >= 0 and previous < playlist.size(): _list.select(previous)

func _format_time(seconds: float) -> String:
	var total: int = int(maxf(0.0, seconds))
	return "%02d:%02d" % [total / 60, total % 60]

func _refresh_transport() -> void:
	if not is_instance_valid(_play_button): return
	_play_button.text = "PAUSE" if is_playing() else "PLAY"
	_repeat_button.text = ["REPEAT OFF", "REPEAT ALL", "REPEAT ONE"][repeat_mode]
	_shuffle_button.text = "SHUFFLE ON" if shuffle else "SHUFFLE OFF"
	if current_index >= 0 and current_index < playlist.size():
		_title.text = str(playlist[current_index].title)
		_artist.text = "ORIGINAL SYNTH INSTRUMENTAL  /  100 BPM" if playlist[current_index].path == DEMO_PATH else "LOCAL FILE  /  " + str(playlist[current_index].path).get_extension().to_upper()
	else:
		_title.text = "Your soundtrack. Your drive."
		_artist.text = "Original demo included. Add files from your computer."
	var length: float = duration()
	_seek.max_value = maxf(length, 0.1)
	_seek.editable = length > 0.0
	if not _seeking:
		var position: float = player.get_playback_position() if player.stream else 0.0
		_seek.set_value_no_signal(position)
		_time.text = _format_time(position) + " / " + _format_time(length)

func _process(dt: float) -> void:
	_ticker += dt
	if _ticker >= 0.12:
		_ticker = 0.0
		_refresh_transport()

func load_library() -> void:
	if is_instance_valid(player):
		player.stop()
		player.stream = null
	playlist.clear()
	var stored: Variant = null
	if FileAccess.file_exists(SAVE_PATH):
		var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
		if file and file.get_length() < 1048576:
			var parser := JSON.new()
			if parser.parse(file.get_as_text()) == OK:
				stored = parser.data
	if stored is Dictionary:
		if stored.get("volume") is float or stored.get("volume") is int:
			music_volume = clampf(float(stored.volume), 0.0, 100.0)
		if stored.get("repeat") is float or stored.get("repeat") is int:
			repeat_mode = clampi(int(stored.repeat), 0, 2)
		if stored.get("shuffle") is bool: shuffle = stored.shuffle
		var items: Variant = stored.get("tracks", [])
		if items is Array:
			for item in items.slice(0, 300):
				if item is Dictionary and item.get("path") is String:
					var path: String = item.path
					if path == DEMO_PATH or FileAccess.file_exists(path):
						if path.get_extension().to_lower() in ["mp3", "wav", "ogg"]:
							playlist.append({"path": path, "title": str(item.get("title", path.get_file().get_basename())).left(160)})
	if playlist.is_empty():
		playlist.append({"path": DEMO_PATH, "title": "Afterhours — original Circuit FD mix"})
	current_index = -1
	last_error = ""
	_refresh_list()
	_refresh_transport()

func save_library() -> void:
	var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify({"version": 1, "volume": music_volume, "repeat": repeat_mode, "shuffle": shuffle, "tracks": playlist}, "  "))
	else:
		_error("Music library could not be saved. Playback can still continue.")

func shutdown() -> void:
	if _shutdown: return
	_shutdown = true
	set_process(false)
	if is_instance_valid(player):
		player.stop()
		player.stream = null
	if is_instance_valid(_dialog): _dialog.hide()

func _exit_tree() -> void:
	shutdown()
