class_name CircuitVehicle
extends Node3D
## A deliberately small planar tyre/engine model. Not a validated vehicle simulator.
## Positive steering turns left, the car faces -Z, speed is signed metres/second.

const MASS: float = 1280.0
const WHEELBASE: float = 2.425
const TYRE_RADIUS: float = 0.31
const GRAVITY: float = 9.81
const FINAL_DRIVE: float = 4.10
const RATIOS: Array[float] = [3.483, 2.015, 1.391, 1.000, 0.806]

var velocity: Vector3 = Vector3.ZERO
var speed: float = 0.0
var steer: float = 0.0
var throttle: float = 0.0
var brake: float = 0.0
var rpm: float = 950.0
var gear: int = 1
var lateral_slip: float = 0.0
var yaw_rate: float = 0.0
var longitudinal_accel: float = 0.0
var steering_sensitivity: float = 1.0
var _shift_cooldown: float = 0.0

func reset_to(point: Vector3, yaw: float) -> void:
	position = Vector3(point.x, 0.0, point.z)
	rotation = Vector3(0.0, yaw, 0.0)
	velocity = Vector3.ZERO
	speed = 0.0
	steer = 0.0
	throttle = 0.0
	brake = 0.0
	rpm = 950.0
	gear = 1
	lateral_slip = 0.0
	yaw_rate = 0.0
	longitudinal_accel = 0.0
	_shift_cooldown = 0.0

func surface_grip(surface: String) -> float:
	match surface:
		"wet": return 0.76
		"grass": return 0.46
		"gravel": return 0.60
		_: return 1.03

func step(dt: float, throttle_input: float, brake_input: float, steer_input: float, reverse: bool, handbrake: bool, surface: String = "asphalt") -> void:
	if dt <= 0.0:
		return
	# Guard accidental caller spikes; the game calls this from its fixed physics tick.
	dt = minf(dt, 0.05)
	throttle = move_toward(throttle, clampf(throttle_input, 0.0, 1.0), dt * 2.6)
	brake = move_toward(brake, clampf(brake_input, 0.0, 1.0), dt * 7.5)
	var forward: Vector3 = -basis.z
	var right: Vector3 = basis.x
	var old_speed: float = velocity.dot(forward)
	var lateral_speed: float = velocity.dot(right)
	var grip: float = surface_grip(surface)
	var max_steer: float = lerpf(0.53, 0.13, clampf(absf(old_speed) / 55.0, 0.0, 1.0))
	var steering_target: float = clampf(steer_input * steering_sensitivity, -1.0, 1.0) * max_steer
	steer = lerpf(steer, steering_target, 1.0 - exp(-7.8 * dt))
	_shift_cooldown = maxf(0.0, _shift_cooldown - dt)
	var direction_change: bool = (reverse and gear > 0) or (not reverse and gear < 0)
	if direction_change and absf(old_speed) < 0.65:
		gear = -1 if reverse else 1
		_shift_cooldown = 0.20
		direction_change = false
	var ratio: float = 3.25 if gear < 0 else RATIOS[gear - 1]
	var wheel_rpm: float = absf(old_speed) / (TAU * TYRE_RADIUS) * 60.0
	var coupled_rpm: float = wheel_rpm * ratio * FINAL_DRIVE
	if gear > 0 and _shift_cooldown <= 0.0:
		if coupled_rpm > 7200.0 and gear < RATIOS.size():
			gear += 1
			_shift_cooldown = 0.23
		elif coupled_rpm < 2900.0 and gear > 1:
			gear -= 1
			_shift_cooldown = 0.23
		ratio = RATIOS[gear - 1]
		coupled_rpm = wheel_rpm * ratio * FINAL_DRIVE
	var desired_rpm: float = clampf(maxf(coupled_rpm, 950.0 + throttle * 850.0), 950.0, 7900.0)
	rpm = lerpf(rpm, desired_rpm, 1.0 - exp(-12.0 * dt))
	# Broad rotary-inspired torque curve, a heuristic rather than measured RX-7 data.
	var torque: float = 245.0 + 55.0 * exp(-pow((rpm - 4900.0) / 2200.0, 2.0))
	var shift_factor: float = 0.20 if _shift_cooldown > 0.08 else 1.0
	var drive_force: float = torque * ratio * FINAL_DRIVE * 0.88 / TYRE_RADIUS
	drive_force = minf(drive_force, MASS * grip * GRAVITY * 0.62)
	var engine_accel: float = throttle * drive_force / MASS * shift_factor
	if rpm > 7750.0:
		engine_accel = 0.0
	if direction_change or brake > 0.05 or (handbrake and absf(old_speed) < 2.0):
		engine_accel = 0.0
	if gear < 0:
		engine_accel *= -0.65
		if old_speed < -11.0:
			engine_accel = 0.0
	var longitudinal: float = old_speed + engine_accel * dt
	var drag_accel: float = 0.00034 * old_speed * old_speed
	var rolling_accel: float = 0.14 if surface == "asphalt" or surface == "wet" else 0.72
	var braking_accel: float = brake * grip * GRAVITY * 0.92
	if direction_change:
		braking_accel = maxf(braking_accel, grip * GRAVITY * 0.65)
	if handbrake:
		braking_accel = maxf(braking_accel, grip * GRAVITY * 0.38)
	longitudinal = move_toward(longitudinal, 0.0, (drag_accel + rolling_accel + braking_accel) * dt)
	if throttle < 0.01 and absf(longitudinal) < 0.045:
		longitudinal = 0.0
	# Steering is limited by lateral friction and a gentle high-speed understeer term.
	var target_yaw: float = longitudinal / WHEELBASE * tan(steer) / (1.0 + 0.0016 * longitudinal * longitudinal)
	var max_yaw: float = grip * GRAVITY / maxf(absf(longitudinal), 2.0)
	target_yaw = clampf(target_yaw, -max_yaw, max_yaw)
	if handbrake:
		target_yaw *= 1.22
	yaw_rate = lerpf(yaw_rate, target_yaw, 1.0 - exp(-6.0 * dt))
	if absf(longitudinal) < 0.035 and absf(lateral_speed) < 0.035:
		yaw_rate = 0.0
		lateral_speed = 0.0
	# Lateral velocity carries inertia; finite tyre force damps the slip after yaw.
	velocity = forward * longitudinal + right * lateral_speed
	rotation.y += yaw_rate * dt
	forward = -basis.z
	right = basis.x
	var new_longitudinal: float = velocity.dot(forward)
	var new_lateral: float = velocity.dot(right)
	var lateral_damping: float = 1.0 - exp(-9.0 * grip * dt)
	if handbrake:
		lateral_damping *= 0.22
	var lateral_change: float = clampf(new_lateral * lateral_damping, -grip * GRAVITY * dt, grip * GRAVITY * dt)
	new_lateral -= lateral_change
	velocity = forward * new_longitudinal + right * new_lateral
	velocity.y = 0.0
	position += velocity * dt
	position.y = 0.0
	speed = new_longitudinal
	lateral_slip = new_lateral
	longitudinal_accel = (speed - old_speed) / dt
