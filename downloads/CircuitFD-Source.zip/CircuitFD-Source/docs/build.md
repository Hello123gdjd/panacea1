# Building Circuit FD

## Windows x64

1. Install the standard **Godot 4.6.3** editor (not the .NET edition; no C# runtime is required).
2. In Godot choose **Editor → Manage Export Templates** and install the matching **4.6.3.stable** official export templates.
3. Import `project.godot` from the source directory, then choose **Project → Export → Windows Desktop → Export Project**.
4. Use release mode and save to `artifacts/CircuitFD.exe`.

Command-line equivalent, with the Godot executable on PATH:

```powershell
New-Item -ItemType Directory -Force artifacts | Out-Null
godot --headless --path . --editor --import --quit
godot --headless --path . --export-release "Windows Desktop" "artifacts/CircuitFD.exe"
```

The preset embeds the game PCK in the x64 executable. There are no external art files, native plugins or additional redistributables to copy. Windows supplies the OpenGL driver; install the GPU manufacturer's supported driver if the driver only exposes Microsoft's OpenGL 1.1 fallback. The executable is unsigned and Windows may display its normal reputation warning. Signing is not configured.

Godot's compatibility renderer requires OpenGL 3.3 support. A target of Windows 10/11 x64 with a functioning hardware driver is proposed; native Windows execution and a specific GPU performance result are not implied by the Linux tests.

## Linux build environment used here

`bash tools/build.sh` imports and exports the Windows binary. Official export templates were downloaded from the Godot release and verified using `SHA512-SUMS.txt` before extraction. They are retained outside the project in `/workspace/.game-tools`; a standard installed template can be used elsewhere. Set `GODOT_BIN` when the executable is not named `godot`.

`bash tools/render.sh godot --path . --audio-driver Dummy` starts a temporary Xvfb display and forces Mesa software rendering for visual tests. It requires the separately prepared Xvfb runtime at `/workspace/.game-tools/root/usr/bin/Xvfb`, or an `XVFB_BIN` override. The helper is for this Linux test environment, not for players. It cleans up only the X server process it started.

## Verification boundaries

A successful export and PE32+ x86-64 inspection verifies packaging and target architecture. Linux rendering verifies a separate Linux executable's scene and OpenGL path. Neither proves the exported binary runs on a real Windows machine. That check remains required before calling the release Windows-tested.

## Tool sources

- Editor and templates: <https://github.com/godotengine/godot-builds/releases/tag/4.6.3-stable>
- Official SHA-512 manifest: same release, `SHA512-SUMS.txt`.
- Xvfb: Debian trixie package, acquired using signed Debian archive metadata and extracted without altering the system.
- Software rendering: system Mesa llvmpipe 25.0.7, LLVM 19.1.7.

## Packaging

After the final successful build and documentation update, run:

```bash
python3 tools/package.py
```

It verifies the executable's PE/x64 header and embedded PCK, then writes `artifacts/CircuitFD-Windows-x64.zip`, `artifacts/CircuitFD-Source.zip`, and `artifacts/package-manifest.json` with SHA-256 hashes. Documentation and license notices accompany the executable. Source archives exclude engine caches and generated build products.

The build helper checks Godot output for engine/script errors because Godot can return exit status zero even when an imported GDScript failed to parse. A Windows export is accepted only after clean import/export logs and PE/PCK checks.
