# v0.2 driving and weather regression report

The validated dry driving model is preserved. No countersteer aid, power increase, boost or automatic path correction was added. Graphics, music, cameras and weather appearance are separate from this planar physics model.

## Wet asphalt

`CircuitVehicle.step(..., surface)` accepts `"wet"`, with heuristic friction coefficient **0.76** versus **1.03** for dry asphalt. Wet asphalt keeps paved rolling resistance (**0.14 m/s²**); it is not treated as gravel. The existing finite tyre/brake/yaw limits therefore produce reduced traction and longer braking, without unbounded slipping or a sudden change to engine power. Grass and gravel retain their earlier settings. These coefficients are illustrative game tuning, not measured RX-7 tyre data. There is no water-depth, aquaplaning, temperature or dynamic drying simulation.

## Executed checks

All results below came from Godot **4.6.3 official Linux x86_64**, headless, with a **120 Hz fixed physics tick**. These are simulation results, not native Windows tests, real-car measurements or graphical frame-rate benchmarks.

| Check | Result |
|---|---|
| Physics assertions, including original tests | **25 passed, 0 failed** |
| Race validation assertions | **22 passed, 0 failed** |
| Real track/controller integration assertions | **11 passed, 0 failed** |
| Dry scripted full circuit | **1 valid lap**, 116.133 simulated seconds, maximum centreline departure 0.549 m |
| Wet scripted full circuit | **1 valid lap**, 116.392 simulated seconds, maximum centreline departure 0.539 m |
| Straight braking from 90 km/h, dry | **34.143 m**, comes to rest |
| Straight braking from 90 km/h, wet | **45.358 m**, comes to rest |
| Render-loop grouping at 30, 60 and 144 Hz | Identical trajectory after **720 fixed ticks**, 6 simulated seconds |

The braking test starts at exactly 25 m/s with zero throttle, applies the model's normal smoothed full brake, and stops counting at rest. The wet distance is about **33% longer** under this implemented approximation. Both surface types retain finite lateral-force damping.

The render-loop check accumulates render frame durations and steps physics only in 1/120-second intervals. It applies gas, steering and brake changes by **simulation time**, so it verifies frame grouping rather than introducing different input schedules. The exact same 720 physics steps execute at all three render rates. It is not a rendering performance benchmark and does not claim the GPU achieves those rates.

The real-car full-lap checks use the existing pure-pursuit regression driver on the generated **1,469.602 m** circuit, operating through gas, brake and steering. They do not teleport, snap to the path or invoke barrier correction to rescue mistakes. Wet and dry lap times are close because this conservative regression driver targets lateral acceleration below either surface limit; the braking and traction assertions specifically exercise the wet-grip difference. Peak simulated speeds were 61.003 km/h dry and 60.969 km/h wet. Human keyboard handling and graphical performance still require their separate assessments.

Run from the source directory:

```sh
godot --headless --path . --script tests/physics_tests.gd
godot --headless --path . --script tests/race_tests.gd
godot --headless --path . --script tests/integration_tests.gd
godot --headless --path . --script tests/route_tests.gd
godot --headless --path . --script tests/route_tests.gd -- --wet
```

Current-run full-lap results, including UTC timestamp, track length and surface, are saved separately in `artifacts/route-test.json` and `artifacts/route-wet-test.json`.
