# Physics, route and race validation

Tests run with Godot 4.6.3 official Linux x86_64, headless, fixed simulation at 120 Hz. These tests do not measure GPU frame rates or Windows execution.

Use a writable Godot user-data/config/cache location in restricted environments. From the source root:

```sh
godot --headless --path . --script tests/physics_tests.gd
godot --headless --path . --script tests/race_tests.gd
godot --headless --path . --script tests/integration_tests.gd
godot --headless --path . --script tests/route_tests.gd
```

The physics suite has 17 assertions, the ordered-sector suite 22, and the scene-controller/track integration suite 11. The route test is a separate full-lap acceptance check and writes its current result to `artifacts/route-test.json`.

The full-lap test drives the actual planar vehicle using steering, accelerator and brake inputs. It does not move the vehicle to the path, teleport to gates, bypass lap validation, or use the boundary clamp to rescue a failed corner. A small pure-pursuit test driver computes steering from a 4–9 m lookahead and limits speed according to upcoming path curvature. The first passing run completed one valid ordered lap in **116.133 simulated seconds**, with **0.549 m** maximum distance from the centreline and **61.003 km/h** peak simulated speed. These are test-driver/simulation outcomes, not real-car measurements or rendering benchmarks.

Independent integration tests validate real track `sample_at`/`nearest` projection, finish wrapping, ordered completion, high-speed barrier energy reduction, repeated-contact positional stability, inward recovery, correct reset heading and a perpendicular car-body envelope at the barrier. An initial controller used too long a lookahead and too high a minimum corner speed; it left the road at a chicane. The conservative test controller passes the same generated track without changing the vehicle model or path. A second discovered issue was a centre-only rail clamp allowing the car nose through at perpendicular impacts; the oriented-body-envelope assertion protects against regression.

Race tests explicitly reject off-track records, gate skipping/teleports, wrong-direction crossings and impossibly short laps. Finishing an invalid lap starts a clean one. Stopping during an active lap continues its timer; pausing belongs to the game controller, which must stop ticking physics and rules. Reset clears partial lap state and preserves a supplied best time. Completed-lap count is a session count and remains across reset.

Remaining scope limits: no measured real-vehicle equivalence, suspension or tyre telemetry, and no claim that keyboard feel has been tested by a person on Windows. Collision is an analytic planar barrier envelope rather than a rigid-body damage solver. Graphics and native platform tests need their separate reports.
