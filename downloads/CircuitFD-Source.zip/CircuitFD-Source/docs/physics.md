# Driving model and limits

`CircuitVehicle.step()` runs in the game's fixed physics tick. Lengths are metres, time is seconds, velocity is metres per second; +Y is up and -Z is forward. Positive steering turns left. Keyboard input is smoothed; steering lock falls with speed. The visual model is independent of the physics node so camera changes and graphical frame rates cannot alter the simulation.

This is an accessible planar driving approximation, **not** a validated RX-7 tyre or suspension simulation. It uses a 1,280 kg illustrative mass, 2.425 m wheelbase, 0.31 m tyre radius, a heuristic torque curve, five forward ratios and explicit reverse. The ratios and torque have not been homologated to a specific real trim. Aerodynamic drag grows with speed; rolling resistance, bounded brake force, finite lateral tyre damping, yaw limits and high-speed understeer create predictable keyboard control. Handbrake reduces lateral grip. Asphalt, grass and gravel have different heuristic grip/resistance. There is no boost, vertical suspension, tyre temperature, tyre wear, ABS solver, differential model or measured load transfer.

Reverse is requested explicitly; while rolling in the opposite direction the car first brakes to near rest. Pressing and holding the ordinary brake cannot accidentally select reverse. Approximate engine rpm follows wheel speed and the current gear, with a smoothed idle/clutch allowance. The automatic gearbox briefly reduces torque during shifts. Engine sound should be labelled synthesized, not an authentic rotary recording.

`reset_to()` clears velocity, throttle, brake, steering, yaw rate and transmission state. The fixed tick should not be advanced while the game is paused or unfocused. Collision containment and lap validation belong to the track/game controller rather than the planar integrator.

Run the existing meaningful headless checks with:

```sh
godot --headless --path . --script tests/physics_tests.gd
```

The suite checks stationary stability, acceleration, straight-line drift, gearbox/rpm bounds, full braking, brake hold, reverse and safe direction switching, steering sign, bounded slip, deterministic trajectories for two render groupings with identical fixed substeps, grass traction, finite lateral damping, reduced steering at speed, 200 simulated seconds of mixed-surface stress and complete reset. These checks validate the implemented approximation; they are not evidence of physical equivalence to a real RX-7 or native Windows performance.
